"""
TwinIDBot — Main entry point
Registers all routers and starts polling.
"""
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from db.database import init_db, close_db
from utils.workers import shutdown_pool
from utils.emoji_fallback import PremiumEmojiFallbackMiddleware
from utils.commands import setup_commands

from handlers.start     import router as start_router
from handlers.posts     import router as posts_router
from handlers.ads       import router as ads_router, run_ads_expiry_checker
from handlers.manage    import router as manage_router
from handlers.credits   import router as credits_router
from handlers.admin     import router as admin_router
from handlers.kivani    import router as kivani_router
from handlers.gifts     import router as gifts_router
from handlers.vouch     import router as vouch_router
from handlers.moderation import router as moderation_router, ModerationLoggerMiddleware
from handlers.fallback  import router as fallback_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


async def main():
    await init_db()
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties())
    bot.session.middleware(PremiumEmojiFallbackMiddleware())
    dp  = Dispatcher(storage=MemoryStorage())
    dp.message.outer_middleware(ModerationLoggerMiddleware())

    dp.include_router(start_router)
    dp.include_router(posts_router)
    dp.include_router(ads_router)
    dp.include_router(manage_router)
    dp.include_router(credits_router)
    dp.include_router(admin_router)
    dp.include_router(kivani_router)
    dp.include_router(gifts_router)
    dp.include_router(vouch_router)
    dp.include_router(moderation_router)
    dp.include_router(fallback_router)

    await bot.delete_webhook(drop_pending_updates=True)
    await setup_commands(bot)
    ads_expiry_task = asyncio.create_task(run_ads_expiry_checker(bot))
    logger.info("🚀 TwinIDBot started!")
    try:
        await dp.start_polling(bot)
    finally:
        ads_expiry_task.cancel()
        await close_db()
        shutdown_pool()


if __name__ == "__main__":
    asyncio.run(main())
