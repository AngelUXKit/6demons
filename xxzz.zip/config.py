"""
TwinIDBot — Configuration
"""

BOT_TOKEN       = "8496881395:AAH4wnk4a9r0RI9RGGjMv33Y-xmrOJnRDz4"
CHANNEL_ID      = "-1004351872416"         # channel username or -100xxx chat ID
ADMIN_ID        = 6662384890        # @mvpzy Telegram user ID
ALLOWLIST_FILE  = "allowlist.json"

# ── Credits ──────────────────────────────────────────
# 1 USD = 1 000 credits
NEW_USER_BONUS   = 1_000            # $2.00 on signup
COST_PER_POST    = 1_000              # $0.20 standard post
TRANSFER_FEE_PCT = 0.03             # 3% on token transfers

# ── KivaniCDK ────────────────────────────────────────
KIVANI_CREATE_FEE = 500             # $0.50 to create a tag
KIVANI_CHANGE_FEE = 1_000           # $1.00 to change a tag
KIVANI_TAG_FILE   = "kivani/tags.json"

# ── Telegram Stars top-up (self-serve, Bot API native payments) ──────
# (label, credits_awarded, price_in_stars)
STAR_PACKAGES = [
    ("Starter",  1_000,  70),
    ("Popular",  5_000, 325),
    ("Premium", 12_000, 750),
    ("Whale",   30_000, 1800),
]

# ── Reputation (OGUsers-style vouches) ────────────────
TRUSTED_SELLER_VOUCHES = 20         # badge unlocks at this many vouches

# ── Ads of the Day ─────────────────────────────────────
# One pinned promo slot in the channel at a time. Paid entirely in
# Telegram Stars (native Bot API payment, currency="XTR") — NOT
# credits, unlike every other post type. Charged the moment the
# sender submits, before it's forwarded to the admin for approval.
ADS_OF_DAY_STARS = 4000            # flat Stars price, paid upfront
ADS_OF_DAY_HOURS = 24               # how long an accepted ad stays pinned

# ── TwinGuard (in-bot moderation module) ──────────────────
# Merged into TwinIDBot rather than run as a separate bot — enabled
# per-chat via /admin so it only does anything in chats the owner
# explicitly opts in.
MOD_AD_WORD_LIMIT   = 500   # text/caption messages longer than this many words are treated as an ad wall
MOD_NOTICE_LIFETIME = 8     # seconds the "your message was deleted" notice stays up before self-cleaning

# ── MySQL (for KivaniCDK messages) ───────────────────
MYSQL_HOST     = "localhost"
MYSQL_PORT     = 3306
MYSQL_USER     = "root"
MYSQL_PASSWORD = "Balenci123$$"
MYSQL_DB       = "twinidbot"

# ── Posts ────────────────────────────────────────────
POSTS_FILE = "posts/posts.json"

def custom_post_cost() -> int:
    """Promote Ads costs 2 % more than a standard post (ceiling)."""
    return int(COST_PER_POST * 1.02 + 0.9999)
