"""
TwinIDBot — Database layer (async/concurrent edition)
• In-memory cached JSON stores, write-through via background thread executor
• Per-resource asyncio locks (users / posts / tags / messages) for fine-grained concurrency
• MySQL access via a shared aiomysql connection pool (no per-call connect/close)
• All disk I/O offloaded to a thread pool so the event loop never blocks
"""
import asyncio
import json
import logging
import os
import shutil
import time

logger = logging.getLogger(__name__)

# ── shared asyncio locks (one per logical resource) ────
_users_lock = asyncio.Lock()
_posts_lock = asyncio.Lock()
_tags_lock  = asyncio.Lock()
_msgs_lock  = asyncio.Lock()
_ads_lock   = asyncio.Lock()
_mod_lock   = asyncio.Lock()

_ALLOWLIST     = "allowlist.json"
_ALLOWLIST_BAK = _ALLOWLIST + ".bak"
_POSTS_FILE    = "posts/posts.json"
_POSTS_BAK     = _POSTS_FILE + ".bak"
_TAGS_FILE     = "kivani/tags.json"
_TAGS_BAK      = _TAGS_FILE + ".bak"
_MSGS_FILE     = "kivani/messages.json"
_MSGS_BAK      = _MSGS_FILE + ".bak"
_ADS_FILE      = "posts/ads_of_day.json"
_ADS_BAK       = _ADS_FILE + ".bak"
_MOD_FILE      = "moderation.json"
_MOD_BAK       = _MOD_FILE + ".bak"

# ── in-memory caches ───────────────────────────────────
_users_cache: dict | None = None
_posts_cache: dict | None = None
_tags_cache:  dict | None = None
_msgs_cache:  dict | None = None
_ads_cache:   dict | None = None
_mod_cache:   dict | None = None

# ── MySQL connection pool (set in init_db) ─────────────
_mysql_pool = None


# ════════════════════════════════════════════════════════
# Low-level sync helpers (run inside executor)
# ════════════════════════════════════════════════════════

def _read_json_sync(path: str, bak: str, default: dict) -> dict:
    for p in (path, bak):
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    return d
            except Exception as e:
                logger.warning("Could not read %s: %s", p, e)
    return json.loads(json.dumps(default))  # deep copy of default


def _write_json_sync(path: str, bak: str, data: dict):
    dirname = os.path.dirname(path)
    if dirname:
        os.makedirs(dirname, exist_ok=True)
    if os.path.exists(path):
        try:
            shutil.copy2(path, bak)
        except Exception as e:
            logger.warning("Could not back up %s: %s", path, e)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


async def _read_json(path: str, bak: str, default: dict) -> dict:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _read_json_sync, path, bak, default)


async def _write_json(path: str, bak: str, data: dict):
    """Snapshot + offload write to a worker thread so the event loop stays free."""
    loop = asyncio.get_running_loop()
    snapshot = json.loads(json.dumps(data))
    await loop.run_in_executor(None, _write_json_sync, path, bak, snapshot)


# ════════════════════════════════════════════════════════
# Cache loaders
# ════════════════════════════════════════════════════════

async def _users_data() -> dict:
    global _users_cache
    if _users_cache is None:
        _users_cache = await _read_json(_ALLOWLIST, _ALLOWLIST_BAK, {"users": {}})
    return _users_cache


async def _posts_data() -> dict:
    global _posts_cache
    if _posts_cache is None:
        _posts_cache = await _read_json(_POSTS_FILE, _POSTS_BAK, {"posts": {}})
    return _posts_cache


async def _tags_data() -> dict:
    global _tags_cache
    if _tags_cache is None:
        _tags_cache = await _read_json(_TAGS_FILE, _TAGS_BAK, {"tags": {}})
    return _tags_cache


async def _msgs_data() -> dict:
    global _msgs_cache
    if _msgs_cache is None:
        _msgs_cache = await _read_json(_MSGS_FILE, _MSGS_BAK, {"messages": []})
    return _msgs_cache


async def _ads_data() -> dict:
    global _ads_cache
    if _ads_cache is None:
        _ads_cache = await _read_json(_ADS_FILE, _ADS_BAK, {"active": None, "pending": {}})
    return _ads_cache


async def _mod_data() -> dict:
    global _mod_cache
    if _mod_cache is None:
        _mod_cache = await _read_json(_MOD_FILE, _MOD_BAK, {"chats": {}})
    return _mod_cache


async def _persist_users():
    await _write_json(_ALLOWLIST, _ALLOWLIST_BAK, _users_cache)


async def _persist_posts():
    await _write_json(_POSTS_FILE, _POSTS_BAK, _posts_cache)


async def _persist_tags():
    await _write_json(_TAGS_FILE, _TAGS_BAK, _tags_cache)


async def _persist_msgs():
    await _write_json(_MSGS_FILE, _MSGS_BAK, _msgs_cache)


async def _persist_ads():
    await _write_json(_ADS_FILE, _ADS_BAK, _ads_cache)


async def _persist_mod():
    await _write_json(_MOD_FILE, _MOD_BAK, _mod_cache)


# ════════════════════════════════════════════════════════
# MySQL pool + init
# ════════════════════════════════════════════════════════

async def init_db():
    """Create MySQL pool + tables if possible. Pre-warm JSON caches concurrently."""
    global _mysql_pool
    try:
        import aiomysql
        from config import MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB
        _mysql_pool = await aiomysql.create_pool(
            host=MYSQL_HOST, port=MYSQL_PORT,
            user=MYSQL_USER, password=MYSQL_PASSWORD,
            db=MYSQL_DB, autocommit=True,
            minsize=1, maxsize=10,
        )
        async with _mysql_pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute("""
                    CREATE TABLE IF NOT EXISTS kivani_messages (
                        id          INT AUTO_INCREMENT PRIMARY KEY,
                        sender_tag  VARCHAR(16) NOT NULL,
                        receiver_tag VARCHAR(16) NOT NULL,
                        content     TEXT        NOT NULL,
                        sent_at     DATETIME    DEFAULT CURRENT_TIMESTAMP,
                        is_read     TINYINT(1)  DEFAULT 0,
                        INDEX idx_receiver (receiver_tag),
                        INDEX idx_sender   (sender_tag)
                    )
                """)
        logger.info("✅ MySQL pool ready")
    except Exception as e:
        _mysql_pool = None
        logger.warning("⚠️  MySQL unavailable (%s). KivaniCDK messages will use JSON fallback.", e)

    os.makedirs("posts",  exist_ok=True)
    os.makedirs("kivani", exist_ok=True)

    # Pre-warm caches concurrently — parallel disk reads on startup
    await asyncio.gather(
        _users_data(),
        _posts_data(),
        _tags_data(),
        _msgs_data(),
        _ads_data(),
        _mod_data(),
    )

    posts = await _posts_data()
    if "posts" not in posts:
        posts["posts"] = {}
        await _persist_posts()


async def close_db():
    """Close MySQL pool cleanly on shutdown."""
    global _mysql_pool
    if _mysql_pool is not None:
        _mysql_pool.close()
        await _mysql_pool.wait_closed()
        _mysql_pool = None


# ════════════════════════════════════════════════════════
# User / credits API
# ════════════════════════════════════════════════════════

async def get_user(user_id: int) -> dict | None:
    async with _users_lock:
        data = await _users_data()
        u = data["users"].get(str(user_id))
        return dict(u) if u else None


async def get_credits(user_id: int) -> int:
    u = await get_user(user_id)
    return u["credits"] if u else 0


async def has_enough(user_id: int, needed: int) -> bool:
    return await get_credits(user_id) >= needed


async def add_user(user_id: int, name: str, credits: int):
    async with _users_lock:
        data = await _users_data()
        uid  = str(user_id)
        if uid not in data["users"]:
            data["users"][uid] = {
                "name":         name,
                "credits":      credits,
                "tos_accepted": False,
                "kivani_tag":   None,
                "post_count":   0,
                "exclusive":    False,
                "vouches":      0,
            }
            await _persist_users()


async def set_exclusive(user_id: int, status: bool) -> bool:
    return await update_user_field(user_id, "exclusive", status)


async def is_exclusive(user_id: int) -> bool:
    user = await get_user(user_id)
    return bool(user and user.get("exclusive", False))


async def update_user_field(user_id: int, field: str, value):
    async with _users_lock:
        data = await _users_data()
        uid  = str(user_id)
        if uid not in data["users"]:
            return False
        data["users"][uid][field] = value
        await _persist_users()
        return True


async def deduct_credits(user_id: int, amount: int) -> bool:
    async with _users_lock:
        data = await _users_data()
        uid  = str(user_id)
        if uid not in data["users"] or data["users"][uid]["credits"] < amount:
            return False
        data["users"][uid]["credits"] -= amount
        await _persist_users()
        return True


async def add_credits(user_id: int, amount: int) -> bool:
    async with _users_lock:
        data = await _users_data()
        uid  = str(user_id)
        if uid not in data["users"]:
            return False
        data["users"][uid]["credits"] += amount
        await _persist_users()
        return True


async def remove_user(user_id: int) -> bool:
    async with _users_lock:
        data = await _users_data()
        uid  = str(user_id)
        if uid not in data["users"]:
            return False
        del data["users"][uid]
        await _persist_users()
        return True


async def list_users() -> dict:
    async with _users_lock:
        data = await _users_data()
        return json.loads(json.dumps(data["users"]))


async def transfer_credits(from_id: int, to_id: int, amount: int) -> tuple[bool, str]:
    from config import TRANSFER_FEE_PCT
    fee   = max(1, int(amount * TRANSFER_FEE_PCT))
    total = amount + fee
    async with _users_lock:
        data  = await _users_data()
        users = data["users"]
        fk, tk = str(from_id), str(to_id)
        if fk not in users:
            return False, "Your account was not found."
        if tk not in users:
            return False, "Recipient not found."
        if users[fk]["credits"] < total:
            bal = users[fk]["credits"]
            return False, f"Need {total} credits (amount + fee) but you have {bal}."
        users[fk]["credits"] -= total
        users[tk]["credits"] += amount
        recipient_name = users[tk]["name"]
        await _persist_users()
    return True, f"Sent {amount} credits to {recipient_name}. Fee: {fee}. Total: {total}."


# ════════════════════════════════════════════════════════
# Reputation — OGUsers-style vouches
# One vouch per (post, voucher); builds a public trust score
# shown on ID cards / listings, same idea as OGU's vouch count.
# ════════════════════════════════════════════════════════

async def add_vouch(post_id: str, voucher_id: int) -> tuple[bool, str]:
    """Record a vouch for a post's seller. Returns (ok, new_count_or_error)."""
    async with _posts_lock:
        data = await _posts_data()
        post = data["posts"].get(post_id)
        if not post:
            return False, "Post not found. Check the Post ID and try again."
        owner_id = post.get("owner_id")
        if owner_id == voucher_id:
            return False, "You can't vouch your own listing."
        voucher_list = post.setdefault("vouched_by", [])
        if voucher_id in voucher_list:
            return False, "You already vouched this seller for this deal."
        voucher_list.append(voucher_id)
        await _persist_posts()

    async with _users_lock:
        udata = await _users_data()
        uk = str(owner_id)
        if uk not in udata["users"]:
            return False, "Seller account not found."
        udata["users"][uk]["vouches"] = udata["users"][uk].get("vouches", 0) + 1
        new_count = udata["users"][uk]["vouches"]
        await _persist_users()

    return True, str(new_count)


async def get_vouches(user_id: int) -> int:
    user = await get_user(user_id)
    return int(user.get("vouches", 0)) if user else 0


# ════════════════════════════════════════════════════════
# Posts storage
# ════════════════════════════════════════════════════════

async def save_post(post_id: str, post_data: dict):
    async with _posts_lock:
        data = await _posts_data()
        data["posts"][post_id] = post_data
        await _persist_posts()


async def get_post(post_id: str) -> dict | None:
    async with _posts_lock:
        data = await _posts_data()
        p = data["posts"].get(post_id)
        return dict(p) if p else None


async def get_user_posts(user_id: int) -> list[dict]:
    async with _posts_lock:
        data = await _posts_data()
        return [dict(p) for p in data["posts"].values() if p.get("owner_id") == user_id]


async def update_post(post_id: str, updates: dict) -> bool:
    async with _posts_lock:
        data = await _posts_data()
        if post_id not in data["posts"]:
            return False
        data["posts"][post_id].update(updates)
        await _persist_posts()
        return True


async def delete_post(post_id: str) -> bool:
    async with _posts_lock:
        data = await _posts_data()
        if post_id not in data["posts"]:
            return False
        del data["posts"][post_id]
        await _persist_posts()
        return True


# ════════════════════════════════════════════════════════
# Ads of the Day — single active pinned slot
# ════════════════════════════════════════════════════════

async def get_active_ad() -> dict | None:
    """Current pinned ad, if any (regardless of expiry — callers that
    care about expiry compare against `expires_at` themselves, since
    the actual unpin action needs a live Bot instance and belongs in
    the handler layer, not here)."""
    async with _ads_lock:
        data = await _ads_data()
        active = data.get("active")
        return dict(active) if active else None


async def set_active_ad(record: dict):
    """Claim the single Ads-of-the-Day slot."""
    async with _ads_lock:
        data = await _ads_data()
        data["active"] = record
        await _persist_ads()


async def clear_active_ad():
    """Release the slot (called after unpinning)."""
    async with _ads_lock:
        data = await _ads_data()
        data["active"] = None
        await _persist_ads()


async def save_pending_ad(uid: int, token: str, record: dict):
    """Stash a paid submission awaiting admin Accept/Reject. Persisted
    (not just held in memory) so a bot restart between payment and
    admin decision doesn't strand an already-paid submission."""
    async with _ads_lock:
        data = await _ads_data()
        data.setdefault("pending", {})[f"{uid}:{token}"] = record
        await _persist_ads()


async def pop_pending_ad(uid: int, token: str) -> dict | None:
    """Fetch + remove a pending submission (Accept/Reject both consume it)."""
    async with _ads_lock:
        data = await _ads_data()
        key = f"{uid}:{token}"
        record = data.setdefault("pending", {}).pop(key, None)
        if record is not None:
            await _persist_ads()
        return dict(record) if record else None


# ════════════════════════════════════════════════════════
# KivaniCDK tag registry
# ════════════════════════════════════════════════════════

async def tag_exists(tag: str) -> bool:
    async with _tags_lock:
        data = await _tags_data()
        return tag.lower() in {k.lower() for k in data["tags"]}


async def get_tag_owner(tag: str) -> int | None:
    async with _tags_lock:
        data = await _tags_data()
        for t, uid in data["tags"].items():
            if t.lower() == tag.lower():
                return uid
        return None


async def register_tag(tag: str, user_id: int) -> bool:
    async with _tags_lock:
        data = await _tags_data()
        if tag.lower() in {k.lower() for k in data["tags"]}:
            return False
        data["tags"][tag] = user_id
        await _persist_tags()
        return True


async def change_tag(old_tag: str, new_tag: str, user_id: int) -> bool:
    async with _tags_lock:
        data = await _tags_data()
        if new_tag.lower() in {k.lower() for k in data["tags"] if k.lower() != old_tag.lower()}:
            return False
        data["tags"] = {k: v for k, v in data["tags"].items() if k.lower() != old_tag.lower()}
        data["tags"][new_tag] = user_id
        await _persist_tags()
        return True


async def get_user_tag(user_id: int) -> str | None:
    async with _tags_lock:
        data = await _tags_data()
        for tag, uid in data["tags"].items():
            if uid == user_id:
                return tag
        return None


# ════════════════════════════════════════════════════════
# KivaniCDK messages (MySQL pool with JSON fallback)
# ════════════════════════════════════════════════════════

async def send_kivani_message(sender_tag: str, receiver_tag: str, content: str) -> bool:
    """Store a message; uses pooled MySQL if available, else JSON fallback."""
    if _mysql_pool is not None:
        try:
            async with _mysql_pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "INSERT INTO kivani_messages (sender_tag, receiver_tag, content) VALUES (%s,%s,%s)",
                        (sender_tag, receiver_tag, content),
                    )
            return True
        except Exception as e:
            logger.warning("MySQL insert failed (%s), falling back to JSON", e)

    async with _msgs_lock:
        data = await _msgs_data()
        data["messages"].append({
            "sender":   sender_tag,
            "receiver": receiver_tag,
            "content":  content,
            "sent_at":  time.strftime("%Y-%m-%d %H:%M:%S"),
            "is_read":  False,
        })
        await _persist_msgs()
        return True


async def get_kivani_inbox(tag: str) -> list[dict]:
    """Fetch most recent messages for tag."""
    if _mysql_pool is not None:
        try:
            import aiomysql
            async with _mysql_pool.acquire() as conn:
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    await cur.execute(
                        "SELECT id, sender_tag, content, sent_at FROM kivani_messages "
                        "WHERE receiver_tag=%s ORDER BY sent_at DESC LIMIT 50", (tag,)
                    )
                    return list(await cur.fetchall())
        except Exception as e:
            logger.warning("MySQL fetch failed (%s), falling back to JSON", e)

    async with _msgs_lock:
        data = await _msgs_data()
        return [m for m in reversed(data["messages"]) if m["receiver"] == tag][:50]


# ════════════════════════════════════════════════════════
# TwinGuard — in-bot moderation module (per-chat, owner-toggled)
# ════════════════════════════════════════════════════════
# Merged in rather than run as a second bot — one process, one set of
# credentials, enabled only for the specific chats the owner opts in
# via /admin, so it costs nothing in idle chats.

_MOD_LOG_CAP      = 5000   # per-chat cap on regular logged message ids
_MOD_JOIN_LOG_CAP = 2000   # per-chat cap on logged join/leave message ids


def _mod_chat(data: dict, chat_id: int) -> dict:
    return data["chats"].setdefault(str(chat_id), {
        "enabled": False, "delete_joins": False, "title": "",
        "log": [], "join_log": [],
    })


async def is_moderation_enabled(chat_id: int) -> bool:
    async with _mod_lock:
        data = await _mod_data()
        chat = data["chats"].get(str(chat_id))
        return bool(chat and chat.get("enabled"))


async def set_moderation_enabled(chat_id: int, enabled: bool, title: str = ""):
    async with _mod_lock:
        data = await _mod_data()
        chat = _mod_chat(data, chat_id)
        chat["enabled"] = enabled
        if title:
            chat["title"] = title
        await _persist_mod()


async def list_moderated_chats() -> dict:
    """chat_id (str) -> chat settings dict, for the /admin panel."""
    async with _mod_lock:
        data = await _mod_data()
        return dict(data["chats"])


async def get_delete_joins(chat_id: int) -> bool:
    async with _mod_lock:
        data = await _mod_data()
        chat = data["chats"].get(str(chat_id))
        return bool(chat and chat.get("delete_joins"))


async def set_delete_joins(chat_id: int, enabled: bool):
    async with _mod_lock:
        data = await _mod_data()
        _mod_chat(data, chat_id)["delete_joins"] = enabled
        await _persist_mod()


async def log_mod_message(chat_id: int, message_id: int, is_join_event: bool = False):
    async with _mod_lock:
        data = await _mod_data()
        chat = _mod_chat(data, chat_id)
        key  = "join_log" if is_join_event else "log"
        cap  = _MOD_JOIN_LOG_CAP if is_join_event else _MOD_LOG_CAP
        lst  = chat[key]
        if message_id not in lst:
            lst.append(message_id)
            if len(lst) > cap:
                del lst[: len(lst) - cap]  # drop oldest, keep the log bounded
        await _persist_mod()


async def get_mod_message_ids(chat_id: int, joins_only: bool = False) -> list[int]:
    async with _mod_lock:
        data = await _mod_data()
        chat = data["chats"].get(str(chat_id))
        if not chat:
            return []
        return list(chat["join_log"] if joins_only else (chat["log"] + chat["join_log"]))


async def clear_mod_messages(chat_id: int, message_ids: list[int]):
    if not message_ids:
        return
    ids = set(message_ids)
    async with _mod_lock:
        data = await _mod_data()
        chat = data["chats"].get(str(chat_id))
        if not chat:
            return
        chat["log"]      = [m for m in chat["log"] if m not in ids]
        chat["join_log"] = [m for m in chat["join_log"] if m not in ids]
        await _persist_mod()
