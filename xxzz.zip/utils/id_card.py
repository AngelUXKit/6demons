"""
TwinIDBot — ID Card / OG Post Image Generator  (v4 — reference-matched neon glass)
Generates the OG-standard (1200x630) card for channel posts. Renders at 2x
internally and downsamples with LANCZOS for crisp edges.

Composition follows the approved reference design exactly: centered avatar
-> flanking @handle / Twin.ID pills -> centered gradient-glow seller name
-> small kivani/vouch caption -> static brand icon row -> info-chip grid
(platform/handle/price/bargain/contact/status) -> footer strip. See
utils/background.py, effects.py, glass.py, avatar.py, typography.py,
icons.py, layout.py and components.py for the actual drawing code.

This module ONLY orchestrates those pieces in order and exposes the exact
same public API the rest of the bot already depends on:
    generate_id_card(...)    — unchanged signature, unchanged return type
    fetch_profile_photo(...) — unchanged

Runs inside the shared CPU process pool (utils/workers.py) — pure
function, no shared state. Requires: Pillow.
"""
from __future__ import annotations

import io
import logging

logger = logging.getLogger(__name__)

# OG-image standard ratio (1.91:1) — renders crisp as a link preview too.
CARD_W, CARD_H = 1200, 630


async def fetch_profile_photo(bot, user_id: int) -> bytes | None:
    """Download the user's Telegram profile photo as bytes. Unchanged."""
    try:
        photos = await bot.get_user_profile_photos(user_id, limit=1)
        if not photos.photos:
            return None
        file_id = photos.photos[0][-1].file_id
        file = await bot.get_file(file_id)
        buf = io.BytesIO()
        await bot.download_file(file.file_path, destination=buf)
        return buf.getvalue()
    except Exception as e:
        logger.debug("Profile photo fetch failed: %s", e)
        return None


def _build_chips(platform: str, handle: str, price: str, bargain: str,
                  contact: str, link_url: str) -> list[tuple[str, str]]:
    chips = [
        ("PLATFORM", platform or "Other"),
        ("HANDLE", f"@{handle}" if handle else "—"),
        ("PRICE", price),
        ("BARGAIN", bargain),
    ]
    if contact:
        chips.append(("CONTACT", contact))
    if link_url:
        chips.append(("LINK", "Tap post to view"))
    if not link_url and not contact:
        chips.append(("STATUS", "Available now"))
    return chips


def generate_id_card(
    full_name: str,
    username: str,
    platform: str,
    handle: str,
    price: str,
    bargain: str,
    post_id: str,
    kivani_tag: str | None = None,
    avatar_bytes: bytes | None = None,
    contact: str = "",
    link_url: str = "",
    is_exclusive: bool = False,
    vouches: int = 0,
) -> bytes:
    """
    Render a 1200x630 neon-glass identity card (2x internal, LANCZOS
    downsample). Returns PNG bytes, or b"" on failure — signature, order
    and return type are unchanged from the previous renderer.
    """
    try:
        from PIL import Image

        from utils import background as bgmod
        from utils.layout import Geometry
        from utils.avatar import compose_avatar
        from utils.components import (
            draw_exclusive_badge, draw_flanking_pills, draw_name_and_caption,
            draw_icon_row, draw_info_chips, draw_footer,
        )

        scale = 2
        geo = Geometry(scale=scale)
        W, H = geo.canvas()

        # ── Background: gradient + dot grid + centered glow + grain + vignette ──
        canvas = bgmod.create_background(W, H, scale=scale)

        # ── Avatar, centered top ─────────────────────────────────────────
        display_name = full_name or username or "TWINID Seller"
        cx, cy = geo.avatar_center()
        compose_avatar(canvas, (cx, cy), geo.avatar_d, avatar_bytes, display_name, scale=scale)

        # ── Flanking @handle / Twin.ID pills, centered gradient name ─────
        draw_flanking_pills(canvas, geo, username, platform, scale)
        content_bottom = draw_name_and_caption(canvas, geo, display_name, kivani_tag, vouches, scale)

        # ── Static brand icon row ─────────────────────────────────────────
        icon_row_top = content_bottom + geo.icon_row_gap
        icons_bottom = draw_icon_row(canvas, geo, icon_row_top, scale)

        # ── Info chip grid: platform / handle / price / bargain / contact / status ──
        footer_top = geo.footer_box()[1]
        chips_top = icons_bottom + geo.chips_top_gap
        chips_bottom = footer_top - 12 * scale
        chips = _build_chips(platform, handle, price, bargain, contact, link_url)
        draw_info_chips(canvas, geo, chips, platform, chips_top, chips_bottom, scale)

        if is_exclusive:
            draw_exclusive_badge(canvas, geo, scale)

        # ── Footer: post id / ecosystem tagline ───────────────────────────
        draw_footer(canvas, geo, post_id, scale)

        # ── Downsample for crisp export ─────────────────────────────────
        # No outer alpha mask here on purpose: Telegram re-encodes photo
        # attachments and flattens any transparent area to solid white
        # before delivery, so a rounded-corner alpha hole always came
        # back as four white corners. Telegram's own message-bubble UI
        # already clips photo attachments to rounded corners on its own,
        # so a full-bleed opaque rectangle is both simpler and correct.
        result = canvas.convert("RGB").resize((CARD_W, CARD_H), Image.LANCZOS)

        buf = io.BytesIO()
        result.save(buf, format="PNG", optimize=False)
        return buf.getvalue()

    except ImportError:
        logger.warning("Pillow not installed — ID card generation disabled")
        return b""
    except Exception as e:
        logger.error("ID card generation error: %s", e)
        return b""
