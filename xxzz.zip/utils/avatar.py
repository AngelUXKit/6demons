"""
TwinID Card — Avatar
Loads the seller's Telegram profile photo (or falls back to an initials
placeholder), clips it to a circle, and wraps it in the glass neon ring +
outer glow that gives the header its "premium identity card" focal point.
"""
from __future__ import annotations

import io
import logging

from PIL import Image, ImageDraw

from utils import background as bgmod
from utils.effects import circle_mask_cached, outer_glow
from utils.typography import load_font, FONT_BOLD

logger = logging.getLogger(__name__)


def _placeholder(diameter: int) -> Image.Image:
    """Generic glowing person-silhouette — matches the approved reference's
    default avatar (used when the seller has no Telegram profile photo)."""
    img = Image.new("RGBA", (diameter, diameter), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([0, 0, diameter, diameter], fill=(8, 26, 24, 255))

    glyph = Image.new("L", (diameter, diameter), 0)
    gd = ImageDraw.Draw(glyph)
    cx = diameter / 2
    head_r = diameter * 0.16
    head_cy = diameter * 0.36
    gd.ellipse([cx - head_r, head_cy - head_r, cx + head_r, head_cy + head_r], fill=255)
    body_w = diameter * 0.46
    body_top = diameter * 0.56
    gd.rounded_rectangle(
        [cx - body_w / 2, body_top, cx + body_w / 2, diameter * 0.92],
        radius=body_w * 0.5, fill=255,
    )
    # clip shoulders to the circle so they don't square off past the avatar edge
    circle = Image.new("L", (diameter, diameter), 0)
    ImageDraw.Draw(circle).ellipse([0, 0, diameter, diameter], fill=255)
    from PIL import ImageChops
    glyph = ImageChops.multiply(glyph, circle)

    silhouette = Image.new("RGBA", (diameter, diameter), (*bgmod.GLOW, 235))
    silhouette.putalpha(glyph)
    img.alpha_composite(silhouette)
    return img


def _load_and_crop(avatar_bytes: bytes, diameter: int) -> Image.Image | None:
    try:
        img = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
    except Exception as e:
        logger.debug("Avatar decode failed: %s", e)
        return None
    # center-crop to square before resizing so off-ratio photos don't stretch
    w, h = img.size
    side = min(w, h)
    left, top = (w - side) // 2, (h - side) // 2
    img = img.crop((left, top, left + side, top + side)).resize((diameter, diameter), Image.LANCZOS)
    img.putalpha(circle_mask_cached(diameter))
    return img


def compose_avatar(base_rgba: Image.Image, center: tuple[int, int], diameter: int,
                    avatar_bytes: bytes | None, display_name: str, scale: int = 2) -> None:
    """
    Composites the full avatar treatment directly onto `base_rgba`:
    outer ambient glow -> glass ring -> circular photo/placeholder -> inner
    highlight arc. Mutates `base_rgba` in place.
    """
    from utils.glass import draw_glass_circle

    cx, cy = center
    r = diameter // 2
    ring_pad = int(10 * scale)

    ring = draw_glass_circle(base_rgba, (cx, cy), r + ring_pad, scale=scale,
                              tint=(*bgmod.ACCENT, 30), glow_intensity=110,
                              glow_radius=36 * scale)
    base_rgba.alpha_composite(ring)

    photo = _load_and_crop(avatar_bytes, diameter) if avatar_bytes else None
    if photo is None:
        photo = _placeholder(diameter)

    # soft glow directly behind the photo silhouette for extra pop
    photo_mask = photo.getchannel("A")
    glow = outer_glow(photo_mask, bgmod.GLOW, base_rgba.size, (cx - r, cy - r),
                       radius=20 * scale, intensity=60)
    base_rgba.alpha_composite(glow)
    base_rgba.paste(photo, (cx - r, cy - r), photo)

    # thin bright rim right on the photo edge
    rim = Image.new("RGBA", base_rgba.size, (0, 0, 0, 0))
    ImageDraw.Draw(rim).ellipse([cx - r, cy - r, cx + r, cy + r], outline=bgmod.ACCENT, width=max(2, 2 * scale))
    base_rgba.alpha_composite(rim)
