"""
TwinID Card — Effects
Generic, reusable Pillow post-processing effects used by glass.py,
avatar.py and typography.py: blur, bloom, glow (outer/inner), drop
shadow and highlight strokes. Every function is a pure transform —
takes an image/mask in, returns a new RGBA layer out.
"""
from __future__ import annotations

from functools import lru_cache

from PIL import Image, ImageDraw, ImageFilter, ImageChops


def gaussian_blur(img: Image.Image, radius: float) -> Image.Image:
    return img.filter(ImageFilter.GaussianBlur(radius))


def bloom(img: Image.Image, radius: float = 24, intensity: float = 0.55) -> Image.Image:
    """Screen-blend a blurred copy over the original for a soft light-bleed."""
    blurred = gaussian_blur(img, radius)
    if img.mode != "RGBA":
        img = img.convert("RGBA")
    if blurred.mode != "RGBA":
        blurred = blurred.convert("RGBA")
    scaled = blurred.copy()
    a = scaled.getchannel("A").point(lambda v: int(v * intensity))
    scaled.putalpha(a)
    return Image.alpha_composite(img, scaled)


def outer_glow(mask: Image.Image, color: tuple[int, int, int], canvas_size: tuple[int, int],
               offset: tuple[int, int], radius: float = 26, intensity: int = 200) -> Image.Image:
    """
    Build a soft colored glow that sits BEHIND a shape, expanding past its
    silhouette. `mask` is an "L" alpha mask of the shape at its own bbox size;
    `offset` is where that shape sits on the full canvas.

    Blurs only a locally-padded crop around the shape (not the whole
    canvas) — blurring a full 2400x1260 layer per glow is the single
    biggest render-time cost, and the result outside the padded region
    is all-zero anyway.
    """
    W, H = canvas_size
    mw, mh = mask.size
    pad = max(4, int(radius * 3))
    local = Image.new("RGBA", (mw + 2 * pad, mh + 2 * pad), (0, 0, 0, 0))
    colored = Image.new("RGBA", mask.size, (*color, intensity))
    colored.putalpha(mask)
    local.paste(colored, (pad, pad), colored)
    local = local.filter(ImageFilter.GaussianBlur(radius))

    full = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dest_x, dest_y = offset[0] - pad, offset[1] - pad
    # Clip the paste box to the canvas so negative/overhanging offsets don't error.
    src_x0, src_y0 = max(0, -dest_x), max(0, -dest_y)
    dst_x0, dst_y0 = max(0, dest_x), max(0, dest_y)
    dst_x1, dst_y1 = min(W, dest_x + local.width), min(H, dest_y + local.height)
    if dst_x1 > dst_x0 and dst_y1 > dst_y0:
        crop = local.crop((src_x0, src_y0, src_x0 + (dst_x1 - dst_x0), src_y0 + (dst_y1 - dst_y0)))
        full.paste(crop, (dst_x0, dst_y0), crop)
    return full


def inner_glow(mask: Image.Image, color: tuple[int, int, int], thickness: float = 10,
               intensity: int = 140) -> Image.Image:
    """Soft light hugging the INSIDE edge of a shape (mask = 'L' alpha at shape bbox)."""
    eroded = mask.filter(ImageFilter.MinFilter(max(3, int(thickness) | 1)))
    ring = ImageChops.subtract(mask, eroded)
    ring = ring.filter(ImageFilter.GaussianBlur(thickness * 0.6))
    out = Image.new("RGBA", mask.size, (*color, intensity))
    out.putalpha(ring)
    return out


def drop_shadow(mask: Image.Image, canvas_size: tuple[int, int], offset: tuple[int, int],
                 dy: int = 10, radius: float = 20, opacity: int = 120) -> Image.Image:
    """Soft shadow cast below a shape, positioned onto the full canvas.
    Blurs a locally-padded crop only — see outer_glow for why."""
    W, H = canvas_size
    mw, mh = mask.size
    pad = max(4, int(radius * 3))
    local = Image.new("RGBA", (mw + 2 * pad, mh + 2 * pad), (0, 0, 0, 0))
    shadow = Image.new("RGBA", mask.size, (0, 0, 0, opacity))
    shadow.putalpha(mask.point(lambda v: int(v * opacity / 255)))
    local.paste(shadow, (pad, pad), shadow)
    local = local.filter(ImageFilter.GaussianBlur(radius))

    full = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dest_x, dest_y = offset[0] - pad, offset[1] + dy - pad
    src_x0, src_y0 = max(0, -dest_x), max(0, -dest_y)
    dst_x0, dst_y0 = max(0, dest_x), max(0, dest_y)
    dst_x1, dst_y1 = min(W, dest_x + local.width), min(H, dest_y + local.height)
    if dst_x1 > dst_x0 and dst_y1 > dst_y0:
        crop = local.crop((src_x0, src_y0, src_x0 + (dst_x1 - dst_x0), src_y0 + (dst_y1 - dst_y0)))
        full.paste(crop, (dst_x0, dst_y0), crop)
    return full


def top_highlight_mask(size: tuple[int, int], band: float = 0.55) -> Image.Image:
    """Vertical gradient mask, brightest at the top — used for glass top-sheen."""
    w, h = size
    grad = Image.new("L", (1, h))
    for y in range(h):
        t = min(y / (h * band), 1.0)
        grad.putpixel((0, y), int(255 * (1 - t)))
    return grad.resize((w, h))


def soft_shadow_for_rect(size: tuple[int, int], radius: int) -> Image.Image:
    """Rounded-rect alpha mask, convenience for shadow/glow calls on pills/cards."""
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, size[0] - 1, size[1] - 1], radius=radius, fill=255)
    return mask


@lru_cache(maxsize=16)
def rounded_mask_cached(w: int, h: int, radius: int) -> Image.Image:
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255)
    return mask


@lru_cache(maxsize=8)
def circle_mask_cached(diameter: int) -> Image.Image:
    mask = Image.new("L", (diameter, diameter), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, diameter - 1, diameter - 1], fill=255)
    return mask
