"""
TwinID Card — Components
Named UI pieces the card is built from, matching the approved reference
layout: flanking handle/brand pills, centered gradient wordmark + caption,
a static brand icon row, the info-chip grid, the footer strip, and the
exclusive corner badge. Each is glass.py + typography.py + icons.py wired
together — id_card.py just calls these in order.
"""
from __future__ import annotations

from PIL import Image, ImageDraw

from utils import background as bgmod
from utils.glass import draw_glass_pill, draw_glass_chip, draw_glass_button
from utils.typography import (
    load_font, FONT_BOLD, FONT_REGULAR, FONT_CJK, pick_font_path, needs_cjk_font,
    draw_text, draw_gradient_text,
    draw_text_centered, text_size, spaced,
)
from utils.icons import get_icon, platform_to_icon
from utils.layout import Geometry

# Static brand row shown under the wordmark — this is TwinID's own
# cross-platform branding (matches the reference), not tied to any one
# listing's platform.
FOOTER_BRAND_ICONS = ("telegram", "x", "instagram", "discord", "tiktok", "website")


def _fit_font(draw: ImageDraw.ImageDraw, text: str, path: str, start_size: int,
              max_w: int, min_size: int) -> "ImageFont.FreeTypeFont":
    """Shrinks a font until `text` fits `max_w`, down to `min_size` — then the
    caller truncates. Keeps long seller names / usernames from overrunning
    their pill or the card edge."""
    size = start_size
    while size > min_size:
        f = load_font(path, size)
        tw, _ = text_size(draw, text, f)
        if tw <= max_w:
            return f
        size -= 2
    return load_font(path, min_size)


def _truncate_to_width(draw: ImageDraw.ImageDraw, text: str, font, max_w: int) -> str:
    if text_size(draw, text, font)[0] <= max_w:
        return text
    while text and text_size(draw, text + "…", font)[0] > max_w:
        text = text[:-1]
    return text + "…" if text else "…"


def draw_exclusive_badge(base: Image.Image, geo: Geometry, scale: int) -> None:
    w, _ = geo.canvas()
    label = spaced("EXCLUSIVE", 2)
    f = load_font(FONT_REGULAR, 12 * scale)
    draw = ImageDraw.Draw(base, "RGBA")
    tw, th = text_size(draw, label, f)
    bw, bh = tw + 28 * scale, th + 16 * scale
    bx, by = w - geo.margin - bw, 20 * scale
    box = (int(bx), int(by), int(bx + bw), int(by + bh))
    pill = draw_glass_pill(base, box, scale=scale, tint=(255, 200, 90, 40),
                            stroke=(255, 210, 120, 180), glow_color=(255, 210, 120), glow_intensity=90)
    base.alpha_composite(pill)
    draw_text(base, (bx + 14 * scale, by + 7 * scale), label, f, fill=(255, 224, 160))


def _handle_pill(base: Image.Image, geo: Geometry, x_edge: int, side: str,
                  text: str, icon_name: str, scale: int) -> None:
    """One flanking pill. side='left' grows rightward from x_edge with the
    icon on its right (matches the reference's left pill); side='right'
    grows leftward from x_edge with the icon on its left."""
    draw = ImageDraw.Draw(base, "RGBA")
    font = _fit_font(draw, text, pick_font_path(text), 17 * scale, geo.pill_max_w - 40 * scale, 12 * scale)
    text = _truncate_to_width(draw, text, font, geo.pill_max_w - 40 * scale)
    tw, th = text_size(draw, text, font)

    icon_d = int(geo.pill_h * 0.5)
    inner_pad = 16 * scale
    content_w = tw + icon_d + 10 * scale
    pill_w = int(content_w + inner_pad * 2)
    cy = geo.pill_cy()

    if side == "left":
        box = (x_edge, int(cy - geo.pill_h / 2), x_edge + pill_w, int(cy + geo.pill_h / 2))
    else:
        box = (x_edge - pill_w, int(cy - geo.pill_h / 2), x_edge, int(cy + geo.pill_h / 2))

    pill = draw_glass_pill(base, box, scale=scale, tint=(*bgmod.ACCENT, 22), glow_intensity=55)
    base.alpha_composite(pill)

    icon = get_icon(icon_name, size=icon_d, color=bgmod.INK)
    if side == "left":
        text_x = box[0] + inner_pad
        icon_x = box[2] - inner_pad - icon_d
    else:
        icon_x = box[0] + inner_pad
        text_x = icon_x + icon_d + 10 * scale

    icon_y = int(cy - icon_d / 2)
    base.paste(icon, (int(icon_x), icon_y), icon)
    draw_text(base, (text_x, cy - th / 2 - 1), text, font, fill=bgmod.INK)


def draw_flanking_pills(base: Image.Image, geo: Geometry, username: str, platform: str,
                         scale: int) -> None:
    w, _ = geo.canvas()
    cx, _ = geo.avatar_center()
    left_edge = geo.margin
    right_edge = w - geo.margin
    _handle_pill(base, geo, left_edge, "left", f"@{username}" if username else "@seller",
                 platform_to_icon(platform), scale)
    _handle_pill(base, geo, right_edge, "right", "Twin.ID", "telegram", scale)


def draw_name_and_caption(base: Image.Image, geo: Geometry, display_name: str,
                          kivani_tag: str | None, vouches: int, scale: int) -> int:
    """Draws the centered gradient name + optional caption line below it.
    Returns the y-coordinate right below the last line drawn, so the caller
    knows exactly where to start the icon row — no separate height estimate
    to keep in sync."""
    w, _ = geo.canvas()
    draw = ImageDraw.Draw(base, "RGBA")

    max_name_w = w * 0.62
    name_font = _fit_font(draw, display_name, pick_font_path(display_name, bold=True), 46 * scale, max_name_w, 22 * scale)
    display_name = _truncate_to_width(draw, display_name, name_font, max_name_w)
    _, name_h = text_size(draw, display_name, name_font)

    name_top = geo.name_top()
    tw, _ = text_size(draw, display_name, name_font)
    name_x = int((w - tw) / 2)
    draw_gradient_text(base, (name_x, name_top), display_name, name_font,
                        top_color=bgmod.INK, bottom_color=bgmod.GLOW,
                        glow_color=bgmod.GLOW, glow_radius=20 * scale, glow_intensity=150)

    bottom_y = name_top + name_h + geo.name_gap

    caption_parts = []
    if kivani_tag:
        caption_parts.append(f"KivaniCDK · {kivani_tag}")
    if vouches:
        try:
            from config import TRUSTED_SELLER_VOUCHES
        except Exception:
            TRUSTED_SELLER_VOUCHES = 10
        if vouches >= TRUSTED_SELLER_VOUCHES:
            caption_parts.append(f"\u2605 TRUSTED SELLER · {vouches} vouches")
        else:
            caption_parts.append(f"{vouches} vouch{'es' if vouches != 1 else ''}")

    if caption_parts:
        cap_font = load_font(FONT_REGULAR, 15 * scale)
        cap_text = "   ·   ".join(caption_parts)
        cap_h = 24 * scale
        draw_text_centered(base, (0, int(bottom_y), w, int(bottom_y) + cap_h), cap_text, cap_font,
                            fill=bgmod.INK_DIM)
        bottom_y += cap_h

    return int(bottom_y)


def draw_icon_row(base: Image.Image, geo: Geometry, top_y: int, scale: int) -> int:
    """Static brand icon row (Telegram/X/Instagram/Discord/TikTok/Website),
    centered under the wordmark. Returns the y-coordinate of its bottom edge."""
    w, _ = geo.canvas()
    d = geo.icon_d
    gap = geo.icon_gap
    total_w = d * len(FOOTER_BRAND_ICONS) + gap * (len(FOOTER_BRAND_ICONS) - 1)
    start_x = (w - total_w) / 2

    for i, name in enumerate(FOOTER_BRAND_ICONS):
        bx0 = int(start_x + i * (d + gap))
        box = (bx0, int(top_y), bx0 + d, int(top_y) + d)
        btn = draw_glass_button(base, box, scale=scale, tint=(*bgmod.ACCENT, 20), glow_intensity=85)
        base.alpha_composite(btn)
        icon = get_icon(name, size=int(d * 0.46), color=bgmod.INK)
        icon_xy = (box[0] + (d - icon.width) // 2, box[1] + (d - icon.height) // 2)
        base.paste(icon, icon_xy, icon)

    return int(top_y) + d


def _chip_icon_for(label: str, platform: str) -> str | None:
    mapping = {"PLATFORM": platform_to_icon(platform), "LINK": "website"}
    return mapping.get(label)


def draw_info_chips(base: Image.Image, geo: Geometry, chips: list[tuple[str, str]],
                     platform: str, top_y: int, bottom_y: int, scale: int) -> None:
    """Lays out label/value glass chips in a 2-column grid between
    `top_y` and `bottom_y` — the extra info the reference template didn't
    need to show, added on below the brand icon row."""
    x0, x1 = geo.margin, geo.canvas()[0] - geo.margin
    cols = 2 if len(chips) > 1 else 1
    gap = geo.chip_gap
    col_w = (x1 - x0 - gap * (cols - 1)) / cols
    rows = (len(chips) + cols - 1) // cols
    row_gap = 14 * scale
    available = bottom_y - top_y
    max_row_h = geo.chip_row_h
    ideal_block_h = rows * max_row_h + (rows - 1) * row_gap
    if ideal_block_h <= available:
        row_h = max_row_h
        grid_y0 = top_y + (available - ideal_block_h) / 2
    else:
        row_h = (available - row_gap * (rows - 1)) / max(rows, 1)
        grid_y0 = top_y

    label_font = load_font(FONT_REGULAR, 12 * scale)
    default_value_font = load_font(FONT_BOLD, 19 * scale)
    cjk_value_font = None  # loaded lazily — most chips are plain ASCII

    for i, (label, value) in enumerate(chips):
        col, row = i % cols, i // cols
        cx0 = x0 + col * (col_w + gap)
        cy0 = grid_y0 + row * (row_h + row_gap)
        box = (int(cx0), int(cy0), int(cx0 + col_w), int(cy0 + row_h))
        chip = draw_glass_chip(base, box, geo.chip_radius, scale=scale)
        base.alpha_composite(chip)

        icon_name = _chip_icon_for(label, platform)
        pad = 18 * scale
        text_x = box[0] + pad
        if icon_name:
            icon_d = int(row_h * 0.4)
            icon = get_icon(icon_name, size=icon_d, color=bgmod.ACCENT)
            iy = int(box[1] + (row_h - icon_d) / 2)
            base.paste(icon, (int(box[0] + pad), iy), icon)
            text_x = box[0] + pad + icon_d + 12 * scale

        draw_text(base, (text_x, box[1] + 10 * scale), spaced(label, 1), label_font, fill=bgmod.INK_FAINT)
        val = str(value)
        max_chars = 26
        if len(val) > max_chars:
            val = val[: max_chars - 1] + "…"
        value_font = default_value_font
        if needs_cjk_font(val):
            if cjk_value_font is None:
                cjk_value_font = load_font(FONT_CJK, 19 * scale)
            value_font = cjk_value_font
        draw_text(base, (text_x, box[1] + 10 * scale + 18 * scale), val, value_font, fill=bgmod.INK)


def draw_footer(base: Image.Image, geo: Geometry, post_id: str, scale: int) -> None:
    """Bottom strip: full post id (left) + ecosystem tagline (right)."""
    x0, y0, x1, y1 = geo.footer_box()
    tiny_font = load_font(FONT_REGULAR, 12 * scale)
    draw = ImageDraw.Draw(base, "RGBA")
    left_text = f"POST ID  {post_id}"
    draw_text(base, (x0, y0), left_text, tiny_font, fill=bgmod.INK_FAINT)
    right_text = "t.me/twinid"
    rw, _ = text_size(draw, right_text, tiny_font)
    draw_text(base, (x1 - rw, y0), right_text, tiny_font, fill=bgmod.ACCENT)
