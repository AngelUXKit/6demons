"""
TwinIDBot — Shared CPU worker pool
Pillow rendering (ID cards, banners) is CPU-bound and holds the GIL, so it
gets its own ProcessPoolExecutor instead of sharing the DB's I/O thread pool.
This lets multiple users request post images at the same time without
blocking each other or the event loop.
"""
import asyncio
import logging
import multiprocessing
from concurrent.futures import ProcessPoolExecutor

logger = logging.getLogger(__name__)

# Cap workers — image rendering is short-lived, no need to spawn dozens.
_MAX_WORKERS = min(4, max(2, (multiprocessing.cpu_count() or 2)))
_pool: ProcessPoolExecutor | None = None


def get_pool() -> ProcessPoolExecutor:
    global _pool
    if _pool is None:
        _pool = ProcessPoolExecutor(max_workers=_MAX_WORKERS)
        logger.info("Image worker pool started (%d processes)", _MAX_WORKERS)
    return _pool


async def run_cpu(func, *args):
    """
    Run a blocking/CPU-heavy function (e.g. Pillow rendering) in the shared
    process pool without blocking the event loop.
    Falls back to a thread executor if the pool can't spawn a process
    (e.g. restricted/sandboxed environments).
    """
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(get_pool(), func, *args)
    except (OSError, NotImplementedError) as e:
        logger.warning("Process pool unavailable (%s) — falling back to thread executor", e)
        return await loop.run_in_executor(None, func, *args)


def shutdown_pool():
    global _pool
    if _pool is not None:
        _pool.shutdown(wait=False, cancel_futures=True)
        _pool = None
