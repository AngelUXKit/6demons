"""
TwinID Card — Typography
Gradient fills, glow, letter-spacing and centering for text. Every text
draw on the card goes through here so hierarchy stays consistent instead
of ad-hoc draw.text() calls scattered through the orchestrator.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageFilter

_FONT_DIR = Path(__file__).parent.parent / "assets" / "fonts"
FONT_BOLD = str(_FONT_DIR / "Roboto-Bold.ttf")
FONT_REGULAR = str(_FONT_DIR / "Roboto-Regular.ttf")

# Roboto (like most Latin webfonts) has no CJK glyphs at all — a name
# like "零零零零零" rendered with it comes out as empty tofu boxes, not
# an error, so it silently looked "broken" rather than failing loudly.
# Bundled alongside it: a CJK-capable fallback, used only for text that
# actually needs it (detected by Unicode block, not a font capability
# probe — reliable and doesn't need extra dependencies).
FONT_CJK = str(_FONT_DIR / "NotoSansCJK-Regular.ttc")

_CJK_RANGES = (
    (0x3000, 0x303F),    # CJK Symbols and Punctuation
    (0x3040, 0x309F),    # Hiragana
    (0x30A0, 0x30FF),    # Katakana
    (0x3400, 0x4DBF),    # CJK Unified Ideographs Extension A
    (0x4E00, 0x9FFF),    # CJK Unified Ideographs
    (0xAC00, 0xD7A3),    # Hangul Syllables
    (0xF900, 0xFAFF),    # CJK Compatibility Ideographs
    (0xFF00, 0xFFEF),    # Halfwidth and Fullwidth Forms
    (0x20000, 0x2A6DF),  # CJK Unified Ideographs Extension B
)

_FALLBACKS = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)


def needs_cjk_font(text: str) -> bool:
    return any(any(lo <= ord(ch) <= hi for lo, hi in _CJK_RANGES) for ch in text)


def pick_font_path(text: str, bold: bool = False) -> str:
    """Which font file should render this text. Noto Sans CJK also
    covers basic Latin fine, so mixed CJK+Latin strings still come out
    readable through the one font rather than needing per-character
    font-switching mid-string."""
    if needs_cjk_font(text):
        return FONT_CJK
    return FONT_BOLD if bold else FONT_REGULAR


@lru_cache(maxsize=32)
def load_font(path: str, size: int) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        for fb in _FALLBACKS:
            try:
                return ImageFont.truetype(fb, size)
            except Exception:
                continue
        return ImageFont.load_default(size=size)


def spaced(text: str, spacing: int = 1) -> str:
    """Cheap letter-spacing for uppercase labels (real kerning isn't worth it at chip sizes)."""
    if spacing <= 0:
        return text
    return (" " * spacing).join(list(text))


def text_size(draw: ImageDraw.ImageDraw, text: str, font) -> tuple[int, int]:
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


def draw_text(base: Image.Image, xy: tuple[int, int], text: str, font,
              fill=(255, 255, 255), anchor: str | None = None) -> None:
    """Plain draw — kept here so every text call (plain or fancy) has one entry point."""
    ImageDraw.Draw(base, "RGBA").text(xy, text, font=font, fill=fill, anchor=anchor)


def draw_text_centered(base: Image.Image, box: tuple[int, int, int, int], text: str, font,
                        fill=(255, 255, 255)) -> None:
    draw = ImageDraw.Draw(base, "RGBA")
    x0, y0, x1, y1 = box
    tw, th = text_size(draw, text, font)
    x = x0 + (x1 - x0 - tw) / 2
    y = y0 + (y1 - y0 - th) / 2
    draw.text((x, y), text, font=font, fill=fill)


def draw_glow_text(base: Image.Image, xy: tuple[int, int], text: str, font,
                    fill=(255, 255, 255), glow_color=(0x53, 0xFF, 0xE5),
                    glow_radius: float = 10, glow_intensity: int = 160) -> None:
    """Draws soft colored glow behind the text, then the crisp text on top."""
    draw_ref = ImageDraw.Draw(base)
    bbox = draw_ref.textbbox(xy, text, font=font)
    pad = int(glow_radius * 2) + 4
    gx0, gy0 = int(bbox[0]) - pad, int(bbox[1]) - pad
    gw = int(bbox[2] - bbox[0]) + pad * 2
    gh = int(bbox[3] - bbox[1]) + pad * 2
    glow_layer = Image.new("RGBA", (gw, gh), (0, 0, 0, 0))
    ImageDraw.Draw(glow_layer).text((xy[0] - gx0, xy[1] - gy0), text, font=font, fill=(*glow_color, glow_intensity))
    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(glow_radius))
    full = Image.new("RGBA", base.size, (0, 0, 0, 0))
    full.paste(glow_layer, (gx0, gy0), glow_layer)
    base.alpha_composite(full) if base.mode == "RGBA" else base.paste(full, (0, 0), full)
    ImageDraw.Draw(base, "RGBA").text(xy, text, font=font, fill=fill)


def draw_gradient_text(base: Image.Image, xy: tuple[int, int], text: str, font,
                        top_color=(255, 255, 255), bottom_color=(0xAF, 0xC7, 0xC7),
                        glow_color=(0x53, 0xFF, 0xE5), glow_radius: float = 14,
                        glow_intensity: int = 120) -> None:
    """
    Premium hero-text treatment: soft mint glow behind, vertical white -> dim
    gradient fill clipped to the glyph mask on top. Used for the seller name.
    """
    draw_ref = ImageDraw.Draw(base)
    bbox = draw_ref.textbbox((0, 0), text, font=font)
    w = int(bbox[2] - bbox[0]) + 4
    h = int(bbox[3] - bbox[1]) + 4
    if w <= 0 or h <= 0:
        return

    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).text((2 - bbox[0], 2 - bbox[1]), text, font=font, fill=255)

    grad = Image.new("RGB", (1, h))
    for y in range(h):
        t = y / max(h - 1, 1)
        r = int(top_color[0] + (bottom_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bottom_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bottom_color[2] - top_color[2]) * t)
        grad.putpixel((0, y), (r, g, b))
    grad = grad.resize((w, h))

    fill_layer = grad.convert("RGBA")
    fill_layer.putalpha(mask)

    # glow pass, then crisp gradient glyphs on top
    glow_layer = Image.new("RGBA", (w, h), (*glow_color, 0))
    glow_layer.putalpha(mask)
    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(glow_radius))
    glow_alpha = glow_layer.getchannel("A").point(lambda v: int(v * glow_intensity / 255))
    glow_layer.putalpha(glow_alpha)

    dest_x, dest_y = xy[0] + bbox[0] - 2, xy[1] + bbox[1] - 2
    full = Image.new("RGBA", base.size, (0, 0, 0, 0))
    full.paste(glow_layer, (dest_x, dest_y), glow_layer)
    full.paste(fill_layer, (dest_x, dest_y), fill_layer)
    if base.mode != "RGBA":
        base.putalpha(255)
    base.alpha_composite(full)
