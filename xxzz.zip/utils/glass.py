"""
TwinID Card — Glass Primitives
Every translucent surface on the card (panel, pill, chip, button, avatar
ring) is composed from these few reusable builders: blur what's behind the
shape, tint it, stroke a thin cyan edge, drop a top highlight + bottom
shadow, add an outer bloom. No shape draws its own one-off glass code.
"""
from __future__ import annotations

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

from utils import background as bgmod
from utils.effects import (
    outer_glow, rounded_mask_cached, top_highlight_mask, drop_shadow,
)


def _frosted_fill(base_rgba: Image.Image, box: tuple[int, int, int, int], mask: Image.Image,
                   blur: float, brighten: float, tint) -> Image.Image:
    """Crop+blur the backdrop under `box`, brighten it, tint it, clip to `mask`."""
    x0, y0, x1, y1 = box
    crop = base_rgba.crop(box).convert("RGB")
    crop = crop.filter(ImageFilter.GaussianBlur(blur))
    crop = ImageEnhance.Brightness(crop).enhance(brighten)
    glass = crop.convert("RGBA")
    tint_layer = Image.new("RGBA", glass.size, tint)
    glass = Image.alpha_composite(glass, tint_layer)
    glass.putalpha(mask)
    return glass


def draw_glass_shape(base_rgba: Image.Image, box: tuple[int, int, int, int], radius: int,
                      scale: int = 2, tint=bgmod.GLASS_FILL, stroke=bgmod.GLASS_STROKE,
                      stroke_w: int = 2, glow_color=bgmod.GLOW, glow_radius: float = 22,
                      glow_intensity: int = 70, shadow: bool = True) -> Image.Image:
    """
    Core glass builder shared by cards/pills/chips/buttons: outer glow ->
    frosted blur-through fill -> top highlight -> bottom shadow -> stroke.
    Returns an RGBA layer the full size of `base_rgba`, ready to alpha-composite.
    """
    W, H = base_rgba.size
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    mask = rounded_mask_cached(w, h, radius)

    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))

    if glow_intensity > 0:
        glow = outer_glow(mask, glow_color, (W, H), (x0, y0), radius=glow_radius, intensity=glow_intensity)
        out = Image.alpha_composite(out, glow)

    if shadow:
        shad = drop_shadow(mask, (W, H), (x0, y0), dy=int(4 * scale), radius=14 * scale, opacity=90)
        out = Image.alpha_composite(out, shad)

    glass = _frosted_fill(base_rgba, box, mask, blur=16 * scale, brighten=1.18, tint=tint)
    glass_full = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    glass_full.paste(glass, (x0, y0), glass)
    out = Image.alpha_composite(out, glass_full)

    # top sheen — brightest highlight along the upper edge, clipped to shape
    hi_mask = top_highlight_mask((w, h), band=0.5)
    hi_mask = Image.eval(hi_mask, lambda v: int(v * 0.35))
    hi_mask = Image.composite(hi_mask, Image.new("L", (w, h), 0), mask)  # clip to shape
    hi = Image.new("RGBA", (w, h), (*bgmod.INK, 0))
    hi.putalpha(hi_mask)
    hi_full = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    hi_full.paste(hi, (x0, y0), hi)
    out = Image.alpha_composite(out, hi_full)

    # stroke
    if stroke_w > 0:
        stroke_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(stroke_layer)
        d.rounded_rectangle(box, radius=radius, outline=stroke, width=stroke_w)
        out = Image.alpha_composite(out, stroke_layer)

    return out


def draw_glass_card(base_rgba: Image.Image, box: tuple[int, int, int, int], radius: int,
                     scale: int = 2, **kw) -> Image.Image:
    """Large content panel — same builder, generous defaults for the header/body block."""
    kw.setdefault("glow_intensity", 55)
    kw.setdefault("glow_radius", 40 * scale)
    kw.setdefault("stroke_w", max(1, 1 * scale))
    return draw_glass_shape(base_rgba, box, radius, scale=scale, **kw)


def draw_glass_pill(base_rgba: Image.Image, box: tuple[int, int, int, int],
                     scale: int = 2, **kw) -> Image.Image:
    """Fully-rounded pill (radius = half height)."""
    x0, y0, x1, y1 = box
    radius = (y1 - y0) // 2
    kw.setdefault("glow_intensity", 60)
    kw.setdefault("glow_radius", 18 * scale)
    kw.setdefault("stroke_w", max(1, 1 * scale))
    return draw_glass_shape(base_rgba, box, radius, scale=scale, **kw)


def draw_glass_chip(base_rgba: Image.Image, box: tuple[int, int, int, int], radius: int,
                     scale: int = 2, **kw) -> Image.Image:
    """Smaller info chip — same as pill but with a settable corner radius."""
    kw.setdefault("glow_intensity", 45)
    kw.setdefault("glow_radius", 14 * scale)
    kw.setdefault("stroke_w", max(1, 1 * scale))
    return draw_glass_shape(base_rgba, box, radius, scale=scale, **kw)


def draw_glass_button(base_rgba: Image.Image, box: tuple[int, int, int, int],
                       scale: int = 2, **kw) -> Image.Image:
    """Circular action/icon button (footer social row)."""
    x0, y0, x1, y1 = box
    radius = (y1 - y0) // 2
    kw.setdefault("glow_intensity", 80)
    kw.setdefault("glow_radius", 16 * scale)
    kw.setdefault("stroke_w", max(1, 1 * scale))
    return draw_glass_shape(base_rgba, box, radius, scale=scale, **kw)


def draw_glass_circle(base_rgba: Image.Image, center: tuple[int, int], radius: int,
                       scale: int = 2, **kw) -> Image.Image:
    """Circular glass surface (used as the avatar's outer ring backdrop)."""
    box = (center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius)
    kw.setdefault("glow_intensity", 90)
    kw.setdefault("glow_radius", 30 * scale)
    kw.setdefault("stroke_w", max(1, 2 * scale))
    return draw_glass_shape(base_rgba, box, radius, scale=scale, **kw)
