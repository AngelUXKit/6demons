"""
TwinID Card — Icon Glyphs
Minimal monoline glyph set for the footer/platform row (Telegram, Instagram,
Discord, TikTok, X, Website, Fragment, TON, Solana, Ethereum, BTC).

Icons are procedurally drawn vector shapes (no bundled binary logo assets,
no network fetch) — abstracted, single-color glyphs in the card's own
accent style rather than literal brand marks. Rendered once per (name,
size, color) and cached; also exported as PNGs under assets/icons/ via
`export_icon_set()` for reference/reuse outside the renderer.
"""
from __future__ import annotations

import math
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw

ICON_DIR = Path(__file__).parent.parent / "assets" / "icons"

_GLYPHS = (
    "telegram", "instagram", "discord", "tiktok", "x", "website",
    "fragment", "ton", "solana", "ethereum", "btc",
)


def _canvas(size: int) -> tuple[Image.Image, ImageDraw.ImageDraw]:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def _telegram(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    pts = [(s * 0.12, s * 0.52), (s * 0.88, s * 0.16), (s * 0.62, s * 0.86),
           (s * 0.48, s * 0.62), (s * 0.30, s * 0.72)]
    d.line([pts[0], pts[1]], fill=color, width=max(2, s // 12), joint="curve")
    d.polygon([pts[1], pts[2], pts[3]], fill=color)
    d.polygon([pts[0], pts[1], pts[4]], fill=color)
    d.polygon([(s * 0.30, s * 0.72), (s * 0.48, s * 0.62), (s * 0.40, s * 0.90)], fill=color)
    return img


def _instagram(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(2, s // 12)
    d.rounded_rectangle([s * 0.14, s * 0.14, s * 0.86, s * 0.86], radius=s * 0.24, outline=color, width=w)
    r = s * 0.19
    cx = cy = s * 0.5
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=w)
    dotr = s * 0.045
    d.ellipse([s * 0.68 - dotr, s * 0.24 - dotr, s * 0.68 + dotr, s * 0.24 + dotr], fill=color)
    return img


def _discord(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    d.rounded_rectangle([s * 0.10, s * 0.30, s * 0.90, s * 0.72], radius=s * 0.22, outline=color, width=max(2, s // 12))
    er = s * 0.075
    d.ellipse([s * 0.34 - er, s * 0.46 - er, s * 0.34 + er, s * 0.46 + er], fill=color)
    d.ellipse([s * 0.66 - er, s * 0.46 - er, s * 0.66 + er, s * 0.46 + er], fill=color)
    d.line([(s * 0.30, s * 0.30), (s * 0.24, s * 0.16)], fill=color, width=max(2, s // 14))
    d.line([(s * 0.70, s * 0.30), (s * 0.76, s * 0.16)], fill=color, width=max(2, s // 14))
    return img


def _tiktok(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(2, s // 11)
    d.arc([s * 0.42, s * 0.14, s * 0.86, s * 0.58], start=300, end=90, fill=color, width=w)
    d.line([(s * 0.64, s * 0.18), (s * 0.64, s * 0.66)], fill=color, width=w)
    r = s * 0.16
    d.arc([s * 0.32, s * 0.50, s * 0.32 + r * 2, s * 0.50 + r * 2], start=0, end=360, fill=color, width=w)
    return img


def _x(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(3, s // 8)
    pad = s * 0.20
    d.line([(pad, pad), (s - pad, s - pad)], fill=color, width=w)
    d.line([(s - pad, pad), (pad, s - pad)], fill=color, width=w)
    return img


def _website(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(2, s // 14)
    d.ellipse([s * 0.14, s * 0.14, s * 0.86, s * 0.86], outline=color, width=w)
    d.line([(s * 0.5, s * 0.14), (s * 0.5, s * 0.86)], fill=color, width=w)
    d.line([(s * 0.14, s * 0.5), (s * 0.86, s * 0.5)], fill=color, width=w)
    d.ellipse([s * 0.32, s * 0.14, s * 0.68, s * 0.86], outline=color, width=w)
    return img


def _fragment(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    d.polygon([(s * 0.5, s * 0.10), (s * 0.85, s * 0.5), (s * 0.5, s * 0.90), (s * 0.15, s * 0.5)],
               outline=color, width=max(2, s // 12))
    return img


def _ton(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(2, s // 12)
    d.ellipse([s * 0.10, s * 0.10, s * 0.90, s * 0.90], outline=color, width=w)
    d.polygon([(s * 0.32, s * 0.36), (s * 0.68, s * 0.36), (s * 0.5, s * 0.72)], outline=color, width=max(2, s // 16))
    return img


def _solana(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    bar_h = s * 0.11
    for i, skew in enumerate((0.0, 0.12, -0.12)):
        y = s * (0.28 + i * 0.24)
        offset = skew * s
        d.polygon([
            (s * 0.16 + offset, y), (s * 0.84 + offset, y),
            (s * 0.84 - offset, y + bar_h), (s * 0.16 - offset, y + bar_h),
        ], fill=color)
    return img


def _ethereum(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    top = (s * 0.5, s * 0.08)
    mid_l = (s * 0.18, s * 0.52)
    mid_r = (s * 0.82, s * 0.52)
    bot = (s * 0.5, s * 0.92)
    mid = (s * 0.5, s * 0.60)
    w = max(2, s // 16)
    d.line([top, mid_l, mid, top], fill=color, width=w, joint="curve")
    d.line([top, mid_r, mid, top], fill=color, width=w, joint="curve")
    d.line([mid_l, bot, mid_r], fill=color, width=w, joint="curve")
    return img


def _btc(size: int, color) -> Image.Image:
    img, d = _canvas(size)
    s = size
    w = max(2, s // 14)
    d.ellipse([s * 0.10, s * 0.10, s * 0.90, s * 0.90], outline=color, width=w)
    from utils.typography import load_font
    f = load_font(str(Path(__file__).parent.parent / "assets" / "fonts" / "Roboto-Bold.ttf"), int(s * 0.44))
    bbox = d.textbbox((0, 0), "\u0243", font=f)
    d.text((s * 0.5 - (bbox[2] - bbox[0]) / 2 - bbox[0], s * 0.5 - (bbox[3] - bbox[1]) / 2 - bbox[1]),
           "\u0243", font=f, fill=color)
    return img


_BUILDERS = {
    "telegram": _telegram, "instagram": _instagram, "discord": _discord,
    "tiktok": _tiktok, "x": _x, "website": _website, "fragment": _fragment,
    "ton": _ton, "solana": _solana, "ethereum": _ethereum, "btc": _btc,
}


@lru_cache(maxsize=128)
def get_icon(name: str, size: int = 64, color: tuple[int, int, int] = (255, 255, 255)) -> Image.Image:
    """Return a cached RGBA glyph for `name` at `size`px, tinted `color`."""
    builder = _BUILDERS.get(name)
    if builder is None:
        return _website(size, color)  # generic fallback glyph
    return builder(size, color)


def platform_to_icon(platform: str) -> str:
    """Map a listing's sold-account `platform` label to a footer glyph name."""
    p = (platform or "").strip().lower()
    table = {
        "telegram": "telegram", "instagram": "instagram", "discord": "discord",
        "x (twitter)": "x", "twitter": "x", "tiktok": "tiktok",
        "ton gifts": "ton", "nft": "ethereum",
    }
    return table.get(p, "website")


def export_icon_set(size: int = 256) -> None:
    """
    One-time helper: renders the full glyph set to assets/icons/*.png so the
    icon set also exists as standalone files (matches the project's asset
    layout). Not called at request time — the renderer draws icons in-memory.
    """
    ICON_DIR.mkdir(parents=True, exist_ok=True)
    for name in _GLYPHS:
        img = get_icon(name, size=size, color=(255, 255, 255))
        img.save(ICON_DIR / f"{name}.png")
    # aliases referenced in the original asset list
    get_icon("telegram", size=size, color=(255, 255, 255)).save(ICON_DIR / "telegram_logo.png")


if __name__ == "__main__":
    export_icon_set()
