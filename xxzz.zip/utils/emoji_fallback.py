"""
TwinIDBot — Premium-emoji fallback middleware
────────────────────────────────────────────────────────────────────────
ROOT CAUSE (the "DOCUMENT_INVALID" crash)
Telegram treats custom emoji as a special kind of document internally.
Per the Bot API docs, <tg-emoji>/icon_custom_emoji_id entities can only
be used in messages sent DIRECTLY by a bot when:
    • the bot's OWNER account has an active Telegram Premium subscription, OR
    • the bot has purchased an extra username on Fragment.
This is a property of the SENDING BOT ACCOUNT — it has nothing to do with
whether the person the bot is messaging has Premium or not. That's why
testing from a Premium user account vs a non-Premium user account looked
inconsistent: the recipient's Premium status was never the deciding
factor. If the bot owner's Premium lapses (or was never active), every
single send/edit that includes a custom emoji ID will fail with:
    aiogram.exceptions.TelegramBadRequest: Bad Request: DOCUMENT_INVALID
even though the emoji IDs themselves (utils/ui.py) are perfectly valid.

THE FIX
Rather than hard-coding a workaround into every handler that calls
pemoji()/ibtn()/main_keyboard() (there are dozens across the codebase),
this middleware hooks the bot's HTTP session once. Whenever Telegram
rejects a request because of a custom emoji, it transparently retries
the *exact same* call with the <tg-emoji> tags unwrapped to their plain
Unicode fallback and icon_custom_emoji_id stripped from any keyboard
buttons. Handlers, and the emoji IDs in utils/ui.py, don't need to
change at all — the premium emoji keep being used the moment the bot
owner's Premium/Fragment eligibility is active again, and gracefully
degrade to normal emoji whenever it isn't, instead of crashing.
"""
import logging
import re

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import InlineKeyboardMarkup, ReplyKeyboardMarkup

logger = logging.getLogger(__name__)

# Substrings Telegram uses for a rejected custom-emoji document.
_EMOJI_ERROR_MARKERS = ("DOCUMENT_INVALID", "CUSTOM_EMOJI", "EMOJI_INVALID")

_TG_EMOJI_RE = re.compile(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>')


def _strip_text(value: str | None) -> str | None:
    """Unwrap <tg-emoji emoji-id="...">X</tg-emoji> down to plain X."""
    if not value or "<tg-emoji" not in value:
        return value
    return _TG_EMOJI_RE.sub(r"\1", value)


def _strip_markup(markup):
    """Return a copy of the markup with icon_custom_emoji_id cleared."""
    if isinstance(markup, InlineKeyboardMarkup):
        return InlineKeyboardMarkup(inline_keyboard=[
            [btn.model_copy(update={"icon_custom_emoji_id": None}) for btn in row]
            for row in markup.inline_keyboard
        ])
    if isinstance(markup, ReplyKeyboardMarkup):
        return markup.model_copy(update={
            "keyboard": [
                [btn.model_copy(update={"icon_custom_emoji_id": None}) for btn in row]
                for row in markup.keyboard
            ]
        })
    return markup


def _is_emoji_error(exc: TelegramBadRequest) -> bool:
    text = str(exc)
    return any(marker in text for marker in _EMOJI_ERROR_MARKERS)


class PremiumEmojiFallbackMiddleware:
    """Bot-session middleware: retry once with custom emoji stripped."""

    async def __call__(self, make_request, bot, method):
        try:
            return await make_request(bot, method)
        except TelegramBadRequest as exc:
            if not _is_emoji_error(exc):
                raise

            update = {}
            text = getattr(method, "text", None)
            if text:
                stripped = _strip_text(text)
                if stripped != text:
                    update["text"] = stripped

            caption = getattr(method, "caption", None)
            if caption:
                stripped = _strip_text(caption)
                if stripped != caption:
                    update["caption"] = stripped

            markup = getattr(method, "reply_markup", None)
            if markup is not None:
                update["reply_markup"] = _strip_markup(markup)

            if not update:
                # Nothing custom-emoji-related to strip — a genuinely
                # different bad request, so don't mask it.
                raise

            logger.warning(
                "Telegram rejected a custom emoji on %s (DOCUMENT_INVALID). "
                "This means the bot owner's Telegram Premium subscription "
                "has lapsed (or no Fragment username is attached to this "
                "bot) — it is NOT related to the recipient's Premium "
                "status. Falling back to plain emoji for this message; "
                "premium emoji will resume automatically once the bot "
                "owner's eligibility is restored.",
                type(method).__name__,
            )
            fallback_method = method.model_copy(update=update)
            return await make_request(bot, fallback_method)
