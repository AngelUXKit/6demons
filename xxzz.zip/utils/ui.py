"""
TwinIDBot — Shared UI helpers
Emojis, keyboard factories, HTML builders, validation utilities.
"""
import re
from html import escape
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton,
)

HTML = "HTML"

# ── Custom emoji tuples (emoji_id, fallback_unicode) ──────────────────
# Real IDs pulled live from the @TwinID5 pack via getStickerSet, matched
# to grid position (upload order == picker order). Every constant now
# has its OWN id — no more sharing (the old file had E_STAR/E_CHECK on
# one id, E_CROSS/E_BACK on another, three different "+" concepts all
# on E_NEWPOST's id — that's gone now).
E_BELL      = ("5985686884376911827",  "🔔")
E_BOLT      = ("5985698094241554158",  "⚡")
E_CROWN     = ("5985721068021620799",  "👑")
E_FACEBOOK  = ("5983526533006893561",  "📘")
E_FIRE      = ("5985774149522432009",  "🔥")
E_PAW       = ("5985676430426513108",  "🐾")
E_GOOGLE    = ("5985384248096333380",  "🔍")
E_IDCARD    = ("5985628704749919939",  "🪪")

E_KEY       = ("5985420510505214654",  "🔑")
E_CHAT      = ("5985755934566129396",  "💬")
E_GRID      = ("5985779462396976274",  "▦")
E_NFT       = ("5985450510851775506",  "🖼️")
E_VERIFIED  = ("5985404666370857829",  "✅")
E_PENCIL    = ("5985388946790555560",  "✏️")
E_PHONE     = ("5985768024899069826",  "📞")
E_TAG       = ("5985520389969682352",  "🏷️")

E_SHIELD    = ("5985431956593056738",  "🛡️")
E_AT        = ("5985809544347917374",  "📧")
E_TIKTOK    = ("5985287559792565989",  "🎶")
E_DIAMOND   = ("5985391532360867998",  "💎")
E_QUOTE     = ("5985699760688864380",  "💭")
E_X         = ("5985767286164691504",  "✖️")
E_YOUTUBE   = ("5985728906336935258",  "▶️")
E_SNAP      = ("5983416745052872044",  "👻")

E_DISCORD   = ("5985433408292003320",  "🎮")
E_INSTA     = ("5985718731559411471",  "📸")
E_REDDIT    = ("5985341401502587914",  "🔴")
E_SPOTIFY   = ("5985581636203322601",  "🎵")
E_SEND      = ("5985422005153832178",  "📤")
E_REFRESH   = ("5985601775304973930",  "🔄")
E_CROSS     = ("5983040278284475859",  "❌")
E_CHECK     = ("5983451508518165959",  "✅")

E_BACK      = ("5985843371510341256",  "◀️")
E_USER      = ("5985484217755114910",  "👤")
E_TROPHY    = ("5983542840997715024",  "🏆")
E_STAR      = ("5983204410459692652",  "⭐")
E_GIFT      = ("5983589097795494041",  "🎁")
E_CUSTOM    = ("5983386465533435293",  "✏️")
E_TON       = ("5985789538390253567",  "🔸")
E_NEWPOST   = ("5983396309598478263",  "➕")

# Spares — 2 extra icons your screenshot didn't show (there was more
# below the fold, per the scrollbar). Tell me what these actually are
# and I'll rename/reassign them properly.
E_ADD       = ("5985771095800684251",  "➕")   # guess: general "add" action
E_SPARE1    = ("5985348187550915913",  "❔")   # unconfirmed

# Platform brand icons NOT in the @TwinID5 pack — left exactly as they
# were, untouched.
E_TELE      = ("5985422005153832178",  "📨")
E_ONLYFANS  = ("5985404666370857829",  "🔞")
E_TWITCH    = ("5985699760688864380",  "🎙️")
E_THREADS   = ("5985809544347917374",  "🧵")
E_GITHUB    = ("5985676430426513108",  "🐙")
E_MICROSOFT = ("5985779462396976274",  "🪟")
E_CLOUD     = ("5985420510505214654",  "☁️")

# Aliases — kept only where the codebase needs the name but the pack
# has no separate icon for it; each now points to a real, matched id
# instead of an unrelated one like the old file did.
E_PRICE     = E_GIFT
E_KIVAN     = E_CHAT
E_MESSAGE   = E_CHAT
E_TOPUP     = E_ADD
E_INBOX     = E_ADD
E_ID        = E_IDCARD
E_PLUS888   = E_ADD

PLATFORMS = [
    ("Telegram",    E_TELE),
    ("Instagram",   E_INSTA),
    ("Snapchat",    E_SNAP),
    ("Discord",     E_DISCORD),
    ("Reddit",      E_REDDIT),
    ("Spotify",     E_SPOTIFY),
    ("Google",      E_GOOGLE),
    ("X (Twitter)", E_X),
    ("OnlyFans",    E_ONLYFANS),
    ("Twitch",      E_TWITCH),
    ("Facebook",    E_FACEBOOK),
    ("Threads",     E_THREADS),
    ("GitHub",      E_GITHUB),
    ("Microsoft",   E_MICROSOFT),
    ("Cloud",       E_CLOUD),
    ("TikTok",      E_TIKTOK),
    ("+888 Numbers",E_PLUS888),
    ("TON Gifts",   E_TON),
    ("NFT",         E_NFT),
    ("Other",       E_TROPHY),
]

# ── Emoji renderer ────────────────────────────────────────────────────

def pemoji(et: tuple) -> str:
    eid, char = et
    return f'<tg-emoji emoji-id="{eid}">{char}</tg-emoji>'


# ── Button factories ──────────────────────────────────────────────────

def ibtn(label: str, cb: str, et: tuple | None = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(
        text=label,
        callback_data=cb,
        icon_custom_emoji_id=et[0] if et else None,
    )


def url_btn(label: str, url: str, et: tuple | None = None, style: str | None = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(
        text=label,
        url=url,
        icon_custom_emoji_id=et[0] if et else None,
        style=style,
    )


def _contact_target(seller_username: str, contact: str) -> tuple[str, str] | None:
    """Resolve the best tappable contact link + display handle.
    Prefers the listing's own `contact` field (handle or URL); falls
    back to the seller's Telegram username. Returns None if there's
    truly nothing to link to."""
    raw = (contact or "").strip()
    if raw:
        if raw.startswith("http://") or raw.startswith("https://"):
            display = raw.split("/")[-1] or raw
            return raw, f"@{display}" if not display.startswith("@") else display
        handle = raw.lstrip("@")
        return f"https://t.me/{handle}", f"@{handle}"
    seller = (seller_username or "").strip().lstrip("@")
    if seller:
        return f"https://t.me/{seller}", f"@{seller}"
    return None


def kb_contact(seller_username: str, contact: str = "") -> InlineKeyboardMarkup | None:
    """A single-button keyboard: 'Contact - @username', styled green
    (Bot API 9.4 button colors — style='success'). Attached to every
    channel post so buyers have one tap straight to the seller. Returns
    None when there's no seller/contact to link to (channel post then
    just ships without a keyboard)."""
    target = _contact_target(seller_username, contact)
    if not target:
        return None
    url, handle = target
    return InlineKeyboardMarkup(inline_keyboard=[[
        url_btn(f"Contact - {handle}", url, E_PHONE, style="success"),
    ]])


def kb_promo(target: str = "") -> InlineKeyboardMarkup:
    """Promote Ads / Ads of the Day button — the poster can point it at
    their own channel/@username instead of always being 'Contact -
    seller'. If they skip it, defaults to 'Ads - @Twinid' pointing
    back at the TwinID channel itself, same green style as Contact."""
    raw = (target or "").strip()
    if raw:
        if raw.startswith("http://") or raw.startswith("https://"):
            url = raw
            tail = raw.rstrip("/").split("/")[-1]
            handle = tail if tail.startswith("@") else f"@{tail}"
        else:
            handle = f"@{raw.lstrip('@')}"
            url = f"https://t.me/{handle.lstrip('@')}"
        label = f"Ads - {handle}"
    else:
        url, label = "https://t.me/twinid", "Ads - @Twinid"
    return InlineKeyboardMarkup(inline_keyboard=[[
        url_btn(label, url, E_FIRE, style="success"),
    ]])


TELEGRAM_CAPTION_LIMIT = 1024  # Telegram's photo-caption cap (vs 4096 for text messages)


async def send_post(bot, chat_id, text: str, *, photo=None, reply_markup=None, parse_mode: str = HTML, **kw):
    """
    Send a post that may optionally carry an image. No `photo` -> a
    plain text message, same as before. With `photo` (a file_id,
    URL, or InputFile) -> sent as a photo with `text` as its caption
    — unless `text` is too long to fit in Telegram's 1024-char photo
    caption limit, in which case the photo ships on its own and a
    separate text message immediately follows with the full content
    and the reply markup, so nothing is silently truncated or
    rejected by Telegram.
    """
    if photo is None:
        return await bot.send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup, **kw)
    if len(text) <= TELEGRAM_CAPTION_LIMIT:
        return await bot.send_photo(chat_id, photo, caption=text, parse_mode=parse_mode, reply_markup=reply_markup, **kw)
    await bot.send_photo(chat_id, photo, **kw)
    return await bot.send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup)


# ── HTML helpers ──────────────────────────────────────────────────────

def esc(s) -> str:     return escape(str(s))
def bold(s: str) -> str:   return f"<b>{esc(s)}</b>"
def italic(s: str) -> str: return f"<i>{esc(s)}</i>"
def code(s: str) -> str:   return f"<code>{esc(s)}</code>"
def quote(s: str) -> str:  return f"<blockquote>{esc(s)}</blockquote>"
def link(label: str, url: str) -> str:
    return f'<a href="{esc(url)}">{esc(label)}</a>'
def mention(username: str) -> str:
    h = username.lstrip("@")
    return f'<a href="https://t.me/{esc(h)}">@{esc(h)}</a>'


async def is_group_admin(bot, chat_id: int, user_id: int) -> bool:
    """True if user_id is a creator/administrator of chat_id. Used by
    the moderation module, where 'admin' means admin of that specific
    group — a different, per-chat notion from ADMIN_ID (the single
    bot owner checked in handlers/admin.py)."""
    try:
        member = await bot.get_chat_member(chat_id, user_id)
    except Exception:
        return False
    return member.status in ("creator", "administrator")


def mention_user(user) -> str:
    """Mention by tg://user?id= — works even for users with no public
    @username, unlike mention() above which needs one."""
    name = esc(user.full_name)
    return f'<a href="tg://user?id={user.id}">{name}</a>'


MAX_DELETE_BATCH = 100  # Telegram's deleteMessages hard cap per call


async def bulk_delete(bot, chat_id, message_ids: list[int]) -> int:
    """Delete up to len(message_ids) messages, chunked into batches of
    100 (Telegram's limit for deleteMessages). Missing/already-deleted
    IDs are silently skipped by Telegram, not errors. Returns the
    number of IDs submitted for deletion."""
    import asyncio as _asyncio
    deleted = 0
    for i in range(0, len(message_ids), MAX_DELETE_BATCH):
        chunk = message_ids[i:i + MAX_DELETE_BATCH]
        try:
            await bot.delete_messages(chat_id, chunk)
            deleted += len(chunk)
        except Exception:
            for mid in chunk:
                try:
                    await bot.delete_message(chat_id, mid)
                    deleted += 1
                except Exception:
                    pass
        await _asyncio.sleep(0.05)
    return deleted


async def delete_after(bot, chat_id, message_id: int, seconds: float):
    """Fire-and-forget: delete a message after a delay — used for
    ephemeral moderation notices."""
    import asyncio as _asyncio
    await _asyncio.sleep(seconds)
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass


# ── Validation ────────────────────────────────────────────────────────

def clean_handle(raw: str) -> str:
    return raw.strip().lstrip("@")

def is_valid_handle(raw: str) -> bool:
    return bool(re.fullmatch(r"[a-zA-Z0-9_]{1,64}", clean_handle(raw)))

def clean_price(raw: str) -> str:
    return raw.strip().lstrip("$").replace(",", "").strip()

def is_valid_price(raw: str) -> bool:
    try:   return float(clean_price(raw)) > 0
    except: return False

def is_valid_url(raw: str) -> bool:
    return bool(re.match(r"https?://\S+\.\S+", raw.strip()))

def fmt_price(raw: str) -> str:
    try:   return f"${int(float(raw)):,}"
    except: return f"${raw}"

def usd(c: int) -> str:
    return f"${c / 1000:.2f}"

def is_valid_kivani_tag(raw: str) -> bool:
    """twin followed by exactly 3 digits, e.g. twin001"""
    return bool(re.fullmatch(r"twin\d{3}", raw.strip().lower()))

def get_plat_emoji(label: str) -> tuple:
    for name, et in PLATFORMS:
        if name == label:
            return et
    return E_TROPHY


# ── Keyboards ────────────────────────────────────────────────────────

BTN_BALANCE  = "Balance"
BTN_TOPUP    = "Top Up"
BTN_SEND     = "Send"
BTN_POST     = "New Post"
BTN_MANAGE   = "Manage Posts"
BTN_HELP     = "Ping"
BTN_KIVANI   = "Kivani Inbox"
BTN_GIFTS    = "Gifts & NFTs"

ESCAPE_TEXTS = {BTN_BALANCE, BTN_TOPUP, BTN_SEND, BTN_POST, BTN_MANAGE, BTN_HELP, BTN_KIVANI, BTN_GIFTS}


def main_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text=BTN_BALANCE, icon_custom_emoji_id=E_STAR[0]),
                KeyboardButton(text=BTN_TOPUP,   icon_custom_emoji_id=E_BOLT[0]),
            ],
            [
                KeyboardButton(text=BTN_POST,    icon_custom_emoji_id=E_NEWPOST[0]),
                KeyboardButton(text=BTN_SEND,    icon_custom_emoji_id=E_SEND[0]),
            ],
            [
                KeyboardButton(text=BTN_KIVANI,  icon_custom_emoji_id=E_MESSAGE[0]),
                KeyboardButton(text=BTN_GIFTS,   icon_custom_emoji_id=E_GIFT[0]),
            ],
            [
                KeyboardButton(text=BTN_MANAGE,  icon_custom_emoji_id=E_TROPHY[0]),
                KeyboardButton(text=BTN_HELP,    icon_custom_emoji_id=E_STAR[0]),
            ],
        ],
        resize_keyboard=True,
        persistent=True,
    )


def kb_cancel_only() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[ibtn("Cancel", "cancel", E_CROSS)]])


def kb_back_cancel(back_cb: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("Back",   back_cb,  E_BACK),
        ibtn("Cancel", "cancel", E_CROSS),
    ]])


def kb_platforms(prefix: str = "platform") -> InlineKeyboardMarkup:
    rows, row = [], []
    for label, et in PLATFORMS:
        row.append(InlineKeyboardButton(
            text=label, callback_data=f"{prefix}:{label}",
            icon_custom_emoji_id=et[0],
        ))
        if len(row) == 2:
            rows.append(row); row = []
    if row:
        rows.append(row)
    rows.append([ibtn("Back", f"back:mode_from_{prefix}", E_BACK), ibtn("Cancel", "cancel", E_CROSS)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ── Send helpers ──────────────────────────────────────────────────────

async def send(target, text: str, **kw):
    await target.bot.send_message(target.chat.id, text, parse_mode=HTML, **kw)


async def edit(target, text: str, **kw):
    """
    Edit a message in place — text body for text messages, caption for
    photo/video/document messages.

    Telegram's edit_text() only works on messages that have a text
    body. A photo message (like the ID-card preview/confirm screens
    for template 4) only has a *caption* — calling edit_text() on it
    fails with "there is no text in the message to edit". Rather than
    have every handler across the codebase remember which screens might
    be photos and branch accordingly, that decision lives here once:
    edit() inspects the target and calls the right API, and if editing
    genuinely isn't possible for some other reason, falls back to
    deleting the old message and sending a fresh one so the user always
    gets their new text instead of a silent crash.
    """
    is_media = bool(getattr(target, "photo", None) or getattr(target, "video", None)
                     or getattr(target, "document", None) or getattr(target, "animation", None))
    try:
        if is_media:
            await target.edit_caption(caption=text, parse_mode=HTML, **kw)
        else:
            await target.edit_text(text, parse_mode=HTML, **kw)
        return
    except TelegramBadRequest as e:
        if "message is not modified" in str(e):
            return  # identical content — not an error, nothing to do
        # Last resort: delete the old message and send a fresh text one
        # instead of crashing the update.
        try:
            await target.delete()
        except Exception:
            pass
        await target.bot.send_message(target.chat.id, text, parse_mode=HTML, **kw)


# ── No-access & common error messages ────────────────────────────────

def msg_no_access(user_id: int) -> str:
    return (
        f"{pemoji(E_SHIELD)}  {bold('Access Required')}\n\n"
        f"Your Telegram ID: {code(str(user_id))}\n\n"
        f"Send /start to register, or contact {link('@mvpzy','https://t.me/mvpzy')}."
    )


def msg_low_credits(bal: int, needed: int) -> str:
    return (
        f"{pemoji(E_GIFT)}  {bold('Insufficient Credits')}\n\n"
        f"Cost:  {bold(usd(needed))}  ({needed} credits)\n"
        f"Your balance:  {bold(usd(bal))}  ({bal} credits)\n\n"
        f"Top up via  {link('@mvpzy','https://t.me/mvpzy')}"
    )


def msg_invalid_input(field: str, hint: str) -> str:
    return f"{pemoji(E_CROSS)}  {bold('Invalid ' + field)}\n\n{esc(hint)}"