"""
TwinID Card — Layout
Every position, size and spacing constant lives here so id_card.py and
components.py never hardcode a pixel number inline. Everything is defined
in "logical" 1200x630 units and multiplied by `scale` at render time.

Composition (matches the approved reference: centered avatar -> flanking
handle/brand pills -> centered glow wordmark -> small caption -> footer
brand-icon row -> info-chip grid -> post-id footer strip):

    ┌──────────────────────────────────────────────┐
    │                    [avatar]                   │  <- centered, top
    │ [@handle pill]                 [Twin.ID pill] │  <- flanks avatar
    │                 Seller Name                    │  <- gradient glow text
    │              (kivani / vouches)                │  <- small caption
    │        (o)  (o)  (o)  (o)  (o)  (o)            │  <- brand icon row
    │  ┌────────────┐  ┌────────────┐                │
    │  │   chip 1   │  │   chip 2   │  ...           │  <- info chip grid
    │  └────────────┘  └────────────┘                │
    │  POST ID •••                 TwinID Ecosystem  │  <- footer strip
    └──────────────────────────────────────────────┘
"""
from __future__ import annotations

from dataclasses import dataclass, field

CARD_W, CARD_H = 1200, 630


@dataclass(frozen=True)
class Geometry:
    scale: int

    margin: int = field(init=False)
    card_radius: int = field(init=False)

    # avatar (centered, top of card)
    avatar_d: int = field(init=False)
    avatar_top: int = field(init=False)

    # flanking pills (same vertical center as the avatar)
    pill_h: int = field(init=False)
    pill_max_w: int = field(init=False)

    # centered wordmark + caption
    name_gap: int = field(init=False)
    caption_gap: int = field(init=False)

    # brand icon row
    icon_d: int = field(init=False)
    icon_gap: int = field(init=False)
    icon_row_gap: int = field(init=False)

    # info chip grid
    chip_gap: int = field(init=False)
    chip_radius: int = field(init=False)
    chip_row_h: int = field(init=False)
    chips_top_gap: int = field(init=False)

    # footer strip
    footer_h: int = field(init=False)

    def __post_init__(self):
        s = self.scale
        object.__setattr__(self, "margin", 50 * s)
        object.__setattr__(self, "card_radius", 30 * s)

        object.__setattr__(self, "avatar_d", 122 * s)
        object.__setattr__(self, "avatar_top", 34 * s)

        object.__setattr__(self, "pill_h", 34 * s)
        object.__setattr__(self, "pill_max_w", 300 * s)

        object.__setattr__(self, "name_gap", 14 * s)
        object.__setattr__(self, "caption_gap", 6 * s)

        object.__setattr__(self, "icon_d", 46 * s)
        object.__setattr__(self, "icon_gap", 12 * s)
        object.__setattr__(self, "icon_row_gap", 18 * s)

        object.__setattr__(self, "chip_gap", 16 * s)
        object.__setattr__(self, "chip_radius", 16 * s)
        object.__setattr__(self, "chip_row_h", 68 * s)
        object.__setattr__(self, "chips_top_gap", 20 * s)

        object.__setattr__(self, "footer_h", 58 * s)

    def canvas(self) -> tuple[int, int]:
        return CARD_W * self.scale, CARD_H * self.scale

    def avatar_center(self) -> tuple[int, int]:
        w, _ = self.canvas()
        return int(w / 2), int(self.avatar_top + self.avatar_d / 2)

    def pill_cy(self) -> int:
        return self.avatar_center()[1]

    def name_top(self) -> int:
        return int(self.avatar_top + self.avatar_d + self.name_gap)

    def footer_box(self) -> tuple[int, int, int, int]:
        w, h = self.canvas()
        return (self.margin, h - self.footer_h, w - self.margin, h - int(16 * self.scale))
