"""
TwinID Card — Background Layer
Builds the dark cyber-glass backdrop: vertical gradient, dot grid,
film noise, radial ambient glow(s) and an outer vignette.

Pure Pillow, no shared state — safe to run inside the worker process pool.
"""
from __future__ import annotations

import os
import random
from functools import lru_cache

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

# The reference backdrop supplied directly by the user — used as the real
# base layer instead of the old fully-procedural gradient. Lives at
# assets/backgrounds/board.png (repo-root-relative, two levels up from
# this file: utils/background.py -> utils -> repo root -> assets/...).
_ASSET_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "backgrounds")
BOARD_IMAGE_PATH = os.path.join(_ASSET_DIR, "board.png")

# ── Palette ──────────────────────────────────────────────────────────────
# Background wash (top -> mid -> bottom)
BG_TOP    = (0x02, 0x0F, 0x10)
BG_MID    = (0x01, 0x2D, 0x29)
BG_BOTTOM = (0x00, 0x5A, 0x4F)

ACCENT      = (0x00, 0xFF, 0xD5)   # #00FFD5 — cyan accent
GLOW        = (0x53, 0xFF, 0xE5)   # #53FFE5 — soft mint glow
INK         = (255, 255, 255)      # primary text
INK_DIM     = (0xAF, 0xC7, 0xC7)   # secondary text
INK_FAINT   = (0x73, 0x86, 0x86)   # muted text
GOLD        = (240, 190, 90)       # exclusive accent

GLASS_STROKE  = (*ACCENT, 90)
GLASS_FILL    = (12, 30, 30, 92)
GLASS_HILITE  = (255, 255, 255, 60)
GLASS_SHADOW  = (0, 0, 0, 110)


def _lerp(a: int, b: int, t: float) -> int:
    return int(a + (b - a) * t)


@lru_cache(maxsize=8)
def vertical_gradient(w: int, h: int, top=BG_TOP, mid=BG_MID, bottom=BG_BOTTOM) -> Image.Image:
    """Three-stop vertical gradient wash (cached — identical for every render at a given size).
    Built as a single-pixel-wide column with numpy, then tiled across the width —
    orders of magnitude faster than setting each of w*h pixels from Python."""
    t = np.linspace(0.0, 1.0, h, dtype=np.float64)
    top_a, mid_a, bottom_a = np.array(top, dtype=np.float64), np.array(mid, dtype=np.float64), np.array(bottom, dtype=np.float64)
    lower = t <= 0.5
    tt_lower = np.clip(t / 0.5, 0, 1)
    tt_upper = np.clip((t - 0.5) / 0.5, 0, 1)
    col = np.where(
        lower[:, None],
        top_a[None, :] + (mid_a[None, :] - top_a[None, :]) * tt_lower[:, None],
        mid_a[None, :] + (bottom_a[None, :] - mid_a[None, :]) * tt_upper[:, None],
    ).astype(np.uint8)
    row = np.repeat(col[:, None, :], w, axis=1)  # (h, w, 3)
    return Image.fromarray(row, mode="RGB")


@lru_cache(maxsize=8)
def dot_grid(w: int, h: int, step: int, radius: int, alpha: int) -> Image.Image:
    """Faint dot-matrix overlay (cyber-UI texture), cached per canvas size."""
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    color = (*ACCENT, alpha)
    for y in range(step // 2, h, step):
        for x in range(step // 2, w, step):
            d.ellipse([x - radius, y - radius, x + radius, y + radius], fill=color)
    return layer


@lru_cache(maxsize=4)
@lru_cache(maxsize=4)
def noise_layer(w: int, h: int, alpha: int, seed: int = 7) -> Image.Image:
    """Subtle film-grain noise so the flat gradient doesn't banding-out on export.
    Cached: deterministic for a given (w, h, alpha, seed), and worker
    processes render many cards over their lifetime — computing this
    once instead of on every single render is a real, easy win.
    Vectorized with numpy instead of a 100k+ call Python randint loop,
    which alone used to take a meaningful fraction of total render time."""
    # Render at quarter-res and upscale — real per-pixel noise at full 2400x1260
    # is needlessly slow and reads identically once blended at low alpha.
    sw, sh = max(w // 4, 1), max(h // 4, 1)
    rng = np.random.default_rng(seed)
    grain_arr = rng.integers(90, 166, size=(sh, sw), dtype=np.uint8)
    grain = Image.fromarray(grain_arr, mode="L").resize((w, h), Image.BILINEAR)
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    layer.putalpha(grain.point(lambda v: int(v * alpha / 255)))
    return layer


def radial_glow(w: int, h: int, center: tuple[float, float], radius: float,
                 color: tuple[int, int, int] = GLOW, intensity: int = 90,
                 blur: float = 90) -> Image.Image:
    """One soft ambient bloom, blurred into the backdrop."""
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx, cy = center
    d.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], fill=(*color, intensity))
    return layer.filter(ImageFilter.GaussianBlur(blur))


@lru_cache(maxsize=4)
def _load_board_source() -> Image.Image | None:
    """Load the user-supplied board.png once, RGB, kept at native res
    so every requested canvas size crops from full quality."""
    try:
        return Image.open(BOARD_IMAGE_PATH).convert("RGB")
    except Exception:
        return None


@lru_cache(maxsize=8)
def board_backdrop(w: int, h: int) -> Image.Image | None:
    """Cover-fit crop of board.png to exactly (w, h) — scales up to cover
    both dimensions, then center-crops the overflow, so the source's
    aspect ratio is preserved with no letterboxing or stretching."""
    src = _load_board_source()
    if src is None:
        return None
    sw, sh = src.size
    scale = max(w / sw, h / sh)
    rw, rh = max(1, round(sw * scale)), max(1, round(sh * scale))
    resized = src.resize((rw, rh), Image.LANCZOS)
    x0 = (rw - w) // 2
    y0 = (rh - h) // 2
    return resized.crop((x0, y0, x0 + w, y0 + h))


@lru_cache(maxsize=4)
def vignette(w: int, h: int, strength: int = 130) -> Image.Image:
    """Darkens the outer edge so the eye settles on the card's center content."""
    layer = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(layer)
    d.ellipse([-w * 0.25, -h * 0.35, w * 1.25, h * 1.35], fill=strength)
    layer = layer.filter(ImageFilter.GaussianBlur(min(w, h) * 0.12))
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    inv = layer.point(lambda v: strength - v)
    out.putalpha(inv)
    black = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    out = Image.composite(black, Image.new("RGBA", (w, h), (0, 0, 0, 0)), inv)
    return out


@lru_cache(maxsize=4)
def _composited_backdrop(w: int, h: int, scale: int) -> Image.Image:
    """The actual compositing work — cached because it's fully
    deterministic for a given (w, h, scale): same board.png crop, same
    glow position, same (now-cached) noise and vignette. id_card.py
    draws the per-user content (avatar, name, chips...) directly onto
    whatever create_background() returns, mutating it in place, so the
    PUBLIC create_background() below always hands back a fresh .copy()
    of this — never this cached object itself, which would otherwise
    get corrupted by every render drawing on top of the same canvas."""
    board = board_backdrop(w, h)
    if board is not None:
        base = board.convert("RGBA")
    else:
        base = vertical_gradient(w, h, top=BG_TOP, mid=(3, 22, 20), bottom=(2, 36, 32)).convert("RGBA")
        grid = dot_grid(w, h, step=34 * scale, radius=1 * scale, alpha=16)
        base = Image.alpha_composite(base, grid)

    # single soft bloom centered behind the avatar/name focal area
    glow = radial_glow(w, h, (w * 0.5, h * 0.30), radius=w * 0.42,
                        color=GLOW, intensity=100, blur=95 * scale)
    base = Image.alpha_composite(base, glow)

    grain = noise_layer(w, h, alpha=10)
    base = Image.alpha_composite(base, grain)

    base = Image.alpha_composite(base, vignette(w, h, strength=150))
    return base


def create_background(w: int, h: int, scale: int = 2) -> Image.Image:
    """
    Assemble the full backdrop. Base layer is the user-supplied
    board.png reference image (cover-cropped to the canvas), which
    already carries the dark green field + dot grid + accent mark —
    on top of it we still add the centered ambient glow behind the
    avatar/wordmark, grain and vignette so the focal content pops
    exactly like the previous procedural version. If the asset is
    ever missing, falls back to the old fully-procedural gradient so
    rendering never breaks.
    """
    return _composited_backdrop(w, h, scale).copy()
