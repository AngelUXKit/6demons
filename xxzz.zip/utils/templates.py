"""
TwinIDBot — Channel post builders
4 templates + exclusive badge injection.
All functions return (html_text, image_bytes_or_None).
"""
import logging
import io
import urllib.request
from html.parser import HTMLParser

from utils.ui import (
    bold, code, link, mention, italic, esc, pemoji,
    fmt_price, usd,
    E_DIAMOND, E_BOLT, E_FIRE, E_STAR, E_GIFT, E_SHIELD,
    E_PLUS888, E_TON, E_NFT, E_CROWN,
    get_plat_emoji,
)

logger = logging.getLogger(__name__)


def reputation_line(vouches: int) -> str:
    """OGUsers-style vouch/reputation line for a seller."""
    from config import TRUSTED_SELLER_VOUCHES
    trusted = pemoji(E_SHIELD) + " " + bold("Trusted Seller") + "  ·  " if vouches >= TRUSTED_SELLER_VOUCHES else ""
    return f"{trusted}{bold('Vouches:')}  {vouches}"

# ══════════════════════════════════════════════════════════════════════
# EXCLUSIVE badge
# ══════════════════════════════════════════════════════════════════════
# Was previously a hand-built "ASCII art" banner strung together from
# Syriac + fullwidth Unicode glyphs — it wasn't a premium emoji at all,
# just plain characters styled to look fancy, which is why it always
# rendered as flat text and looked cluttered stacked above a post.
# Replaced with a single clean line built from a real custom emoji
# (E_CROWN) plus bold text — one line, one occurrence, no box.

# ══════════════════════════════════════════════════════════════════════
# EXCLUSIVE badge
# ══════════════════════════════════════════════════════════════════════
# A blockquote gives the badge its own visually separated block above
# the post — the closest thing Telegram's formatting has to a stamped
# "seal" rather than just another line of plain text — and bold+underline
# together give the label real weight without needing a box drawn out
# of characters. The label itself is context-aware: this badge sits
# above Usernames/Accs listings, Promote Ads, and (in principle) any
# future post kind, and each of those is a different kind of post — a
# marketplace listing being "EXCLUSIVE LISTING" is accurate, but a
# Promote Ad tagged the exact same way used to misdescribe it as a
# "listing" when it's actually an ad. One line was doing two jobs.

_EXCLUSIVE_KINDS = {
    "listing": (E_CROWN, "EXCLUSIVE LISTING"),
    "promo":   (E_FIRE,  "PROMOTED"),
}


def exclusive_line(kind: str = "listing") -> str:
    """Single-line exclusive marker, boxed in a blockquote. `kind`
    picks the icon/label — 'listing' (default) for Usernames/Accs
    posts, 'promo' for Promote Ads."""
    emoji, label = _EXCLUSIVE_KINDS.get(kind, _EXCLUSIVE_KINDS["listing"])
    return f"<blockquote>{pemoji(emoji)}  <b><u>{label}</u></b></blockquote>"


def inject_exclusive(text: str, kind: str = "listing") -> str:
    """Prepend the exclusive marker to a channel post."""
    return f"{exclusive_line(kind)}\n\n{text}"


# ══════════════════════════════════════════════════════════════════════
# og:image fetcher (used by templates 2 & 3)
# ══════════════════════════════════════════════════════════════════════

class _OGParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.og_image: str | None = None

    def handle_starttag(self, tag, attrs):
        if tag == "meta":
            d = dict(attrs)
            if d.get("property") == "og:image" and d.get("content"):
                self.og_image = d["content"]


def _fetch_og_image(url: str) -> str | None:
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 (compatible; TwinidBot/1.0)"}
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            raw = resp.read(65_536).decode("utf-8", errors="ignore")
        p = _OGParser(); p.feed(raw)
        return p.og_image
    except Exception as e:
        logger.debug("og:image fetch failed for %s: %s", url, e)
        return None


# ══════════════════════════════════════════════════════════════════════
# ─── TEMPLATE 1 — Clean Structured Card ──────────────────────────────
# Plain lines, labels, minimal chrome. Classic marketplace look.
# ══════════════════════════════════════════════════════════════════════

def template_1(
    platform: str, handle: str, price: str, bargain: str,
    contact: str, link_url: str, seller: str,
    post_id: str, kivani_tag: str | None = None, vouches: int = 0,
) -> str:
    plat_e = get_plat_emoji(platform)
    lines = [
        f"{pemoji(plat_e)}  {bold('TWINID')}  ·  {esc(platform)}",
        "",
        f"{bold('Handle:')}  {code('@' + handle)}",
        f"{bold('Price:')}  {esc(fmt_price(price))}",
        f"{bold('Bargain:')}  {esc(fmt_price(bargain))}",
    ]
    if contact:
        lines.append(f"{bold('Contact:')}  {esc(contact)}")
    if link_url:
        lines.append(f"{bold('Link:')}  {link('View Listing', link_url)}")
    if kivani_tag:
        lines.append(f"{bold('KivaniCDK:')}  {code(kivani_tag)}")
    if vouches:
        lines.append(reputation_line(vouches))
    lines += [
        "",
        f"{bold('Post ID:')}  {code(post_id)}",
        f"DM {mention(seller)}  ·  {link('@twinid', 'https://t.me/twinid')}",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# ─── TEMPLATE 2 — Bold Spotlight ─────────────────────────────────────
# Large header, price highlighted, energetic feel.
# ══════════════════════════════════════════════════════════════════════

def template_2(
    platform: str, handle: str, price: str, bargain: str,
    contact: str, link_url: str, seller: str,
    post_id: str, kivani_tag: str | None = None, vouches: int = 0,
) -> str:
    plat_e = get_plat_emoji(platform)
    lines = [
        f"{bold(esc(platform).upper() + ' HANDLE FOR SALE')}  ",
        "",
        f"{pemoji(plat_e)}  {code('@' + handle)}",
        "",
        f"{bold('Asking:')}  {bold(esc(fmt_price(price)))}",
        f"{bold('Best Offer:')}  {esc(fmt_price(bargain))}",
    ]
    if contact:
        lines.append(f"{bold('Reach me:')}  {esc(contact)}")
    if link_url:
        lines.append(f"{link('View / Verify on Fragment', link_url)}")
    if kivani_tag:
        lines.append(f"{bold('Anonymous DM:')}  {code(kivani_tag)}")
    if vouches:
        lines.append(reputation_line(vouches))
    lines += [
        "",
        f"┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄",
        f"{code(post_id)}   ·   {link('@twinid', 'https://t.me/twinid')}",
        f"Seller: {mention(seller)}",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# ─── TEMPLATE 3 — Minimal Elegant ────────────────────────────────────
# Whitespace-heavy, clean, luxury feel.
# ══════════════════════════════════════════════════════════════════════

def template_3(
    platform: str, handle: str, price: str, bargain: str,
    contact: str, link_url: str, seller: str,
    post_id: str, kivani_tag: str | None = None, vouches: int = 0,
) -> str:
    plat_e = get_plat_emoji(platform)
    lines = [
        f"— {pemoji(plat_e)} {bold(esc(platform))} —",
        "",
        f"{code('@' + handle)}",
        "",
        f"Price     {bold(esc(fmt_price(price)))}",
        f"Bargain   {esc(fmt_price(bargain))}",
    ]
    if contact:
        lines.append(f"Contact   {esc(contact)}")
    if link_url:
        lines.append(f"{link(' Listing', link_url)}")
    if kivani_tag:
        lines.append(f"KivaniCDK  {code(kivani_tag)}")
    if vouches:
        lines.append(reputation_line(vouches))
    lines += [
        "",
        f"{code(post_id)}  ·  {mention(seller)}",
        f"{link('twinid', 'https://t.me/twinid')}",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# ─── TEMPLATE 4 — ID Card (image-based) ──────────────────────────────
# Generates a graphical ID card. Text caption is a short summary.
# ══════════════════════════════════════════════════════════════════════

def template_4_caption(
    platform: str, handle: str, price: str, bargain: str,
    seller: str, post_id: str, kivani_tag: str | None = None,
    contact: str = "", url: str = "", vouches: int = 0,
) -> str:
    """
    Caption that goes *under* the ID-card photo. The card is the visual
    centerpiece, but the caption still spells out the same core details
    in plain text — platform, handle, price, bargain, contact — so the
    listing is fully readable even before the image loads, searchable
    in-channel, and consistent with templates 1–3 rather than being a
    near-empty stub next to a much richer image.
    """
    plat_e = get_plat_emoji(platform)
    lines = [
        f"{pemoji(plat_e)}  {bold('TWINID')}  ·  {esc(platform)}",
        "",
        f"{bold('Handle:')}  {code('@' + handle)}",
        f"{bold('Price:')}  {esc(fmt_price(price))}   ·   {bold('Bargain:')}  {esc(fmt_price(bargain))}",
    ]
    if contact:
        lines.append(f"{bold('Contact:')}  {esc(contact)}")
    if url:
        lines.append(link("View Listing", url))
    if kivani_tag:
        lines.append(f"{bold('KivaniCDK:')}  {code(kivani_tag)}")
    if vouches:
        lines.append(reputation_line(vouches))
    lines += [
        "",
        f"{bold('Post ID:')}  {code(post_id)}",
        f"DM {mention(seller)}  ·  {link('@twinid', 'https://t.me/twinid')}",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# ─── Gift / +888 / NFT / TON template ────────────────────────────────
# ══════════════════════════════════════════════════════════════════════

def build_gift_post(
    category: str, name: str, price: str, bargain: str,
    contact: str | None, url: str, seller: str,
    post_id: str, kivani_tag: str | None = None,
) -> str:
    if category == "+888 Numbers":
        icon = pemoji(E_PLUS888)
        header = bold("+888 NUMBER FOR SALE")
    elif category == "TON Gifts":
        icon = pemoji(E_TON)
        header = bold("TON GIFT LISTING")
    else:
        icon = pemoji(E_NFT)
        header = bold("NFT LISTING")

    lines = [
        f"{icon}  {header}",
        "",
        f"{bold('Item:')}  {esc(name)}",
        f"{bold('Price:')}  {esc(fmt_price(price))}",
        f"{bold('Bargain:')}  {esc(fmt_price(bargain))}",
    ]
    if contact:
        lines.append(f"{bold('Contact:')}  {esc(contact)}")
    lines.append(f"{bold('URL:')}  {link('View Item', url)}")
    if kivani_tag:
        lines.append(f"{bold('KivaniCDK:')}  {code(kivani_tag)}")
    lines += [
        "",
        f"{bold('Post ID:')}  {code(post_id)}",
        f"DM {mention(seller)}  ·  {link('@twinid', 'https://t.me/twinid')}",
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════
# ─── Raw passthrough post — Promote Ads & Ads of the Day ─────────────
# ══════════════════════════════════════════════════════════════════════

def build_raw_post(raw_html: str) -> str:
    """Promote Ads and Ads of the Day both post exactly what the sender
    typed — their own wording, formatting, and (if they have Telegram
    Premium) their own custom emoji — with nothing added on top. The
    caller is expected to have already captured the sender's message
    as HTML (aiogram's Message.html_text) so entities like bold,
    links, and custom emoji survive the round trip intact. This
    function is intentionally a passthrough rather than a no-op call
    site, so both flows share one clearly-named, documented entry
    point instead of sending raw strings inline in the handlers.
    """
    return raw_html


# ══════════════════════════════════════════════════════════════════════
# ─── Template preview for the "choose template" step ─────────────────
# ══════════════════════════════════════════════════════════════════════

TEMPLATE_NAMES = {
    1: "Clean Card",
    2: "Bold Spotlight",
    3: "Minimal Elegant",
    4: "ID Card (image)",
}


def get_template_preview(
    tpl: int,
    platform: str, handle: str, price: str, bargain: str,
    contact: str, link_url: str, seller: str,
    kivani_tag: str | None = None, vouches: int = 0,
) -> str:
    """Return a rendered preview of the chosen template (no exclusive badge)."""
    dummy_id = "PREV-0000"
    if tpl == 1:
        return template_1(platform, handle, price, bargain, contact, link_url, seller, dummy_id, kivani_tag, vouches)
    elif tpl == 2:
        return template_2(platform, handle, price, bargain, contact, link_url, seller, dummy_id, kivani_tag, vouches)
    elif tpl == 3:
        return template_3(platform, handle, price, bargain, contact, link_url, seller, dummy_id, kivani_tag, vouches)
    else:
        return template_4_caption(platform, handle, price, bargain, seller, dummy_id, kivani_tag, contact, link_url, vouches)


def build_final_post(
    tpl: int,
    platform: str, handle: str, price: str, bargain: str,
    contact: str, link_url: str, seller: str,
    post_id: str, is_exclusive_user: bool,
    kivani_tag: str | None = None, vouches: int = 0,
) -> str:
    """Build the final post HTML, injecting exclusive badge if needed."""
    if tpl == 1:
        text = template_1(platform, handle, price, bargain, contact, link_url, seller, post_id, kivani_tag, vouches)
    elif tpl == 2:
        text = template_2(platform, handle, price, bargain, contact, link_url, seller, post_id, kivani_tag, vouches)
    elif tpl == 3:
        text = template_3(platform, handle, price, bargain, contact, link_url, seller, post_id, kivani_tag, vouches)
    else:
        text = template_4_caption(platform, handle, price, bargain, seller, post_id, kivani_tag, contact, link_url, vouches)

    # Template 4's image already renders a clean EXCLUSIVE badge on the
    # card itself — injecting the text banner too would just duplicate
    # it above the photo. Only templates 1–3 (plain text, no image) get
    # the text marker.
    if is_exclusive_user and tpl != 4:
        text = inject_exclusive(text)
    return text