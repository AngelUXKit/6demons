"""
TwinIDBot — Slash-command menu
────────────────────────────────────────────────────────────────────────
Registers the command list Telegram shows when a user types "/" in the
chat with the bot. Without this, aiogram will still route /balance,
/post, etc. correctly (they're just message filters), but Telegram's
client UI has no idea those commands exist, so the "/" autocomplete
menu stays empty. This calls Bot.set_my_commands() once at startup.

Two scopes are used:
  • default   — shown to every user, in every private chat with the bot.
  • chat(ADMIN_ID) — the same list plus /admin, shown only to the bot owner.
This keeps /admin out of the public menu without hiding it from you.
"""
from aiogram import Bot
from aiogram.types import BotCommand, BotCommandScopeChat, BotCommandScopeDefault

from config import ADMIN_ID

PUBLIC_COMMANDS = [
    BotCommand(command="start",   description="Open the main menu"),
    BotCommand(command="balance", description="View your balance, ID & KivaniCDK tag"),
    BotCommand(command="post",    description="List an account for sale"),
    BotCommand(command="manage",  description="Manage your active posts"),
    BotCommand(command="kivani",  description="Anonymous KivaniCDK inbox"),
    BotCommand(command="gifts",   description="Browse Gifts & NFTs"),
    BotCommand(command="vouch",   description="Vouch for a trusted seller"),
    BotCommand(command="rep",     description="Check a seller's vouch count"),
    BotCommand(command="help",    description="Help & support"),
]

ADMIN_COMMANDS = PUBLIC_COMMANDS + [
    BotCommand(command="admin", description="Admin control panel"),
]


async def setup_commands(bot: Bot) -> None:
    await bot.set_my_commands(PUBLIC_COMMANDS, scope=BotCommandScopeDefault())
    await bot.set_my_commands(ADMIN_COMMANDS, scope=BotCommandScopeChat(chat_id=ADMIN_ID))
