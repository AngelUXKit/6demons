# TwinIDBot — Update Log

## Fixes
- Removed a duplicate `get_credits` import in `handlers/kivani.py` that was silently shadowing itself.

## Performance / Async
- New `utils/workers.py`: dedicated `ProcessPoolExecutor` for CPU-bound Pillow rendering (ID cards),
  separate from the DB layer's I/O thread pool. Multiple users generating post images at once now
  render in true parallel instead of queuing behind the GIL. Falls back to a thread executor if the
  environment can't spawn processes.
- `handlers/posts.py` routes ID card generation through the new pool (`run_cpu(...)`).
- `bot.py` shuts the pool down cleanly on exit.

## Post Images — redesigned (`utils/id_card.py`)
- Rebuilt at OG-image standard size (1200x630) instead of 800x480.
- Real frosted-glass content panel (blurred + tinted backdrop, not a flat rectangle).
- Clean 2-column detail grid with hairline cells (Handle / Price / Bargain / Contact / Link).
- Decoupled from `aiogram` — it's a pure function now, safe to run in a worker process.
- Shows seller reputation (see Vouches below): vouch count, or a gold "TRUSTED SELLER" badge once
  a seller crosses the threshold.

## Reputation — OGUsers-style vouches (new)
Inspired by OGUsers' vouch/reputation system (buyers vouch for sellers after a deal, reputation is
public and drives trust) — added as a lightweight equivalent:
- `/vouch TW-XXXXXXXX` — vouch for the seller of a completed deal. One vouch per (post, voucher);
  sellers can't vouch themselves.
- `/rep <telegram_id>` — look up any seller's public vouch count.
- Crossing `TRUSTED_SELLER_VOUCHES` (config.py, default 10) unlocks a gold "Trusted Seller" badge —
  shown on `/balance`, on the ID card, and appended to every text-template post.
- New DB functions: `add_vouch()`, `get_vouches()` in `db/database.py`.

## Telegram Stars — self-serve top-up (new)
Previously credits could only be topped up by manually messaging the admin. Added native
in-bot purchase using Telegram's built-in Stars payments (Bot API `sendInvoice` with `currency="XTR"`):
- `Top Up` now shows package buttons (`config.STAR_PACKAGES`) with instant checkout.
- `pre_checkout_query` auto-approves; `successful_payment` credits the account immediately.
- Manual admin top-up kept as a fallback button for anyone who prefers it.

## Ecosystem branding
- Every post template and the ID card footer now carries a consistent "TwinID Ecosystem" tag
  alongside the `@twinid` channel link.

## Security note (not code — flagging for you)
`config.py` has a live bot token and a MySQL password committed in plaintext. Worth moving both to
environment variables before this file goes anywhere outside your own machine.
