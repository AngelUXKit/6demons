"""
TwinIDBot — Gifts, +888 Numbers, TON Gifts & NFT handler
No @username — items use Name, Price, Bargain, Contact (optional), URL (required).
"""
import uuid
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup

from config import CHANNEL_ID, COST_PER_POST
from db.database import (
    get_user, has_enough, deduct_credits, get_credits,
    save_post, get_user_tag, is_exclusive,
)
from utils.ui import (
    HTML,
    send,
    edit,
    ibtn,
    kb_back_cancel,
    kb_cancel_only,
    kb_contact,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    fmt_price,
    is_valid_price,
    clean_price,
    is_valid_url,
    msg_no_access,
    msg_low_credits,
    msg_invalid_input,
    E_BACK,
    E_BOLT,
    E_CHECK,
    E_CROSS,
    E_DIAMOND,
    E_GIFT,
    E_ID,
    E_NFT,
    E_PHONE,
    E_PLUS888,
    E_PRICE,
    E_STAR,
    E_TON,

    BTN_GIFTS,
)
from utils.templates import build_gift_post, inject_exclusive
from handlers.manage import kb_manage

router = Router()

GIFT_CATEGORIES = ["+888 Numbers", "TON Gifts", "NFT"]

CATEGORY_ICONS = {
    "+888 Numbers": "",
    "TON Gifts":    "",
    "NFT":          "",
}


# ── FSM ───────────────────────────────────────────────────────────────

class GiftFlow(StatesGroup):
    choosing_category = State()
    entering_name     = State()
    entering_price    = State()
    entering_bargain  = State()
    entering_contact  = State()
    entering_url      = State()
    confirming        = State()


# ── Keyboards ─────────────────────────────────────────────────────────

def kb_gift_categories() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [ibtn("+888 Numbers", "gift_cat:+888 Numbers", E_PLUS888)],
        [ibtn("TON Gifts",    "gift_cat:TON Gifts",    E_TON)],
        [ibtn("NFT",          "gift_cat:NFT",          E_NFT)],
        [ibtn("Cancel",       "cancel",                E_CROSS)],
    ])


def kb_gift_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("Post Now",  "gift_confirm",  E_CHECK),
        ibtn("Redo",      "gift_redo",     E_BACK),
        ibtn("Cancel",    "cancel",        E_CROSS),
    ]])


# ══════════════════════════════════════════════════════════════════════
# Entry
# ══════════════════════════════════════════════════════════════════════

@router.message(F.text == BTN_GIFTS)
@router.message(Command("gifts"))
async def btn_gifts(msg: Message, state: FSMContext):
    await state.clear()
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    if not user.get("tos_accepted"):
        await send(msg, f"{pemoji(E_CROSS)} Accept TOS first. Send /start."); return

    await state.set_state(GiftFlow.choosing_category)
    await send(msg,
        f"{pemoji(E_GIFT)}  {bold('Gifts, Numbers & NFTs')}\n\n"
        f"List your  {bold('+888 number')},  {bold('TON Gift')},  or  {bold('NFT')}.\n\n"
        f"These listings  {bold('do not')}  use @usernames.\n"
        f"You'll provide:  Name · Price · Bargain · Contact (opt) · URL\n\n"
        f"Cost:  {bold(usd(COST_PER_POST))}  ({COST_PER_POST} credits)",
        reply_markup=kb_gift_categories())


# ── Category ──────────────────────────────────────────────────────────

@router.callback_query(GiftFlow.choosing_category, F.data.startswith("gift_cat:"))
async def cb_gift_category(cq: CallbackQuery, state: FSMContext):
    uid      = cq.from_user.id
    if not await has_enough(uid, COST_PER_POST):
        await edit(cq.message, msg_low_credits(await get_credits(uid), COST_PER_POST)); return
    category = cq.data.split(":", 1)[1]
    icon     = CATEGORY_ICONS.get(category, pemoji(E_GIFT))
    await state.update_data(category=category)
    await state.set_state(GiftFlow.entering_name)
    await edit(cq.message,
        f"{icon}  {bold(category)}\n\n"
        f"What is the  {bold('name')}  of the item?\n\n"
        f"For +888 numbers use the full number, e.g.  {bold('+888 123 456')}\n"
        f"For Gifts / NFTs use the collection name.",
        reply_markup=kb_back_cancel("back:gift_category"))
    await cq.answer()


@router.callback_query(F.data == "back:gift_category")
async def back_gift_category(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.choosing_category)
    await edit(cq.message,
        f"{pemoji(E_GIFT)}  {bold('Choose Category')}",
        reply_markup=kb_gift_categories())
    await cq.answer()


# ── Name ──────────────────────────────────────────────────────────────

@router.message(GiftFlow.entering_name)
async def fsm_gift_name(msg: Message, state: FSMContext):
    name = (msg.text or "").strip()
    if not name:
        await send(msg, msg_invalid_input("name", "Name can't be empty."),
                   reply_markup=kb_back_cancel("back:gift_category")); return
    await state.update_data(item_name=name)
    await state.set_state(GiftFlow.entering_price)
    await send(msg,
        f"{pemoji(E_PRICE)}  {bold('Asking Price')}\n\nJust the number, no $.",
        reply_markup=kb_back_cancel("back:gift_name"))


@router.callback_query(F.data == "back:gift_name")
async def back_gift_name(cq: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    cat  = data.get("category", "")
    icon = CATEGORY_ICONS.get(cat, pemoji(E_GIFT))
    await state.set_state(GiftFlow.entering_name)
    await edit(cq.message,
        f"{icon}  {bold(cat)}\n\nSend the item name:",
        reply_markup=kb_back_cancel("back:gift_category"))
    await cq.answer()


# ── Price ─────────────────────────────────────────────────────────────

@router.message(GiftFlow.entering_price)
async def fsm_gift_price(msg: Message, state: FSMContext):
    raw = msg.text or ""
    if not is_valid_price(raw):
        await send(msg, msg_invalid_input("price", "Positive number only."),
                   reply_markup=kb_back_cancel("back:gift_name")); return
    await state.update_data(price=clean_price(raw))
    await state.set_state(GiftFlow.entering_bargain)
    await send(msg,
        f"{pemoji(E_CHECK)}  {bold('Bargain Price')}\n\nLowest you'll accept.",
        reply_markup=kb_back_cancel("back:gift_price"))


@router.callback_query(F.data == "back:gift_price")
async def back_gift_price(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.entering_price)
    await edit(cq.message,
        f"{pemoji(E_PRICE)}  {bold('Asking Price')}\n\nJust the number, no $.",
        reply_markup=kb_back_cancel("back:gift_name"))
    await cq.answer()


# ── Bargain ───────────────────────────────────────────────────────────

@router.message(GiftFlow.entering_bargain)
async def fsm_gift_bargain(msg: Message, state: FSMContext):
    raw  = msg.text or ""
    if not is_valid_price(raw):
        await send(msg, msg_invalid_input("bargain", "Positive number only."),
                   reply_markup=kb_back_cancel("back:gift_price")); return
    data = await state.get_data()
    if float(clean_price(raw)) > float(data.get("price", "0") or "0"):
        await send(msg, msg_invalid_input("bargain", f"Can't exceed asking price ({fmt_price(data['price'])})."),
                   reply_markup=kb_back_cancel("back:gift_price")); return
    await state.update_data(bargain=clean_price(raw))
    await state.set_state(GiftFlow.entering_contact)
    await send(msg,
        f"{pemoji(E_PHONE)}  {bold('Contact')}  (optional)\n\n"
        f"Your @username or other contact info.\n"
        f"Type  {bold('skip')}  to omit.",
        reply_markup=kb_back_cancel("back:gift_bargain"))


@router.callback_query(F.data == "back:gift_bargain")
async def back_gift_bargain(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.entering_bargain)
    await edit(cq.message,
        f"{pemoji(E_CHECK)}  {bold('Bargain Price')}\n\nLowest you'll accept.",
        reply_markup=kb_back_cancel("back:gift_price"))
    await cq.answer()


# ── Contact ───────────────────────────────────────────────────────────

@router.message(GiftFlow.entering_contact)
async def fsm_gift_contact(msg: Message, state: FSMContext):
    val = (msg.text or "").strip()
    await state.update_data(contact="" if val.lower() == "skip" else val)
    await state.set_state(GiftFlow.entering_url)
    await send(msg,
        f"{pemoji(E_BOLT)}  {bold('Item URL')}  —  {bold('Required')}\n\n"
        f"Paste a direct link to the item.\n"
        f"Must start with  {bold('https://')}",
        reply_markup=kb_back_cancel("back:gift_contact"))


@router.callback_query(F.data == "back:gift_contact")
async def back_gift_contact(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.entering_contact)
    await edit(cq.message,
        f"{pemoji(E_PHONE)}  {bold('Contact')}  (optional)\n\nType skip to omit.",
        reply_markup=kb_back_cancel("back:gift_bargain"))
    await cq.answer()


# ── URL (required) ────────────────────────────────────────────────────

@router.message(GiftFlow.entering_url)
async def fsm_gift_url(msg: Message, state: FSMContext):
    url = (msg.text or "").strip()
    if not is_valid_url(url):
        await send(msg, msg_invalid_input("URL",
            "A valid https:// URL is required for Gift / NFT / +888 listings.\n"
            "Paste the item link:"),
                   reply_markup=kb_back_cancel("back:gift_contact")); return

    seller = msg.from_user.username or str(msg.from_user.id)
    await state.update_data(url=url, seller_username=seller)

    data   = await state.get_data()
    kivani = await get_user_tag(msg.from_user.id)
    preview = build_gift_post(
        data["category"], data["item_name"], data["price"], data["bargain"],
        data.get("contact"), url, seller, "PREV-0000", kivani,
    )
    await send(msg, f"{pemoji(E_STAR)}  {bold('Preview:')}\n\n{'─'*30}\n\n{preview}")
    await state.set_state(GiftFlow.confirming)
    await send(msg,
        f"{pemoji(E_PRICE)}  Cost:  {bold(usd(COST_PER_POST))}  ({COST_PER_POST} credits)",
        reply_markup=kb_gift_confirm())


@router.callback_query(F.data == "back:gift_url")
async def back_gift_url(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.entering_url)
    await edit(cq.message,
        f"{pemoji(E_BOLT)}  {bold('Item URL')}  (required)\n\nPaste https:// link:",
        reply_markup=kb_back_cancel("back:gift_contact"))
    await cq.answer()


# ── Redo ──────────────────────────────────────────────────────────────

@router.callback_query(GiftFlow.confirming, F.data == "gift_redo")
async def cb_gift_redo(cq: CallbackQuery, state: FSMContext):
    await state.set_state(GiftFlow.entering_name)
    data = await state.get_data()
    cat  = data.get("category", "")
    icon = CATEGORY_ICONS.get(cat, pemoji(E_GIFT))
    await edit(cq.message,
        f"{icon}  {bold(cat)}\n\nSend the item name:",
        reply_markup=kb_back_cancel("back:gift_category"))
    await cq.answer()


# ── Confirm & post ────────────────────────────────────────────────────

@router.callback_query(GiftFlow.confirming, F.data == "gift_confirm")
async def cb_gift_confirm(cq: CallbackQuery, state: FSMContext, bot: Bot):
    uid  = cq.from_user.id
    cost = COST_PER_POST
    if not await deduct_credits(uid, cost):
        await edit(cq.message, msg_low_credits(await get_credits(uid), cost))
        await state.clear(); return

    data    = await state.get_data()
    post_id = f"TW-{uuid.uuid4().hex[:8].upper()}"
    excl    = await is_exclusive(uid)
    kivani  = await get_user_tag(uid)

    post_html = build_gift_post(
        data["category"], data["item_name"], data["price"], data["bargain"],
        data.get("contact"), data["url"], data["seller_username"], post_id, kivani,
    )
    if excl:
        post_html = inject_exclusive(post_html)

    # Try og:image from URL
    sent = None
    try:
        import asyncio, urllib.request
        from html.parser import HTMLParser

        def _og(url):
            try:
                req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=6) as r:
                    raw = r.read(65536).decode("utf-8","ignore")
                class P(HTMLParser):
                    og=None
                    def handle_starttag(s,tag,attrs):
                        if tag=="meta":
                            d=dict(attrs)
                            if d.get("property")=="og:image": s.og=d.get("content")
                p=P(); p.feed(raw); return p.og
            except: return None

        loop     = asyncio.get_event_loop()
        img_url  = await loop.run_in_executor(None, _og, data["url"])
        if img_url:
            sent = await bot.send_photo(CHANNEL_ID, photo=img_url,
                                        caption=post_html, parse_mode=HTML,
                                        reply_markup=kb_contact(data["seller_username"], data.get("contact", "")))
    except Exception:
        pass
    if not sent:
        sent = await bot.send_message(CHANNEL_ID, post_html, parse_mode=HTML,
                                       reply_markup=kb_contact(data["seller_username"], data.get("contact", "")))

    await save_post(post_id, {
        "post_id":         post_id,
        "owner_id":        uid,
        "channel_msg_id":  sent.message_id,
        "mode":            "gift",
        "category":        data["category"],
        "item_name":       data["item_name"],
        "price":           data["price"],
        "bargain":         data["bargain"],
        "contact":         data.get("contact", ""),
        "url":             data["url"],
        "seller_username": data["seller_username"],
        "exclusive":       excl,
    })
    await state.clear()
    bal = await get_credits(uid)
    await edit(cq.message,
        f"{pemoji(E_DIAMOND)}  {bold('Posted!')}\n\n"
        f"Live on  {link('@twinid', 'https://t.me/twinid')}\n"
        f"{pemoji(E_ID)}  Post ID:  {code(post_id)}\n\n"
        f"{pemoji(E_STAR)}  Balance:  {bold(usd(bal))}  ({bal} credits)",
        reply_markup=kb_manage(post_id))
    await cq.answer("Posted!")
