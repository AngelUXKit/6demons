"""
TwinIDBot — Ads of the Day
──────────────────────────────────────────────────────────────────────
A single premium pinned promo slot in the channel:
  1. Sender writes (or forwards) their ad — posted exactly as given,
     same as Promote Ads — their own formatting/emoji, nothing added.
     An image is optional; can come bundled with the message (typed
     with a photo, or a forwarded photo post) or attached separately.
  2. Sender picks what the post's button points to — their own
     channel/@username, or skip for the TwinID default.
  3. On submit, a flat Telegram Stars invoice is charged immediately —
     paid in Stars, NOT credits, and happens before the admin ever
     sees it.
  4. Paid submission goes to ADMIN_ID with Accept / Reject.
  5. Accept -> posted to the channel and pinned for ADS_OF_DAY_HOURS.
  6. Only one slot can be active at a time; a background task
     (run_ads_expiry_checker, started from bot.py) auto-unpins once it
     expires and frees the slot back up.
"""
import asyncio
import logging
import time

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, LabeledPrice, PreCheckoutQuery,
)

from config import ADMIN_ID, CHANNEL_ID, ADS_OF_DAY_STARS, ADS_OF_DAY_HOURS
from db.database import (
    get_user, get_active_ad, set_active_ad, clear_active_ad,
    save_pending_ad, pop_pending_ad,
)
from utils.templates import build_raw_post
from utils.ui import (
    HTML, send, edit, ibtn, kb_back_cancel, kb_promo, send_post,
    pemoji, bold, code, link, esc,
    msg_no_access, msg_invalid_input,
    E_BACK, E_CHECK, E_CROSS, E_FIRE, E_STAR,
)

from handlers.posts import ModeFlow, kb_mode, mode_menu_text

logger = logging.getLogger(__name__)
router = Router()


class AdsFlow(StatesGroup):
    entering_message = State()
    entering_image    = State()   # only reached if the message step had no photo
    entering_target   = State()   # configurable button destination
    awaiting_payment  = State()   # invoice sent, waiting on Telegram's payment callback


# ══════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════

def _fmt_remaining(expires_at: float) -> str:
    remaining = max(0, int(expires_at - time.time()))
    h, rem = divmod(remaining, 3600)
    m, _ = divmod(rem, 60)
    return f"{h}h {m}m"


def kb_ads_admin(uid: int, token: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("Accept", f"ads_accept:{uid}:{token}", E_CHECK),
        ibtn("Reject", f"ads_reject:{uid}:{token}", E_CROSS),
    ]])


# ══════════════════════════════════════════════════════════════════════
# Entry point — wired from the /post "New Listing" menu (mode:ads_of_day)
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(ModeFlow.choosing_mode, F.data == "mode:ads_of_day")
async def cb_mode_ads_of_day(cq: CallbackQuery, state: FSMContext):
    uid  = cq.from_user.id
    user = await get_user(uid)
    if not user:
        await edit(cq.message, msg_no_access(uid)); return

    active = await get_active_ad()
    if active and active.get("expires_at", 0) > time.time():
        await edit(cq.message,
            f"{pemoji(E_FIRE)}  {bold('Ads of the Day')}\n\n"
            f"The slot is currently taken — only one ad pinned at a time.\n"
            f"Free again in  {bold(_fmt_remaining(active['expires_at']))}.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                ibtn("Back", "back:mode_from_ads", E_BACK),
            ]]))
        await cq.answer(); return

    await state.set_state(AdsFlow.entering_message)
    await edit(cq.message,
        f"{pemoji(E_FIRE)}  {bold('Ads of the Day')}\n\n"
        f"One pinned slot in the channel for {ADS_OF_DAY_HOURS}h — only one active at a time.\n\n"
        f"Send (or forward) the message exactly how you want it posted — your "
        f"own formatting and emoji included, nothing added on top. Attach a "
        f"photo if you want one in the post.\n\n"
        f"Flat price:  ⭐ {bold(str(ADS_OF_DAY_STARS))} Stars, charged on submit "
        f"(separate from your credit balance).",
        reply_markup=kb_back_cancel("back:mode_from_ads"))
    await cq.answer()


@router.callback_query(F.data == "back:mode_from_ads")
async def back_from_ads(cq: CallbackQuery, state: FSMContext):
    await state.set_state(ModeFlow.choosing_mode)
    await edit(cq.message, mode_menu_text(), reply_markup=kb_mode())
    await cq.answer()


# ══════════════════════════════════════════════════════════════════════
# Compose (message -> optional image -> promo button) -> pay
# ══════════════════════════════════════════════════════════════════════

@router.message(AdsFlow.entering_message)
async def fsm_ads_message(msg: Message, state: FSMContext):
    # html_text falls back to .caption/.caption_entities when the
    # message is a photo, and works the same for a fresh message or a
    # forward, so forwarding an existing post here "just works".
    ad_html = (msg.html_text or "").strip()
    if not ad_html and not msg.photo:
        await send(msg, msg_invalid_input("message", "Message can't be empty."),
                   reply_markup=kb_back_cancel("back:mode_from_ads")); return

    # Re-check the slot right away — it may have filled while this
    # sender was still typing (cheap check, avoids composing for nothing).
    active = await get_active_ad()
    if active and active.get("expires_at", 0) > time.time():
        await send(msg,
            f"{pemoji(E_CROSS)}  Someone else grabbed the slot first — "
            f"free again in  {bold(_fmt_remaining(active['expires_at']))}.")
        await state.clear(); return

    await state.update_data(ad_html=ad_html)

    if msg.photo:
        await state.update_data(ad_photo=msg.photo[-1].file_id)
        await state.set_state(AdsFlow.entering_target)
        await send(msg,
            f"{pemoji(E_FIRE)}  {bold('Promo button')}\n\n"
            f"Send a channel link or @username for the button to point to, "
            f"or type  {code('skip')}  to default to  {code('Ads - @Twinid')}.",
            reply_markup=kb_back_cancel("back:mode_from_ads"))
        return

    await state.set_state(AdsFlow.entering_image)
    await send(msg,
        f"{pemoji(E_STAR)}  Send a photo to attach, or type  {code('skip')}  for none.",
        reply_markup=kb_back_cancel("back:mode_from_ads"))


@router.message(AdsFlow.entering_image)
async def fsm_ads_image(msg: Message, state: FSMContext):
    if msg.photo:
        await state.update_data(ad_photo=msg.photo[-1].file_id)
    await state.set_state(AdsFlow.entering_target)
    await send(msg,
        f"{pemoji(E_FIRE)}  {bold('Promo button')}\n\n"
        f"Send a channel link or @username for the button to point to, "
        f"or type  {code('skip')}  to default to  {code('Ads - @Twinid')}.",
        reply_markup=kb_back_cancel("back:mode_from_ads"))


@router.message(AdsFlow.entering_target)
async def fsm_ads_target(msg: Message, state: FSMContext, bot: Bot):
    raw    = (msg.text or "").strip()
    target = "" if raw.lower() == "skip" else raw
    await state.update_data(ad_target=target)

    token = str(msg.message_id)
    await state.update_data(token=token)

    # Move off entering_target BEFORE sending the invoice. Data (ad_html,
    # ad_photo, ad_target, token) survives a set_state() call — only the
    # state *name* changes — so ads_payment_success can still read it
    # back later via state.get_data(). Without this, this handler was
    # still "listening" as entering_target when Telegram's payment
    # confirmation message came back in, matched this same filter, and
    # got treated as if it were the target-text reply — firing a SECOND
    # invoice on a loop and never letting ads_payment_success run at all
    # (which is also why the admin notification never went out).
    await state.set_state(AdsFlow.awaiting_payment)

    await bot.send_invoice(
        chat_id=msg.from_user.id,
        title="TwinID  ·  Ads of the Day",
        description=f"One pinned slot in @twinid for {ADS_OF_DAY_HOURS}h.",
        payload=f"ads:{msg.from_user.id}:{token}",
        currency="XTR",                       # Telegram Stars
        prices=[LabeledPrice(label="Ads of the Day", amount=ADS_OF_DAY_STARS)],
    )


@router.pre_checkout_query(F.invoice_payload.startswith("ads:"))
async def ads_pre_checkout(pcq: PreCheckoutQuery):
    await pcq.answer(ok=True)


@router.message(F.successful_payment.invoice_payload.startswith("ads:"))
async def ads_payment_success(msg: Message, state: FSMContext, bot: Bot):
    data    = await state.get_data()
    ad_html = data.get("ad_html")
    photo   = data.get("ad_photo")
    target  = data.get("ad_target", "")
    token   = data.get("token", str(msg.message_id))
    await state.clear()

    uid    = msg.from_user.id
    seller = msg.from_user.username or str(uid)

    if ad_html is None:
        # Money already moved — don't just eat it silently if state
        # somehow got lost between invoice and payment.
        await send(msg,
            f"{pemoji(E_CROSS)}  Payment received, but your draft message "
            f"couldn't be recovered. Message  {link('@mvpzy', 'https://t.me/mvpzy')}  "
            f"with your payment receipt and it'll be sorted manually.")
        return

    await send(msg,
        f"{pemoji(E_CHECK)}  {bold('Payment received!')}\n\n"
        f"Sent to the admin for review — you'll be notified once it's "
        f"accepted and pinned.")

    await save_pending_ad(uid, token, {
        "ad_html": ad_html, "ad_photo": photo, "ad_target": target,
        "seller_username": seller, "submitted_at": time.time(),
    })

    admin_preview = (
        f"{pemoji(E_FIRE)}  {bold('Ads of the Day — Submission')}\n\n"
        f"From:  @{esc(seller)}  ({code(str(uid))})\n"
        f"Paid:  ⭐ {ADS_OF_DAY_STARS} Stars\n"
        f"Button:  {esc(target) if target else 'default (Ads - @Twinid)'}\n\n"
        f"{'─'*30}\n\n"
        f"{build_raw_post(ad_html)}"
    )
    try:
        await send_post(
            bot, ADMIN_ID, admin_preview, photo=photo, parse_mode=HTML,
            reply_markup=kb_ads_admin(uid, token),
        )
    except Exception as e:
        logger.error("Could not reach admin for Ads of the Day approval: %s", e)
        await send(msg,
            f"{pemoji(E_CROSS)}  Couldn't reach the admin automatically — "
            f"message  {link('@mvpzy', 'https://t.me/mvpzy')}  directly, "
            f"your payment is already on record.")


# ══════════════════════════════════════════════════════════════════════
# Admin: Accept -> post + pin  /  Reject
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data.startswith("ads_accept:"))
async def cb_ads_accept(cq: CallbackQuery, bot: Bot):
    if cq.from_user.id != ADMIN_ID:
        await cq.answer("Admin only.", show_alert=True); return
    _, uid_str, token = cq.data.split(":", 2)
    uid = int(uid_str)

    active = await get_active_ad()
    if active and active.get("expires_at", 0) > time.time():
        await cq.answer("A slot is already active — wait for it to expire first.", show_alert=True)
        return

    record = await pop_pending_ad(uid, token)
    if not record:
        await edit(cq.message, f"{pemoji(E_CROSS)}  Submission expired or already handled.")
        await cq.answer(); return

    post_html = build_raw_post(record["ad_html"])
    sent = await send_post(
        bot, CHANNEL_ID, post_html, photo=record.get("ad_photo"), parse_mode=HTML,
        reply_markup=kb_promo(record.get("ad_target", "")),
    )

    # Slot lock happens immediately after the channel post exists — not
    # gated on pinning at all. Bots generally cannot pin messages in a
    # public channel unless separately granted that specific admin
    # right (posting rights alone aren't enough), so pinning here is a
    # manual, out-of-band step for a human admin. Locking the slot
    # first means a failed/skipped pin can never cause a second
    # submission to slip through and get charged again.
    expires_at = time.time() + ADS_OF_DAY_HOURS * 3600
    await set_active_ad({
        "owner_id":       uid,
        "channel_msg_id": sent.message_id,
        "expires_at":     expires_at,
        "seller_username": record["seller_username"],
    })

    post_link = f"https://t.me/twinid/{sent.message_id}"
    pinned_automatically = False
    try:
        await bot.pin_chat_message(chat_id=CHANNEL_ID, message_id=sent.message_id, disable_notification=False)
        pinned_automatically = True
    except Exception as e:
        logger.info("Bot couldn't pin directly (expected if it only has posting rights): %s", e)

    await edit(cq.message,
        f"{pemoji(E_CHECK)}  {bold('Accepted & posted')}  — live for {ADS_OF_DAY_HOURS}h.\n\n"
        + (f"Pinned automatically." if pinned_automatically else
           f"{pemoji(E_FIRE)}  {bold('Pin it now:')}  {link('Open message', post_link)}"))
    await cq.answer("Posted!")
    if not pinned_automatically:
        # Urgent, separate nudge — the accepted-confirmation above can
        # get scrolled past, this is the one message admin needs to act
        # on right away for the slot to actually be visible as pinned.
        await bot.send_message(ADMIN_ID,
            f"{pemoji(E_FIRE)}  {bold('Pin needed — Ads of the Day is live')}\n\n"
            f"{link('Open the message', post_link)}  and pin it in the channel.",
            parse_mode=HTML)
    try:
        await bot.send_message(uid,
            f"{pemoji(E_FIRE)}  {bold('Your Ads of the Day is live!')}\n\n"
            f"Live on  {link('@twinid', 'https://t.me/twinid')}  for {ADS_OF_DAY_HOURS}h.",
            parse_mode=HTML)
    except Exception:
        pass


@router.callback_query(F.data.startswith("ads_reject:"))
async def cb_ads_reject(cq: CallbackQuery, bot: Bot):
    if cq.from_user.id != ADMIN_ID:
        await cq.answer("Admin only.", show_alert=True); return
    _, uid_str, token = cq.data.split(":", 2)
    uid = int(uid_str)

    record = await pop_pending_ad(uid, token)
    await edit(cq.message, f"{pemoji(E_CROSS)}  {bold('Rejected')}.")
    await cq.answer()
    if not record:
        return
    try:
        await bot.send_message(uid,
            f"{pemoji(E_CROSS)}  {bold('Your Ads of the Day submission was rejected.')}\n\n"
            f"Message  {link('@mvpzy', 'https://t.me/mvpzy')}  about a refund for the "
            f"⭐ {ADS_OF_DAY_STARS} Stars already charged — Stars refunds aren't "
            f"automatic and need an admin to process them.",
            parse_mode=HTML)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════
# Background: auto-unpin once the active slot expires
# ══════════════════════════════════════════════════════════════════════

async def run_ads_expiry_checker(bot: Bot, interval_seconds: int = 300):
    """Long-running loop, started once from bot.py. Polls rather than
    scheduling a one-shot timer so it also recovers correctly if the
    bot restarts mid-window — the expiry is stored on disk
    (get_active_ad), not held only in memory."""
    while True:
        try:
            active = await get_active_ad()
            if active and active.get("expires_at", 0) <= time.time():
                unpinned_automatically = False
                try:
                    await bot.unpin_chat_message(
                        chat_id=CHANNEL_ID, message_id=active["channel_msg_id"],
                    )
                    unpinned_automatically = True
                except Exception as e:
                    logger.info("Bot couldn't unpin directly (expected if it only has posting rights): %s", e)
                await clear_active_ad()
                logger.info("Ads of the Day slot expired and was cleared.")
                if not unpinned_automatically:
                    post_link = f"https://t.me/twinid/{active['channel_msg_id']}"
                    try:
                        await bot.send_message(ADMIN_ID,
                            f"{pemoji(E_FIRE)}  {bold('Unpin needed — Ads of the Day expired')}\n\n"
                            f"{link('Open the message', post_link)}  and unpin it — the slot is free again.",
                            parse_mode=HTML)
                    except Exception:
                        pass
        except Exception:
            logger.exception("Ads of the Day expiry checker failed this cycle.")
        await asyncio.sleep(interval_seconds)
