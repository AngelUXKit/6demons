"""
TwinIDBot — Credits handler
Balance (with user ID + KivaniCDK tag), Top Up, Send Tokens.
"""
from aiogram import Router, F, Bot
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery

from config import COST_PER_POST, TRANSFER_FEE_PCT, STAR_PACKAGES, TRUSTED_SELLER_VOUCHES
from db.database import get_user, get_credits, has_enough, transfer_credits, is_exclusive, get_user_tag, add_credits, get_vouches
from utils.ui import (
    send,
    edit,
    ibtn,
    kb_back_cancel,
    kb_cancel_only,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    msg_no_access,
    msg_low_credits,
    msg_invalid_input,
    E_CHECK,
    E_CROSS,
    E_CROWN,
    E_DIAMOND,
    E_GIFT,
    E_ID,
    E_MESSAGE,
    E_SEND,
    E_STAR,
    E_TOPUP,
    E_USER,

    BTN_BALANCE,
    BTN_SEND,
    BTN_TOPUP,
)
from aiogram.types import InlineKeyboardMarkup

router = Router()


class SendFlow(StatesGroup):
    waiting_recipient = State()
    waiting_amount    = State()
    confirming        = State()


def kb_send_confirm(to_id: int, amount: int, fee: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn(f"Send {amount}  (−{fee} fee)", f"send_confirm:{to_id}:{amount}", E_CHECK),
        ibtn("Cancel", "cancel", E_CROSS),
    ]])


# ══════════════════════════════════════════════════════════════════════
# Balance — shows balance + user ID + KivaniCDK tag
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("balance"))
@router.message(F.text == BTN_BALANCE)
async def cmd_balance(msg: Message):
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return

    bal        = user["credits"]
    excl       = await is_exclusive(uid)
    # get_user_tag() reads the tags table directly, which is the source
    # of truth for tag ownership. user["kivani_tag"] is a cached copy on
    # the user record that can fall out of sync (e.g. it was never
    # written on some historical accounts) — always prefer the live
    # lookup and only fall back to the cached value if that ever misses.
    kivani_tag = await get_user_tag(uid) or user.get("kivani_tag") or "—"
    vouches    = await get_vouches(uid)

    # Exclusive badge line
    excl_line = (
        f"\n{pemoji(E_CROWN)}  {bold('✦ EXCLUSIVE MEMBER ✦')}\n"
        if excl else ""
    )
    trusted_line = (
        f"\n{pemoji(E_CROWN)}  {bold('🏆 TRUSTED SELLER')}\n"
        if vouches >= TRUSTED_SELLER_VOUCHES else ""
    )

    await send(msg,
        f"{pemoji(E_DIAMOND)}  {bold('Your Account')}\n"
        f"{excl_line}{trusted_line}\n"
        f"{pemoji(E_USER)}  {bold('Name:')}   {esc(user['name'])}\n"
        f"{pemoji(E_ID)}  {bold('User ID:')}  {code(str(uid))}\n"
        f"{pemoji(E_MESSAGE)}  {bold('KivaniCDK:')}  {code(kivani_tag)}\n"
        f"{pemoji(E_CROWN)}  {bold('Vouches:')}  {vouches}\n\n"
        f"─────────────────────\n"
        f"{pemoji(E_STAR)}  {bold('Credits:')}  {bold(str(bal))}   {bold(usd(bal))}\n"
        f"{pemoji(E_GIFT)}  {bold('Posts left:')}  {bold(str(bal // COST_PER_POST))}"
    )


# ══════════════════════════════════════════════════════════════════════
# Top Up  —  Telegram Stars (self-serve) + manual admin fallback
# ══════════════════════════════════════════════════════════════════════

def kb_topup(uid: int) -> InlineKeyboardMarkup:
    rows = []
    for label, credit_amt, stars in STAR_PACKAGES:
        rows.append([ibtn(
            f"{label}  ·  {credit_amt:,} credits  ·  ⭐ {stars}",
            f"topup_stars:{credit_amt}:{stars}", E_STAR,
        )])
    rows.append([ibtn("Contact admin instead", "topup_manual", E_TOPUP)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text == BTN_TOPUP)
async def btn_topup(msg: Message):
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    bal = user["credits"]
    await send(msg,
        f"{pemoji(E_TOPUP)}  {bold('Top Up Credits')}\n\n"
        f"Current balance:  {bold(usd(bal))}  ({bal} credits)\n\n"
        f"Buy instantly with  {bold('Telegram Stars')}  — no waiting on an admin:",
        reply_markup=kb_topup(uid))


@router.callback_query(F.data == "topup_manual")
async def cb_topup_manual(cq: CallbackQuery):
    await edit(cq.message,
        f"{pemoji(E_TOPUP)}  {bold('Manual Top Up')}\n\n"
        f"Contact  {link('@mvpzy', 'https://t.me/mvpzy')}  to purchase credits.\n\n"
        f"Rate:  {bold('$1 = 1,000 credits')}")
    await cq.answer()


@router.callback_query(F.data.startswith("topup_stars:"))
async def cb_topup_stars(cq: CallbackQuery, bot: Bot):
    _, credit_amt, stars = cq.data.split(":")
    credit_amt, stars = int(credit_amt), int(stars)
    await bot.send_invoice(
        chat_id=cq.from_user.id,
        title=f"TwinID  ·  {credit_amt:,} Credits",
        description=f"Instant top-up of {credit_amt:,} TwinID credits, paid with Telegram Stars.",
        payload=f"topup:{cq.from_user.id}:{credit_amt}",
        currency="XTR",                       # Telegram Stars
        prices=[LabeledPrice(label=f"{credit_amt:,} credits", amount=stars)],
    )
    await cq.answer()


@router.pre_checkout_query()
async def process_pre_checkout(pcq: PreCheckoutQuery):
    # Stars payments must be approved within 10s of the query.
    await pcq.answer(ok=True)


@router.message(F.successful_payment.invoice_payload.startswith("topup:"))
async def process_successful_payment(msg: Message):
    payload = msg.successful_payment.invoice_payload
    try:
        _, uid_str, credit_amt_str = payload.split(":")
        uid, credit_amt = int(uid_str), int(credit_amt_str)
    except (ValueError, AttributeError):
        return
    await add_credits(uid, credit_amt)
    bal = await get_credits(uid)
    stars_paid = msg.successful_payment.total_amount
    await send(msg,
        f"{pemoji(E_DIAMOND)}  {bold('Top Up Complete!')}\n\n"
        f"Paid:  ⭐ {bold(str(stars_paid))}  Telegram Stars\n"
        f"Credited:  {bold(f'+{credit_amt:,}')}  credits\n\n"
        f"{pemoji(E_STAR)}  New balance:  {bold(usd(bal))}  ({bal} credits)")


# ══════════════════════════════════════════════════════════════════════
# Send Tokens
# ══════════════════════════════════════════════════════════════════════

@router.message(F.text == BTN_SEND)
async def btn_send(msg: Message, state: FSMContext):
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    if not user.get("tos_accepted"):
        await send(msg, f"{pemoji(E_CROSS)} Please accept the TOS first. Send /start."); return
    bal = user["credits"]
    await state.set_state(SendFlow.waiting_recipient)
    await send(msg,
        f"{pemoji(E_SEND)}  {bold('Send Tokens')}\n\n"
        f"Enter the Telegram ID of the recipient:\n\n"
        f"Your balance:  {bold(usd(bal))}  ({bal} credits)\n"
        f"Fee:  {bold('3%')}  deducted from sender.",
        reply_markup=kb_cancel_only())


@router.message(SendFlow.waiting_recipient)
async def send_recipient(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("Telegram ID", "Must be a numeric ID. Try again:"),
                   reply_markup=kb_cancel_only()); return
    to_id = int(raw)
    if to_id == msg.from_user.id:
        await send(msg, msg_invalid_input("recipient", "You can't send tokens to yourself."),
                   reply_markup=kb_cancel_only()); return
    recipient = await get_user(to_id)
    if not recipient:
        await send(msg, msg_invalid_input("recipient", "That user is not registered. Double-check the ID:"),
                   reply_markup=kb_cancel_only()); return
    await state.update_data(to_id=to_id, to_name=recipient["name"])
    await state.set_state(SendFlow.waiting_amount)
    await send(msg,
        f"{pemoji(E_SEND)}  {bold('Amount')}\n\n"
        f"Sending to:  {bold(esc(recipient['name']))}  ({to_id})\n\n"
        f"How many credits?  Example:  {bold('500')}",
        reply_markup=kb_back_cancel("back:send_recipient"))


@router.message(SendFlow.waiting_amount)
async def send_amount(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await send(msg, msg_invalid_input("amount", "Enter a positive whole number, e.g. 500:"),
                   reply_markup=kb_back_cancel("back:send_recipient")); return
    amount = int(raw)
    import math
    fee    = max(1, int(amount * TRANSFER_FEE_PCT))
    total  = amount + fee
    data   = await state.get_data()
    bal    = await get_credits(msg.from_user.id)
    if bal < total:
        await send(msg, msg_low_credits(bal, total),
                   reply_markup=kb_back_cancel("back:send_recipient")); return
    await state.update_data(amount=amount, fee=fee)
    await state.set_state(SendFlow.confirming)
    await send(msg,
        f"{pemoji(E_SEND)}  {bold('Confirm Transfer')}\n\n"
        f"To:  {bold(esc(data['to_name']))}  ({code(str(data['to_id']))})\n"
        f"Amount:  {bold(str(amount))}  credits\n"
        f"Fee:  {bold(str(fee))}  credits  (3%)\n"
        f"Total deducted:  {bold(str(total))}  credits\n\n"
        f"Balance after:  {bold(str(bal - total))}  credits",
        reply_markup=kb_send_confirm(data["to_id"], amount, fee))


@router.callback_query(F.data == "back:send_recipient")
async def back_send_recipient(cq: CallbackQuery, state: FSMContext):
    uid  = cq.from_user.id
    user = await get_user(uid)
    bal  = user["credits"] if user else 0
    await state.set_state(SendFlow.waiting_recipient)
    await edit(cq.message,
        f"{pemoji(E_SEND)}  {bold('Send Tokens')}\n\n"
        f"Enter the Telegram ID of the recipient:\n\n"
        f"Your balance:  {bold(usd(bal))}  ({bal} credits)\n"
        f"Fee:  {bold('3%')}  deducted from sender.",
        reply_markup=kb_cancel_only())
    await cq.answer()


@router.callback_query(SendFlow.confirming, F.data.startswith("send_confirm:"))
async def cb_send_confirm(cq: CallbackQuery, state: FSMContext):
    parts  = cq.data.split(":")
    to_id  = int(parts[1])
    amount = int(parts[2])
    ok, note = await transfer_credits(cq.from_user.id, to_id, amount)
    await state.clear()
    if ok:
        bal = await get_credits(cq.from_user.id)
        await edit(cq.message,
            f"{pemoji(E_CHECK)}  {bold('Sent!')}\n\n"
            f"{esc(note)}\n\n"
            f"{pemoji(E_DIAMOND)}  New balance:  {bold(str(bal))}  ({usd(bal)})")
    else:
        await edit(cq.message,
            f"{pemoji(E_CROSS)}  {bold('Transfer failed')}\n\n{esc(note)}")
    await cq.answer()