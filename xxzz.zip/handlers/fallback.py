"""TwinIDBot — /help and fallback handler."""
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from config import COST_PER_POST
from utils.ui import send, pemoji, bold, code, link, usd, E_STAR, E_DIAMOND, E_BOLT, E_GIFT, E_MESSAGE, E_TROPHY, E_SEND, E_USER, E_CROWN, HTML

router = Router()

HELP_TEXT = (
    f"{pemoji(E_STAR)}  {bold('TWINID — Help')}\n\n"
    f"{pemoji(E_BOLT)}  {bold('New Post')} — List a handle, username or account\n"
    f"{pemoji(E_GIFT)}  {bold('Gifts & NFTs')} — List +888 numbers, TON gifts or NFTs\n"
    f"{pemoji(E_DIAMOND)}  {bold('Balance')} — View your credits, User ID and KivaniCDK tag\n"
    f"{pemoji(E_SEND)}  {bold('Top Up')} — Add credits to your account\n"
    f"{pemoji(E_SEND)}  {bold('Send')} — Transfer credits to another user\n"
    f"{pemoji(E_MESSAGE)}  {bold('KivaniCDK')} — Register a twin tag and message sellers anonymously\n"
    f"{pemoji(E_TROPHY)}  {bold('Manage')} — Edit or delete your active posts\n\n"
    f"Post cost:  {bold(usd(COST_PER_POST))}  per listing\n"
    f"New users receive  {bold('$2.00')}  free credits on signup\n\n"
    f"Support:  {link('@mvpzy', 'https://t.me/mvpzy')}\n"
    f"Channel:  {link('@twinid', 'https://t.me/twinid')}"
)


@router.message(Command("help"))
async def cmd_help(msg: Message):
    await send(msg, HELP_TEXT)


@router.message(F.chat.type == "private")
async def fallback_private(msg: Message):
    """Private chats with the bot: reply to anything unrecognized —
    it's a 1:1 conversation, so a nudge toward /help is expected."""
    await send(msg,
        f"{pemoji(E_STAR)}  {bold('Not a command.')}\n\n"
        f"Use  /help  to see available commands.")


@router.message(F.chat.type.in_({"group", "supergroup"}), F.text.startswith("/"))
async def fallback_group_unknown_command(msg: Message):
    """Groups: only ever reply to something that actually looks like an
    attempted command (starts with '/'). Member joins/leaves, pins,
    media, stickers, and ordinary chatter are left completely alone —
    a bot chiming in on every group event reads as broken/spammy, not
    helpful. This naturally also excludes service messages (joins,
    leaves, etc.), since those carry no message text to match against."""
    await send(msg,
        f"{pemoji(E_STAR)}  {bold('Not a command.')}\n\n"
        f"Use  /help  to see available commands.")
