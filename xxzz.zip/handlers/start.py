"""
TwinIDBot — /start  + TOS flow
"""
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup

from config import NEW_USER_BONUS, COST_PER_POST, ADMIN_ID
from db.database import get_user, add_user, update_user_field, add_credits, is_exclusive, get_user_tag
from utils.ui import (
    HTML,
    send,
    edit,
    main_keyboard,
    ibtn,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    msg_no_access,
    E_BOLT,
    E_CHECK,
    E_CROSS,
    E_CROWN,
    E_DIAMOND,
    E_GIFT,
    E_MESSAGE,
    E_SHIELD,
    E_STAR,
    E_USER,
)

router = Router()


def kb_tos() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("I Accept",  "tos:accept",  E_CHECK),
        ibtn("I Decline", "tos:decline", E_CROSS),
    ]])


# Plain text TOS — NO pemoji/tg-emoji tags here, Telegram rejects unknown emoji doc IDs
TOS_TEXT = (
    f"{bold('TWINID — Terms of Service')}\n\n"
    "By using this bot you agree to the following:\n\n"
    f"{bold('1. Authenticity')} — You may only list handles, usernames, numbers, "
    "gifts or NFTs that you genuinely own. Listing items you do not own is strictly "
    "prohibited and will result in an immediate ban.\n\n"
    f"{bold('2. No Scamming')} — Any attempt to defraud buyers or sellers will "
    "result in permanent removal from the platform and may be reported to Telegram.\n\n"
    f"{bold('3. Accurate Listings')} — All prices and details must be truthful. "
    "Misleading listings will be removed without refund.\n\n"
    f"{bold('4. No Spam')} — Do not flood the channel with duplicate posts.\n\n"
    f"{bold('5. KivaniCDK')} — The private messaging tag is for legitimate buyer-seller "
    "communication. Abuse will result in tag revocation.\n\n"
    f"{bold('6. Liability')} — TWINID acts as a listing platform only. We are not "
    "responsible for transactions between users.\n\n"
    "Tap  <b>I Accept</b>  to proceed, or  <b>I Decline</b>  to exit."
)


@router.message(CommandStart())
async def cmd_start(msg: Message, state: FSMContext):
    await state.clear()
    uid  = msg.from_user.id
    name = msg.from_user.full_name or str(uid)

    # ── Admin: auto-register if needed, then show panel ───────────────
    if uid == ADMIN_ID:
        user = await get_user(uid)
        if not user:
            await add_user(uid, name, NEW_USER_BONUS)
            await update_user_field(uid, "tos_accepted", True)
        await send(msg,
            f"{pemoji(E_CROWN)}  {bold('TWINID Admin Panel')}\n\n"
            f"Use {bold('/admin')} to manage users, exclusive members and credits.",
            reply_markup=main_keyboard())
        return

    user = await get_user(uid)

    # ── Returning user who already accepted TOS ────────────────────────
    if user and user.get("tos_accepted"):
        bal    = user["credits"]
        excl   = await is_exclusive(uid)
        # Source from the tags table (authoritative) first — the cached
        # kivani_tag field on the user record can fall out of sync.
        kivani = await get_user_tag(uid) or user.get("kivani_tag") or "—"
        excl_line = f"\n{pemoji(E_CROWN)}  {bold('EXCLUSIVE MEMBER')}\n" if excl else ""
        await send(msg,
            f"{pemoji(E_DIAMOND)}  {bold('Welcome back to TWINID!')}{excl_line}\n\n"
            f"{pemoji(E_USER)}  {esc(msg.from_user.first_name)}\n\n"
            f"{pemoji(E_STAR)}  Balance   {bold(usd(bal))}  ({bal} credits)\n"
            f"{pemoji(E_GIFT)}  Posts left  {bold(str(bal // COST_PER_POST))}\n"
            f"{pemoji(E_MESSAGE)}  KivaniCDK   {code(kivani)}\n\n"
            f"Tap  {bold('New Post')}  to list something.",
            reply_markup=main_keyboard())
        return

    # ── New user or user who hasn't accepted TOS yet ───────────────────
    if not user:
        await add_user(uid, name, 0)   # register with 0; bonus given on TOS accept

    await send(msg, TOS_TEXT, reply_markup=kb_tos())


# ── TOS accept ────────────────────────────────────────────────────────

@router.callback_query(F.data == "tos:accept")
async def tos_accept(cq: CallbackQuery):
    uid  = cq.from_user.id
    user = await get_user(uid)
    if not user:
        # edge case: create user if somehow missing
        name = cq.from_user.full_name or str(uid)
        await add_user(uid, name, 0)

    already_accepted = user and user.get("tos_accepted", False)
    await update_user_field(uid, "tos_accepted", True)

    if not already_accepted:
        # First-time accept — grant bonus
        await add_credits(uid, NEW_USER_BONUS)
        posts_free = NEW_USER_BONUS // COST_PER_POST
        await edit(cq.message,
            f"{bold('Welcome to TWINID!')} 🎉\n\n"
            f"{pemoji(E_USER)}  {esc(cq.from_user.first_name)}\n\n"
            f"You have received a  {bold(usd(NEW_USER_BONUS))}  new-user bonus!\n"
            f"That's  {bold(str(posts_free))}  free posts to get you started.\n\n"
            f"Tap  {bold('New Post')}  to list your first item.")
    else:
        await edit(cq.message,
            f"{pemoji(E_CHECK)}  {bold('TOS Accepted')}  — welcome back!\n\n"
            "All features are now unlocked.")

    await cq.message.answer(
        f"{pemoji(E_DIAMOND)}  {bold('Ready!')}",
        parse_mode=HTML,
        reply_markup=main_keyboard())
    await cq.answer("Accepted!")


# ── TOS decline ───────────────────────────────────────────────────────

@router.callback_query(F.data == "tos:decline")
async def tos_decline(cq: CallbackQuery):
    await edit(cq.message,
        f"{bold('TOS Declined')}\n\n"
        "You must accept the Terms of Service to use TWINID.\n"
        "Send /start at any time to try again.")
    await cq.answer("TOS not accepted.")
