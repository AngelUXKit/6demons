"""
TwinIDBot — Moderation module (TwinGuard, merged in)
──────────────────────────────────────────────────────────────────────
Runs inside TwinIDBot itself rather than as a second bot/process —
one set of credentials, one running process, and it only does
anything at all in chats the owner has explicitly enabled via /admin
(see handlers/admin.py's "TwinGuard" section). Every handler here
checks is_moderation_enabled() first and raises SkipHandler
immediately if the chat isn't opted in, so disabled chats cost
nothing beyond that one cheap dict lookup.

Features:
- Any text/caption message over MOD_AD_WORD_LIMIT words gets deleted
  (treated as an ad/spam wall), with a short-lived notice. Chat admins
  of that specific group are exempt.
- "X joined/left the group" service messages are always logged (so
  /wipealljoins has something to act on even before the live toggle
  is turned on), and deleted the instant they arrive if that chat has
  delete_joins on.
- /modconfig — per-chat admin-only settings (currently: the
  delete_joins toggle).
- /wipeall — per-chat admin-only, deletes every message TwinGuard has
  logged in this chat. Confirm-gated, irreversible.
- /wipealljoins — per-chat admin-only, deletes every logged
  join/leave message right now regardless of the toggle's state.

IMPORTANT LIMITATION: a bot cannot fetch a group's message history —
there's no Bot API method for it. /wipeall and /wipealljoins can only
ever act on messages TwinGuard has personally logged since moderation
was enabled for that chat, not the chat's entire lifetime history.

Bad-word filtering intentionally not included yet.
"""
import asyncio

from aiogram import Router, F, Bot, BaseMiddleware
from aiogram.filters import Command
from aiogram.dispatcher.event.bases import SkipHandler
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from config import MOD_AD_WORD_LIMIT, MOD_NOTICE_LIFETIME
from db.database import (
    is_moderation_enabled, get_delete_joins, set_delete_joins,
    log_mod_message, get_mod_message_ids, clear_mod_messages,
)
from utils.ui import is_group_admin, bulk_delete, delete_after, mention_user, pemoji, bold, E_FIRE, E_CHECK, E_CROSS

router = Router()


class ModerationLoggerMiddleware(BaseMiddleware):
    """Outer middleware, registered in bot.py — logs every message id
    in chats that have moderation enabled, which is the only thing
    that makes /wipeall and /wipealljoins possible at all (Telegram
    gives bots no way to fetch history; this is what builds the list
    of what's actually deletable). Scoped to enabled group chats only
    so it costs nothing anywhere else in the bot."""
    async def __call__(self, handler, event: Message, data):
        if event.chat.type in ("group", "supergroup") and await is_moderation_enabled(event.chat.id):
            is_join_event = bool(event.new_chat_members or event.left_chat_member)
            await log_mod_message(event.chat.id, event.message_id, is_join_event)
        return await handler(event, data)


def _word_count(text: str) -> int:
    return len(text.split())


# ══════════════════════════════════════════════════════════════════════
# Ad / spam wall filter — word-count based
# ══════════════════════════════════════════════════════════════════════

@router.message(F.chat.type.in_({"group", "supergroup"}), F.text | F.caption)
async def enforce_word_limit(msg: Message, bot: Bot):
    if not msg.from_user or msg.from_user.is_bot:
        raise SkipHandler  # never moderate service/bot-authored content (avoids self-loops)
    if not await is_moderation_enabled(msg.chat.id):
        raise SkipHandler  # not opted in — every other handler in the bot still runs normally

    text = msg.text or msg.caption or ""
    if _word_count(text) <= MOD_AD_WORD_LIMIT:
        raise SkipHandler  # not an ad wall — let /commands and everything else still be checked
    if await is_group_admin(bot, msg.chat.id, msg.from_user.id):
        raise SkipHandler  # admins of *this* group are exempt from this filter

    try:
        await bot.delete_message(msg.chat.id, msg.message_id)
    except Exception:
        raise SkipHandler  # no delete rights here — nothing more this handler can do

    notice = await bot.send_message(
        msg.chat.id,
        f"🗑  {mention_user(msg.from_user)}'s message was deleted for exceeding the "
        f"{MOD_AD_WORD_LIMIT}-word limit (treated as an ad/spam wall).",
        parse_mode="HTML",
    )
    asyncio.create_task(delete_after(bot, msg.chat.id, notice.message_id, MOD_NOTICE_LIFETIME))


# ══════════════════════════════════════════════════════════════════════
# Join / leave events
# ══════════════════════════════════════════════════════════════════════

@router.message(F.new_chat_members | F.left_chat_member)
async def handle_join_leave(msg: Message, bot: Bot):
    if not await is_moderation_enabled(msg.chat.id):
        raise SkipHandler
    if not await get_delete_joins(msg.chat.id):
        raise SkipHandler  # logging middleware already recorded it either way
    try:
        await bot.delete_message(msg.chat.id, msg.message_id)
    except Exception:
        raise SkipHandler


# ══════════════════════════════════════════════════════════════════════
# /modconfig — per-chat settings (admin of that specific group)
# ══════════════════════════════════════════════════════════════════════

def _modconfig_kb(delete_joins: bool) -> InlineKeyboardMarkup:
    label = "✅ Delete join/leave messages: ON" if delete_joins else "⬜ Delete join/leave messages: OFF"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=label, callback_data="modcfg:toggle_joins"),
    ]])


@router.message(Command("modconfig"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_modconfig(msg: Message, bot: Bot):
    if not await is_moderation_enabled(msg.chat.id):
        raise SkipHandler
    if not await is_group_admin(bot, msg.chat.id, msg.from_user.id):
        raise SkipHandler
    delete_joins = await get_delete_joins(msg.chat.id)
    await msg.answer(
        f"{pemoji(E_FIRE)}  {bold('TwinGuard Settings')}\n\nTap to toggle.",
        parse_mode="HTML", reply_markup=_modconfig_kb(delete_joins),
    )


@router.callback_query(F.data == "modcfg:toggle_joins")
async def cb_modconfig_toggle(cq: CallbackQuery, bot: Bot):
    if not await is_group_admin(bot, cq.message.chat.id, cq.from_user.id):
        await cq.answer("Admins only.", show_alert=True); return
    new_val = not await get_delete_joins(cq.message.chat.id)
    await set_delete_joins(cq.message.chat.id, new_val)
    await cq.message.edit_reply_markup(reply_markup=_modconfig_kb(new_val))
    await cq.answer("Updated.")


# ══════════════════════════════════════════════════════════════════════
# /wipeall — nuke every logged message in this chat (confirm required)
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("wipeall"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_wipeall(msg: Message, bot: Bot):
    if not await is_moderation_enabled(msg.chat.id):
        raise SkipHandler
    if not await is_group_admin(bot, msg.chat.id, msg.from_user.id):
        raise SkipHandler
    ids = await get_mod_message_ids(msg.chat.id)
    if not ids:
        await msg.answer("Nothing logged to wipe yet."); return
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=f"Confirm — wipe {len(ids)} messages", callback_data="wipeall:confirm"),
        InlineKeyboardButton(text="Cancel", callback_data="wipeall:cancel"),
    ]])
    await msg.answer(
        f"⚠️  This deletes all <b>{len(ids)}</b> messages TwinGuard has logged in this "
        f"chat since moderation was enabled. Older history isn't reachable — Telegram "
        f"doesn't let bots fetch chat history. This can't be undone.",
        parse_mode="HTML", reply_markup=kb,
    )


@router.callback_query(F.data == "wipeall:confirm")
async def cb_wipeall_confirm(cq: CallbackQuery, bot: Bot):
    if not await is_group_admin(bot, cq.message.chat.id, cq.from_user.id):
        await cq.answer("Admins only.", show_alert=True); return
    ids = await get_mod_message_ids(cq.message.chat.id)
    await cq.message.edit_text(f"Wiping {len(ids)} messages…")
    deleted = await bulk_delete(bot, cq.message.chat.id, ids)
    await clear_mod_messages(cq.message.chat.id, ids)
    try:
        await cq.message.edit_text(f"✅  Wiped {deleted} messages.")
    except Exception:
        pass  # this message may itself have been among the ones just deleted
    await cq.answer()


@router.callback_query(F.data == "wipeall:cancel")
async def cb_wipeall_cancel(cq: CallbackQuery, bot: Bot):
    if not await is_group_admin(bot, cq.message.chat.id, cq.from_user.id):
        await cq.answer("Admins only.", show_alert=True); return
    await cq.message.edit_text("Cancelled — nothing was deleted.")
    await cq.answer()


# ══════════════════════════════════════════════════════════════════════
# /wipealljoins — nuke every logged join/leave message right now
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("wipealljoins"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_wipealljoins(msg: Message, bot: Bot):
    if not await is_moderation_enabled(msg.chat.id):
        raise SkipHandler
    if not await is_group_admin(bot, msg.chat.id, msg.from_user.id):
        raise SkipHandler
    ids = await get_mod_message_ids(msg.chat.id, joins_only=True)
    if not ids:
        await msg.answer("No join/leave messages logged to wipe."); return
    status = await msg.answer(f"Wiping {len(ids)} join/leave messages…")
    deleted = await bulk_delete(bot, msg.chat.id, ids)
    await clear_mod_messages(msg.chat.id, ids)
    try:
        await status.edit_text(f"✅  Wiped {deleted} join/leave messages.")
    except Exception:
        pass
