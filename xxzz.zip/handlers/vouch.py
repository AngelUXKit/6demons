"""
TwinIDBot — Vouches / Reputation
OGUsers-style trust layer: after a deal, the buyer vouches for the seller
with the post's ID. Vouches accumulate on the seller's profile and unlock
a public "Trusted Seller" badge shown on future ID cards and posts —
the same social-proof pattern that made OGUsers' vouch count the de facto
trust signal for handle/account trading.
"""
from aiogram import Router, F
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from config import TRUSTED_SELLER_VOUCHES
from db.database import get_user, add_vouch, get_vouches, get_post, get_tag_owner
from utils.ui import (
    send,
    pemoji,
    bold,
    code,
    esc,
    msg_no_access,
    msg_invalid_input,
    E_TROPHY,
    E_CHECK,
    E_CROSS,
)

router = Router()


@router.message(Command("vouch"))
async def cmd_vouch(msg: Message, command: CommandObject):
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return

    if not command.args:
        await send(msg,
            f"{pemoji(E_TROPHY)}  {bold('Vouch for a Seller')}\n\n"
            f"Completed a deal? Vouch for the seller so future buyers can trust them:\n"
            f"{code('/vouch TW-XXXXXXXX')}\n\n"
            f"One vouch per completed deal. Vouches are public and build a seller's "
            f"reputation — reach {bold(str(TRUSTED_SELLER_VOUCHES))} to unlock the "
            f"{bold('Trusted Seller')} badge.")
        return

    post_id = command.args.strip().upper()
    ok, result = await add_vouch(post_id, uid)
    if not ok:
        await send(msg, msg_invalid_input("vouch", result)); return

    count = int(result)
    unlocked = (
        f"\n\n{pemoji(E_TROPHY)}  {bold('Trusted Seller badge unlocked!')}"
        if count == TRUSTED_SELLER_VOUCHES else ""
    )
    await send(msg,
        f"{pemoji(E_CHECK)}  {bold('Vouch recorded!')}\n\n"
        f"This seller now has  {bold(str(count))}  {'vouch' if count == 1 else 'vouches'}."
        f"{unlocked}")


@router.message(Command("rep"))
async def cmd_rep(msg: Message, command: CommandObject):
    """Look up a seller's public reputation via whichever identifier
    they have handy: /rep <telegram_id>, /rep <KivaniCDK tag>, or
    /rep <post ID> (any listing that belongs to them)."""
    raw = (command.args or "").strip()
    if not raw:
        await send(msg,
            f"{pemoji(E_TROPHY)}  {bold('Check Reputation')}\n\n"
            f"{code('/rep <telegram_id>')}\n"
            f"{code('/rep <kivani tag>')}\n"
            f"{code('/rep <post ID>')}\n\n"
            f"Any of the three works — view a seller's vouch count."); return

    target_id: int | None = None
    if raw.lstrip("-").isdigit():
        target_id = int(raw)
    elif raw.upper().startswith("TW-"):
        post = await get_post(raw.upper())
        if post:
            target_id = post.get("owner_id")
    else:
        target_id = await get_tag_owner(raw)

    if target_id is None:
        await send(msg, msg_invalid_input(
            "identifier", "No user found for that telegram ID, Kivani tag, or post ID.")); return

    target = await get_user(target_id)
    if not target:
        await send(msg, msg_invalid_input("user", "That user isn't registered.")); return
    count   = await get_vouches(target_id)
    trusted = count >= TRUSTED_SELLER_VOUCHES
    badge   = f"  {pemoji(E_TROPHY)} {bold('Trusted Seller')}" if trusted else ""
    await send(msg,
        f"{pemoji(E_TROPHY)}  {bold(esc(target['name']))}{badge}\n\n"
        f"Vouches:  {bold(str(count))}")
