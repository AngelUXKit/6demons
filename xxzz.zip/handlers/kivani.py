"""
TwinIDBot — KivaniCDK Private Messaging
Register twinXXX tag, send & receive anonymous messages.
"""
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup

from config import KIVANI_CREATE_FEE, KIVANI_CHANGE_FEE
from db.database import (
    get_user, has_enough, deduct_credits, get_credits,
    get_user_tag, register_tag, tag_exists, get_tag_owner, change_tag,
    update_user_field, send_kivani_message, get_kivani_inbox,
)
from utils.ui import (
    HTML,
    send,
    edit,
    ibtn,
    kb_back_cancel,
    kb_cancel_only,
    pemoji,
    bold,
    italic,
    code,
    link,
    esc,
    usd,
    is_valid_kivani_tag,
    msg_no_access,
    msg_low_credits,
    msg_invalid_input,
    E_BACK,
    E_BELL,
    E_CHECK,
    E_CROSS,
    E_INBOX,
    E_KEY,
    E_MESSAGE,
    E_USER,

    BTN_KIVANI,
)

router = Router()


# ── FSM ───────────────────────────────────────────────────────────────

class KivaniFlow(StatesGroup):
    registering_tag   = State()
    changing_tag      = State()
    composing_message = State()   # sub-state: recipient stored in FSM data
    entering_recipient = State()


# ── Keyboards ─────────────────────────────────────────────────────────

def kb_kivani_home(has_tag: bool) -> InlineKeyboardMarkup:
    rows = []
    if has_tag:
        rows.append([
            ibtn("Inbox",       "kivani:inbox",   E_INBOX),
            ibtn("Send Message", "kivani:compose", E_MESSAGE),
        ])
        rows.append([
            ibtn("Change Tag",   "kivani:change",  E_KEY),
        ])
    else:
        rows.append([ibtn("Register Tag", "kivani:register", E_CHECK)])
    rows.append([ibtn("Close", "cancel", E_CROSS)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def kb_confirm_tag(tag: str, is_change: bool) -> InlineKeyboardMarkup:
    fee  = KIVANI_CHANGE_FEE if is_change else KIVANI_CREATE_FEE
    action = "change" if is_change else "register"
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn(f"Confirm  (−{usd(fee)})", f"kivani:confirm_{action}:{tag}", E_CHECK),
        ibtn("Cancel", "cancel", E_CROSS),
    ]])


# ══════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════

@router.message(F.text == BTN_KIVANI)
@router.message(Command("kivani"))
async def btn_kivani(msg: Message, state: FSMContext):
    await state.clear()
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    if not user.get("tos_accepted"):
        await send(msg, f"{pemoji(E_CROSS)} Accept TOS first. Send /start."); return

    tag = await get_user_tag(uid)
    tag_display = code(tag) if tag else italic("Not registered")

    await send(msg,
        f"{pemoji(E_MESSAGE)}  {bold('KivaniCDK  —  Private Messaging')}\n\n"
        f"Send and receive anonymous messages using your unique  twin tag.\n\n"
        f"Your tag:   {tag_display}\n\n"
        f"{'Active' if tag else 'No tag — register for  ' + bold(usd(KIVANI_CREATE_FEE))}\n\n"
        f"Fees:\n"
        f"  Create tag  {bold(usd(KIVANI_CREATE_FEE))}\n"
        f"  Change tag   {bold(usd(KIVANI_CHANGE_FEE))}",
        reply_markup=kb_kivani_home(bool(tag)))


# ══════════════════════════════════════════════════════════════════════
# Register tag
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "kivani:register")
async def cb_register(cq: CallbackQuery, state: FSMContext):
    uid = cq.from_user.id
    if not await has_enough(uid, KIVANI_CREATE_FEE):
        await edit(cq.message, msg_low_credits(await get_credits(uid), KIVANI_CREATE_FEE)); return
    await state.set_state(KivaniFlow.registering_tag)
    await edit(cq.message,
        f"{pemoji(E_KEY)}  {bold('Register KivaniCDK Tag')}\n\n"
        f"Choose your tag:  {bold('twin')}  followed by  {bold('3 digits')}\n\n"
        f"Examples:  {code('twin001')}  ·  {code('twin420')}  ·  {code('twin999')}\n\n"
        f"Cost:  {bold(usd(KIVANI_CREATE_FEE))}  (one-time)\n"
        f"Your tag is permanent unless you change it for  {bold(usd(KIVANI_CHANGE_FEE))}.",
        reply_markup=kb_back_cancel("back:kivani_home"))
    await cq.answer()


@router.message(KivaniFlow.registering_tag)
async def fsm_register_tag(msg: Message, state: FSMContext):
    if not msg.text:
        await send(msg, msg_invalid_input("tag",
            "Please send your tag as plain text.  Example:  twin420"),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    raw = (msg.text or "").strip().lower()
    if not is_valid_kivani_tag(raw):
        await send(msg, msg_invalid_input("tag",
            "Must be  twin  + 3 digits.  Examples:  twin001  twin420"),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    if await tag_exists(raw):
        await send(msg, msg_invalid_input("tag",
            f"{code(raw)}  is already taken. Choose another:"),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    await state.update_data(pending_tag=raw)
    await send(msg,
        f"{pemoji(E_CHECK)}  Tag  {code(raw)}  is available!\n\n"
        f"Cost:  {bold(usd(KIVANI_CREATE_FEE))}",
        reply_markup=kb_confirm_tag(raw, is_change=False))


@router.callback_query(F.data.startswith("kivani:confirm_register:"))
async def cb_confirm_register(cq: CallbackQuery, state: FSMContext):
    tag = cq.data.split(":", 2)[2]
    uid = cq.from_user.id
    if not await has_enough(uid, KIVANI_CREATE_FEE):
        await edit(cq.message, msg_low_credits(await get_credits(uid), KIVANI_CREATE_FEE))
        await state.clear(); return
    # Check again (race-condition guard)
    if await tag_exists(tag):
        await edit(cq.message, msg_invalid_input("tag", f"{code(tag)} was just taken. Pick another."))
        await state.set_state(KivaniFlow.registering_tag); return

    ok = await register_tag(tag, uid)
    if not ok:
        await edit(cq.message, msg_invalid_input("tag", "Tag could not be registered. Try a different one."))
        await state.set_state(KivaniFlow.registering_tag); return

    await deduct_credits(uid, KIVANI_CREATE_FEE)
    await update_user_field(uid, "kivani_tag", tag)
    await state.clear()
    await edit(cq.message,
        f"{pemoji(E_CHECK)}  {bold('Tag Registered!')}\n\n"
        f"Your KivaniCDK tag:  {code(tag)}\n\n"
        f"Share this tag so buyers can message you anonymously.\n"
        f"When you post to the channel, this tag will be shown so anyone can DM you via bot.")
    await cq.answer("Tag registered!")


# ══════════════════════════════════════════════════════════════════════
# Change tag
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "kivani:change")
async def cb_change_tag(cq: CallbackQuery, state: FSMContext):
    uid = cq.from_user.id
    if not await has_enough(uid, KIVANI_CHANGE_FEE):
        await edit(cq.message, msg_low_credits(await get_credits(uid), KIVANI_CHANGE_FEE)); return
    await state.set_state(KivaniFlow.changing_tag)
    await edit(cq.message,
        f"{pemoji(E_KEY)}  {bold('Change KivaniCDK Tag')}\n\n"
        f"Send your new  {bold('twin')}  + 3-digit tag.\n\n"
        f"Cost:  {bold(usd(KIVANI_CHANGE_FEE))}",
        reply_markup=kb_back_cancel("back:kivani_home"))
    await cq.answer()


@router.message(KivaniFlow.changing_tag)
async def fsm_change_tag(msg: Message, state: FSMContext):
    uid = msg.from_user.id
    raw = (msg.text or "").strip().lower()
    if not is_valid_kivani_tag(raw):
        await send(msg, msg_invalid_input("tag", "Must be twin + 3 digits."),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    if await tag_exists(raw):
        await send(msg, msg_invalid_input("tag", f"{code(raw)} is already taken."),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    old_tag = await get_user_tag(uid) or ""
    await state.update_data(pending_tag=raw, old_tag=old_tag)
    await send(msg,
        f"{pemoji(E_KEY)}  Change  {code(old_tag)}  →  {code(raw)}\n\n"
        f"Cost:  {bold(usd(KIVANI_CHANGE_FEE))}",
        reply_markup=kb_confirm_tag(raw, is_change=True))


@router.callback_query(F.data.startswith("kivani:confirm_change:"))
async def cb_confirm_change(cq: CallbackQuery, state: FSMContext):
    new_tag = cq.data.split(":", 2)[2]
    uid     = cq.from_user.id
    data    = await state.get_data()
    old_tag = data.get("old_tag", "")
    if not await has_enough(uid, KIVANI_CHANGE_FEE):
        await edit(cq.message, msg_low_credits(await get_credits(uid), KIVANI_CHANGE_FEE))
        await state.clear(); return
    ok = await change_tag(old_tag, new_tag, uid)
    if not ok:
        await edit(cq.message, msg_invalid_input("tag", f"{code(new_tag)} was just taken."))
        await state.set_state(KivaniFlow.changing_tag); return
    await deduct_credits(uid, KIVANI_CHANGE_FEE)
    await update_user_field(uid, "kivani_tag", new_tag)
    await state.clear()
    await edit(cq.message,
        f"{pemoji(E_CHECK)}  {bold('Tag Updated!')}\n\n"
        f"Old:  {code(old_tag)}\n"
        f"New:  {code(new_tag)}")
    await cq.answer("Tag changed!")


# ══════════════════════════════════════════════════════════════════════
# Send a KivaniCDK message
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "kivani:compose")
async def cb_compose(cq: CallbackQuery, state: FSMContext):
    uid = cq.from_user.id
    tag = await get_user_tag(uid)
    if not tag:
        await cq.answer("Register a tag first.", show_alert=True); return
    await state.set_state(KivaniFlow.entering_recipient)
    await edit(cq.message,
        f"{pemoji(E_MESSAGE)}  {bold('Send Anonymous Message')}\n\n"
        f"Enter the recipient's KivaniCDK tag:\n"
        f"Example:  {code('twin042')}",
        reply_markup=kb_back_cancel("back:kivani_home"))
    await cq.answer()


@router.message(KivaniFlow.entering_recipient)
async def fsm_enter_recipient(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip().lower()
    if not is_valid_kivani_tag(raw):
        await send(msg, msg_invalid_input("tag", "Must be twin + 3 digits."),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    uid     = msg.from_user.id
    my_tag  = await get_user_tag(uid)
    if raw == my_tag:
        await send(msg, msg_invalid_input("tag", "You can't message yourself."),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    if not await tag_exists(raw):
        await send(msg, msg_invalid_input("tag", f"{code(raw)} is not registered. Check and retry:"),
                   reply_markup=kb_back_cancel("back:kivani_home")); return
    await state.update_data(recipient_tag=raw)
    await state.set_state(KivaniFlow.composing_message)
    await send(msg,
        f"{pemoji(E_MESSAGE)}  To:  {code(raw)}\n\n"
        f"Type your message.  The recipient won't see your name — only your tag  {code(my_tag or '?')}.",
        reply_markup=kb_back_cancel("back:kivani_recipient"))


@router.callback_query(F.data == "back:kivani_recipient")
async def back_kivani_recipient(cq: CallbackQuery, state: FSMContext):
    await state.set_state(KivaniFlow.entering_recipient)
    await edit(cq.message,
        f"{pemoji(E_MESSAGE)}  Enter the recipient's KivaniCDK tag:",
        reply_markup=kb_back_cancel("back:kivani_home"))
    await cq.answer()


@router.message(KivaniFlow.composing_message)
async def fsm_compose_message(msg: Message, state: FSMContext, bot: Bot):
    text = (msg.text or "").strip()
    if not text:
        await send(msg, msg_invalid_input("message", "Message can't be empty."),
                   reply_markup=kb_back_cancel("back:kivani_recipient")); return

    uid          = msg.from_user.id
    data         = await state.get_data()
    sender_tag   = await get_user_tag(uid) or "unknown"
    receiver_tag = data.get("recipient_tag", "")

    await send_kivani_message(sender_tag, receiver_tag, text)

    # Deliver to recipient in-bot (if online)
    try:
        receiver_uid = await get_tag_owner(receiver_tag)
        if receiver_uid:
            await bot.send_message(
                receiver_uid,
                f"{pemoji(E_BELL)}  {bold('New KivaniCDK Message')}\n\n"
                f"From:  {code(sender_tag)}\n\n"
                f"{esc(text)}",
                parse_mode=HTML,
            )
    except Exception:
        pass  # recipient may have blocked the bot

    await state.clear()
    await send(msg,
        f"{pemoji(E_CHECK)}  {bold('Message Sent!')}\n\n"
        f"To:  {code(receiver_tag)}\n"
        f"Your identity is hidden — recipient sees only  {code(sender_tag)}.")


# ══════════════════════════════════════════════════════════════════════
# Inbox
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "kivani:inbox")
async def cb_inbox(cq: CallbackQuery):
    uid = cq.from_user.id
    tag = await get_user_tag(uid)
    if not tag:
        await cq.answer("Register a tag first.", show_alert=True); return
    messages = await get_kivani_inbox(tag)
    if not messages:
        await edit(cq.message,
            f"{pemoji(E_INBOX)}  {bold('Inbox')}  —  {code(tag)}\n\n"
            f"No messages yet.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                ibtn("Refresh", "kivani:inbox", E_BELL),
                ibtn("Close",   "cancel",       E_CROSS),
            ]]))
        await cq.answer(); return

    lines = [f"{pemoji(E_INBOX)}  {bold('Inbox')}  —  {code(tag)}  ({len(messages)} messages)\n"]
    for m in messages[:10]:
        sender  = m.get("sender_tag") or m.get("sender", "?")
        content = str(m.get("content",""))[:200]
        sent_at = str(m.get("sent_at",""))[:16]
        lines.append(
            f"─────────────────────\n"
            f"From  {code(sender)}   {italic(sent_at)}\n"
            f"{esc(content)}"
        )
    if len(messages) > 10:
        lines.append(f"\n…and {len(messages)-10} more.")

    await edit(cq.message, "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            ibtn("Refresh", "kivani:inbox",   E_BELL),
            ibtn("Reply",    "kivani:compose", E_MESSAGE),
            ibtn("Close",    "cancel",         E_CROSS),
        ]]))
    await cq.answer()


# ── Back to kivani home ────────────────────────────────────────────────

@router.callback_query(F.data == "back:kivani_home")
async def back_kivani_home(cq: CallbackQuery, state: FSMContext):
    await state.clear()
    uid = cq.from_user.id
    tag = await get_user_tag(uid)
    tag_display = code(tag) if tag else italic("Not registered")
    await edit(cq.message,
        f"{pemoji(E_MESSAGE)}  {bold('KivaniCDK')}\n\n"
        f"Your tag:  {tag_display}",
        reply_markup=kb_kivani_home(bool(tag)))
    await cq.answer()
