"""
TwinIDBot — Posts handler
4 template chooser → singular & custom flows → channel post with exclusive badge.
"""
import uuid
import asyncio
import urllib.request
import logging

from aiogram import Router, F, Bot
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup,
)

from config import CHANNEL_ID, COST_PER_POST, ADS_OF_DAY_STARS
from config import custom_post_cost
from db.database import (
    get_user, has_enough, deduct_credits, get_credits,
    save_post, get_user_tag, is_exclusive, get_vouches,
)
from utils.ui import (
    HTML,
    send,
    edit,
    ibtn,
    kb_back_cancel,
    kb_cancel_only,
    kb_platforms,
    kb_contact,
    kb_promo,
    send_post,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    fmt_price,
    is_valid_handle,
    clean_handle,
    is_valid_price,
    clean_price,
    is_valid_url,
    get_plat_emoji,
    msg_no_access,
    msg_low_credits,
    msg_invalid_input,
    E_BACK,
    E_BOLT,
    E_CHECK,
    E_CROSS,
    E_CROWN,
    E_CUSTOM,
    E_DIAMOND,
    E_FIRE,
    E_GIFT,
    E_ID,
    E_PHONE,
    E_PRICE,
    E_STAR,
    E_USER,

    BTN_POST,
)
from utils.templates import (
    TEMPLATE_NAMES, get_template_preview,
    build_final_post, build_raw_post, inject_exclusive,
)

logger = logging.getLogger(__name__)
router = Router()


# ══════════════════════════════════════════════════════════════════════
# FSM
# ══════════════════════════════════════════════════════════════════════

class ModeFlow(StatesGroup):
    choosing_mode     = State()

class PostFlow(StatesGroup):
    choosing_template = State()
    choosing_platform = State()
    entering_handle   = State()
    entering_price    = State()
    entering_bargain  = State()
    entering_contact  = State()
    entering_link     = State()
    previewing        = State()   # cycling through templates
    confirming        = State()

class PromoteFlow(StatesGroup):
    entering_message = State()
    entering_image    = State()   # only reached if the message step had no photo
    entering_target   = State()   # configurable button destination
    confirming        = State()


# ══════════════════════════════════════════════════════════════════════
# Keyboards
# ══════════════════════════════════════════════════════════════════════

def mode_menu_text() -> str:
    return (
        f"{pemoji(E_BOLT)}  {bold('New Listing')}\n\n"
        f"{bold('Usernames/Accs')} — structured form  ·  {usd(COST_PER_POST)}\n"
        f"{bold('Promote Ads')}    — write your own    ·  {usd(custom_post_cost())}  (+2%)\n"
        f"{bold('Ads of the Day')} — pinned, admin-approved  ·  ⭐ {ADS_OF_DAY_STARS} Stars"
    )


def kb_mode() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            ibtn("Usernames/Accs", "mode:singular", E_STAR),
            ibtn("Promote Ads",    "mode:promote",  E_CUSTOM),
        ],
        [ibtn("Ads of the Day", "mode:ads_of_day", E_FIRE)],
        [ibtn("Cancel", "cancel", E_CROSS)],
    ])


def kb_template_nav(current: int) -> InlineKeyboardMarkup:
    """Nav keyboard for cycling through 4 templates."""
    prev_t = ((current - 2) % 4) + 1
    next_t = (current % 4) + 1
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            ibtn(f"{TEMPLATE_NAMES[prev_t]}", f"tpl_prev:{current}", E_BACK),
            ibtn(f"{TEMPLATE_NAMES[next_t]}", f"tpl_next:{current}", E_CUSTOM),
        ],
        [
            ibtn(f"Use {TEMPLATE_NAMES[current]}", f"tpl_select:{current}", E_CHECK),
        ],
        [ibtn("Cancel", "cancel", E_CROSS)],
    ])


def kb_confirm_post(tpl: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("Post Now",      f"confirm_post:{tpl}", E_CHECK),
        ibtn("Change Template", "back:template_pick", E_BACK),
        ibtn("Cancel",         "cancel",             E_CROSS),
    ]])


def kb_promote_confirm() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        ibtn("Post Now",  "confirm_promote_post", E_CHECK),
        ibtn("Redo",      "redo_promote",         E_CUSTOM),
        ibtn("Cancel",    "cancel",               E_CROSS),
    ]])


# ══════════════════════════════════════════════════════════════════════
# og:image helper (async wrapper)
# ══════════════════════════════════════════════════════════════════════

def _fetch_og_image(url: str):
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 (compatible; TwinidBot/1.0)"}
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            raw = resp.read(65_536).decode("utf-8", errors="ignore")
        from html.parser import HTMLParser
        class P(HTMLParser):
            og = None
            def handle_starttag(self, tag, attrs):
                if tag == "meta":
                    d = dict(attrs)
                    if d.get("property") == "og:image": self.og = d.get("content")
        p = P(); p.feed(raw)
        return p.og
    except Exception:
        return None


async def send_to_channel(bot: Bot, text: str, link_url: str = "",
                           seller_username: str = "", contact: str = ""):
    """Post to channel, trying photo preview first. Every channel post
    carries a green 'Contact - @username' button (Bot API 9.4 button
    style) so buyers can reach the seller in one tap."""
    kb = kb_contact(seller_username, contact)
    image_url = None
    if link_url:
        loop = asyncio.get_event_loop()
        image_url = await loop.run_in_executor(None, _fetch_og_image, link_url)
    if image_url:
        try:
            return await bot.send_photo(
                chat_id=CHANNEL_ID, photo=image_url,
                caption=text, parse_mode=HTML, reply_markup=kb,
            )
        except Exception:
            pass
    return await bot.send_message(CHANNEL_ID, text, parse_mode=HTML, reply_markup=kb)


async def send_idcard_to_channel(bot: Bot, caption: str, img_bytes: bytes,
                                  seller_username: str = "", contact: str = ""):
    """Post ID-card image to channel, with the same green Contact button."""
    kb = kb_contact(seller_username, contact)
    if not img_bytes:
        return await bot.send_message(CHANNEL_ID, caption, parse_mode=HTML, reply_markup=kb)
    import io
    from aiogram.types import BufferedInputFile
    return await bot.send_photo(
        chat_id=CHANNEL_ID,
        photo=BufferedInputFile(img_bytes, filename="id_card.png"),
        caption=caption,
        parse_mode=HTML,
        reply_markup=kb,
    )


# ══════════════════════════════════════════════════════════════════════
# /post  (or keyboard button)
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("post"))
@router.message(F.text == BTN_POST)
async def cmd_post(msg: Message, state: FSMContext):
    uid  = msg.from_user.id
    user = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    if not user.get("tos_accepted"):
        await send(msg, f"{pemoji(E_CROSS)} Please accept the TOS first. Send /start."); return
    await state.set_state(ModeFlow.choosing_mode)
    await send(msg, mode_menu_text(), reply_markup=kb_mode())


# ── Mode selection ────────────────────────────────────────────────────

@router.callback_query(ModeFlow.choosing_mode, F.data == "mode:singular")
async def cb_mode_singular(cq: CallbackQuery, state: FSMContext):
    uid = cq.from_user.id
    if not await has_enough(uid, COST_PER_POST):
        await edit(cq.message, msg_low_credits(await get_credits(uid), COST_PER_POST)); return
    await state.set_state(PostFlow.choosing_platform)
    await edit(cq.message,
        f"{pemoji(E_BOLT)}  {bold('Usernames/Accs  ·  Choose Platform')}\n\nWhat are you listing?",
        reply_markup=kb_platforms("platform"))
    await cq.answer()


@router.callback_query(ModeFlow.choosing_mode, F.data == "mode:promote")
async def cb_mode_promote(cq: CallbackQuery, state: FSMContext):
    uid  = cq.from_user.id
    cost = custom_post_cost()
    if not await has_enough(uid, cost):
        await edit(cq.message, msg_low_credits(await get_credits(uid), cost)); return
    await state.set_state(PromoteFlow.entering_message)
    await edit(cq.message,
        f"{pemoji(E_CUSTOM)}  {bold('Promote Ads')}\n\n"
        f"Send (or forward) the message you want posted — write it exactly "
        f"how you want it to appear, your own formatting and emoji included. "
        f"Attach a photo if you want one in the post.\n\n"
        f"Cost:  {bold(usd(cost))}  ({cost} credits)",
        reply_markup=kb_back_cancel("back:mode_from_promote"))
    await cq.answer()


# ── Back to mode ──────────────────────────────────────────────────────

@router.callback_query(F.data.in_({"back:mode_from_platform", "back:mode_from_promote"}))
async def back_to_mode(cq: CallbackQuery, state: FSMContext):
    await state.set_state(ModeFlow.choosing_mode)
    await edit(cq.message, mode_menu_text(), reply_markup=kb_mode())
    await cq.answer()


# ══════════════════════════════════════════════════════════════════════
# SINGULAR FLOW
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(PostFlow.choosing_platform, F.data.startswith("platform:"))
async def cb_platform(cq: CallbackQuery, state: FSMContext):
    platform = cq.data.split(":", 1)[1]
    await state.update_data(platform=platform)
    await state.set_state(PostFlow.entering_handle)
    plat_e = get_plat_emoji(platform)
    await edit(cq.message,
        f"{pemoji(plat_e)}  {bold(platform)}\n\n"
        f"Send the  {bold('username / handle')}.\n"
        f"No @ needed.  Letters, digits, underscores only.",
        reply_markup=kb_back_cancel("back:post_platform"))
    await cq.answer()


@router.callback_query(F.data == "back:post_platform")
async def back_post_platform(cq: CallbackQuery, state: FSMContext):
    await state.set_state(PostFlow.choosing_platform)
    await edit(cq.message,
        f"{pemoji(E_BOLT)}  {bold('Choose Platform')}\n\nWhat are you listing?",
        reply_markup=kb_platforms("platform"))
    await cq.answer()


@router.message(PostFlow.entering_handle)
async def fsm_handle(msg: Message, state: FSMContext):
    raw = msg.text or ""
    if not is_valid_handle(raw):
        await send(msg, msg_invalid_input("handle", "Letters, digits, underscores only. No spaces."),
                   reply_markup=kb_back_cancel("back:post_platform")); return
    await state.update_data(handle=clean_handle(raw))
    await state.set_state(PostFlow.entering_price)
    await send(msg,
        f"{pemoji(E_PRICE)}  {bold('Asking Price')}\n\nJust the number.  Example:  {bold('5000')}",
        reply_markup=kb_back_cancel("back:post_handle"))


@router.callback_query(F.data == "back:post_handle")
async def back_post_handle(cq: CallbackQuery, state: FSMContext):
    data   = await state.get_data()
    plat_e = get_plat_emoji(data.get("platform", "Other"))
    await state.set_state(PostFlow.entering_handle)
    await edit(cq.message,
        f"{pemoji(plat_e)}  {bold(data.get('platform',''))}\n\n"
        f"Send the username / handle.  No @ needed.",
        reply_markup=kb_back_cancel("back:post_platform"))
    await cq.answer()


@router.message(PostFlow.entering_price)
async def fsm_price(msg: Message, state: FSMContext):
    raw = msg.text or ""
    if not is_valid_price(raw):
        await send(msg, msg_invalid_input("price", "Positive number only.  Example:  5000"),
                   reply_markup=kb_back_cancel("back:post_handle")); return
    await state.update_data(price=clean_price(raw))
    await state.set_state(PostFlow.entering_bargain)
    await send(msg,
        f"{pemoji(E_CHECK)}  {bold('Bargain Price')}\n\nLowest you'll accept.  Example:  {bold('2000')}",
        reply_markup=kb_back_cancel("back:post_price"))


@router.callback_query(F.data == "back:post_price")
async def back_post_price(cq: CallbackQuery, state: FSMContext):
    await state.set_state(PostFlow.entering_price)
    await edit(cq.message,
        f"{pemoji(E_PRICE)}  {bold('Asking Price')}\n\nJust the number.  Example:  5000",
        reply_markup=kb_back_cancel("back:post_handle"))
    await cq.answer()


@router.message(PostFlow.entering_bargain)
async def fsm_bargain(msg: Message, state: FSMContext):
    raw  = msg.text or ""
    if not is_valid_price(raw):
        await send(msg, msg_invalid_input("bargain price", "Positive number only."),
                   reply_markup=kb_back_cancel("back:post_price")); return
    data = await state.get_data()
    if float(clean_price(raw)) > float(data.get("price", "0") or "0"):
        await send(msg, msg_invalid_input("bargain price",
            f"Can't be higher than asking price ({fmt_price(data['price'])})."),
                   reply_markup=kb_back_cancel("back:post_price")); return
    await state.update_data(bargain=clean_price(raw))
    await state.set_state(PostFlow.entering_contact)
    await send(msg,
        f"{pemoji(E_PHONE)}  {bold('Contact')}  (optional)\n\n"
        f"Your @username or t.me/ link.\n"
        f"Type  {bold('skip')}  to leave blank.",
        reply_markup=kb_back_cancel("back:post_bargain"))


@router.callback_query(F.data == "back:post_bargain")
async def back_post_bargain(cq: CallbackQuery, state: FSMContext):
    await state.set_state(PostFlow.entering_bargain)
    await edit(cq.message,
        f"{pemoji(E_CHECK)}  {bold('Bargain Price')}\n\nLowest you'll accept.  Example:  2000",
        reply_markup=kb_back_cancel("back:post_price"))
    await cq.answer()


@router.message(PostFlow.entering_contact)
async def fsm_contact(msg: Message, state: FSMContext):
    val = (msg.text or "").strip()
    await state.update_data(contact="" if val.lower() == "skip" else val)
    await state.set_state(PostFlow.entering_link)
    await send(msg,
        f"{pemoji(E_BOLT)}  {bold('Listing URL')}\n\n"
        f"Paste a link (Fragment, marketplace, etc.).\n"
        f"Type  {bold('skip')}  to leave blank.",
        reply_markup=kb_back_cancel("back:post_contact"))


@router.callback_query(F.data == "back:post_contact")
async def back_post_contact(cq: CallbackQuery, state: FSMContext):
    await state.set_state(PostFlow.entering_contact)
    await edit(cq.message,
        f"{pemoji(E_PHONE)}  {bold('Contact')}  (optional)\n\nType  skip  to leave blank.",
        reply_markup=kb_back_cancel("back:post_bargain"))
    await cq.answer()


@router.message(PostFlow.entering_link)
async def fsm_link(msg: Message, state: FSMContext, bot: Bot):
    val = (msg.text or "").strip()
    if val.lower() != "skip" and val and not is_valid_url(val):
        await send(msg, msg_invalid_input("URL",
            "Must start with https://\nOr type  skip  to leave blank."),
                   reply_markup=kb_back_cancel("back:post_contact")); return
    link_url = "" if val.lower() == "skip" else val
    seller   = msg.from_user.username or str(msg.from_user.id)
    await state.update_data(link=link_url, seller_username=seller)

    # Now enter the template preview loop, starting at template 1
    await state.update_data(current_template=1)
    await state.set_state(PostFlow.previewing)
    await _show_template_preview(msg.chat.id, msg.from_user.id, state, 1, bot)


async def _show_template_preview(chat_id: int, uid: int, state: FSMContext, tpl: int, bot: Bot):
    """
    Shows what this listing will actually look like once posted.

    For templates 1-3 (plain text) that's just the formatted text. For
    template 4 (ID card) this now renders the REAL PNG via
    generate_id_card() with the seller's real data/avatar — not a text
    stand-in — so what they see here is what goes to the channel.

    Always deletes the previous preview message and sends a fresh one,
    rather than editing in place: Telegram has no way to edit a text
    message into a photo message (or back), which is exactly the wall
    template 4 used to hit, silently falling back to a text stub.
    """
    data    = await state.get_data()
    kivani  = await get_user_tag(uid)
    excl    = await is_exclusive(uid)
    kb      = kb_template_nav(tpl)
    header  = f"{pemoji(E_STAR)}  {bold('Template Preview')}  ({tpl}/4)  —  {bold(TEMPLATE_NAMES[tpl])}"

    # Clean up the previous preview message before sending the new one.
    old_chat, old_mid = data.get("preview_chat_id"), data.get("preview_msg_id")
    if old_chat and old_mid:
        try:
            await bot.delete_message(old_chat, old_mid)
        except Exception:
            pass

    if tpl == 4:
        from utils.id_card import generate_id_card, fetch_profile_photo
        from utils.workers import run_cpu
        processing = await bot.send_message(chat_id, f"{pemoji(E_STAR)}  Processing…", parse_mode=HTML)
        user_info = await get_user(uid)
        avatar    = await fetch_profile_photo(bot, uid)
        img_bytes = await run_cpu(
            generate_id_card,
            user_info["name"] if user_info else "",
            data.get("seller_username", ""),
            data.get("platform", "Other"), data.get("handle", ""),
            fmt_price(data.get("price", "0")), fmt_price(data.get("bargain", "0")),
            "PREV-00000000", kivani, avatar,
            data.get("contact", ""), data.get("link", ""), excl, 0,
        )
        try:
            await bot.delete_message(chat_id, processing.message_id)
        except Exception:
            pass
        if img_bytes:
            from aiogram.types import BufferedInputFile
            sent = await bot.send_photo(
                chat_id, BufferedInputFile(img_bytes, filename="preview.png"),
                caption=header, parse_mode=HTML, reply_markup=kb,
            )
        else:
            # Pillow/font failure — tell them plainly instead of a silent stub.
            sent = await bot.send_message(
                chat_id,
                f"{header}\n\n{pemoji(E_CROSS)}  Couldn't render the card image "
                f"on this server (Pillow/fonts issue) — the other templates work fine.",
                parse_mode=HTML, reply_markup=kb,
            )
    else:
        preview = get_template_preview(
            tpl,
            data.get("platform", "Other"),
            data.get("handle", "handle"),
            data.get("price", "0"),
            data.get("bargain", "0"),
            data.get("contact", ""),
            data.get("link", ""),
            data.get("seller_username", ""),
            kivani,
        )
        full_text = f"{header}\n\n{'─'*30}\n\n{preview}"
        sent = await bot.send_message(chat_id, full_text, parse_mode=HTML, reply_markup=kb)

    await state.update_data(preview_chat_id=sent.chat.id, preview_msg_id=sent.message_id)


@router.callback_query(PostFlow.previewing, F.data.startswith("tpl_prev:"))
async def tpl_prev(cq: CallbackQuery, state: FSMContext, bot: Bot):
    current = int(cq.data.split(":")[1])
    new_tpl = ((current - 2) % 4) + 1
    await state.update_data(current_template=new_tpl)
    await _show_template_preview(cq.message.chat.id, cq.from_user.id, state, new_tpl, bot)
    await cq.answer()


@router.callback_query(PostFlow.previewing, F.data.startswith("tpl_next:"))
async def tpl_next(cq: CallbackQuery, state: FSMContext, bot: Bot):
    current = int(cq.data.split(":")[1])
    new_tpl = (current % 4) + 1
    await state.update_data(current_template=new_tpl)
    await _show_template_preview(cq.message.chat.id, cq.from_user.id, state, new_tpl, bot)
    await cq.answer()


@router.callback_query(PostFlow.previewing, F.data.startswith("tpl_select:"))
async def tpl_select(cq: CallbackQuery, state: FSMContext, bot: Bot):
    tpl = int(cq.data.split(":")[1])
    data = await state.get_data()
    if not all(k in data for k in ("platform", "handle", "price", "bargain", "seller_username")):
        # Stale button from an earlier/expired flow — the listing data
        # it depended on is gone. Tell the user plainly instead of
        # crashing with a KeyError.
        await state.clear()
        await edit(cq.message,
            f"{pemoji(E_CROSS)}  {bold('This listing session expired')}\n\n"
            f"Send /post to start a new listing.")
        await cq.answer("Session expired", show_alert=True)
        return
    await state.update_data(chosen_template=tpl)
    await state.set_state(PostFlow.confirming)
    uid     = cq.from_user.id
    kivani  = await get_user_tag(uid)
    vouches = await get_vouches(uid)
    excl    = await is_exclusive(uid)
    cost    = COST_PER_POST
    kb      = kb_confirm_post(tpl)
    header  = f"{pemoji(E_CHECK)}  {bold(TEMPLATE_NAMES[tpl])}  selected"
    footer  = f"{pemoji(E_PRICE)}  Cost:  {bold(usd(cost))}  ({cost} credits)"

    # Same story as the cycling step: delete the old preview message and
    # send a fresh one, since it may be a photo (template 4) that can't
    # be edit_text()'d into this confirmation screen.
    old_chat, old_mid = data.get("preview_chat_id"), data.get("preview_msg_id")
    if old_chat and old_mid:
        try:
            await bot.delete_message(old_chat, old_mid)
        except Exception:
            pass

    if tpl == 4:
        from utils.id_card import generate_id_card, fetch_profile_photo
        from utils.workers import run_cpu
        processing = await bot.send_message(cq.message.chat.id, f"{pemoji(E_STAR)}  Processing…", parse_mode=HTML)
        user_info = await get_user(uid)
        avatar    = await fetch_profile_photo(bot, uid)
        img_bytes = await run_cpu(
            generate_id_card,
            user_info["name"] if user_info else "",
            data["seller_username"],
            data["platform"], data["handle"],
            fmt_price(data["price"]), fmt_price(data["bargain"]),
            "PREV-00000000", kivani, avatar,
            data.get("contact", ""), data.get("link", ""), excl, vouches,
        )
        try:
            await bot.delete_message(cq.message.chat.id, processing.message_id)
        except Exception:
            pass
        if img_bytes:
            from aiogram.types import BufferedInputFile
            sent = await bot.send_photo(
                cq.message.chat.id, BufferedInputFile(img_bytes, filename="preview.png"),
                caption=f"{header}\n\n{footer}", parse_mode=HTML, reply_markup=kb,
            )
        else:
            sent = await bot.send_message(
                cq.message.chat.id,
                f"{header}\n\n{pemoji(E_CROSS)}  Couldn't render the card image.\n\n{footer}",
                parse_mode=HTML, reply_markup=kb,
            )
    else:
        preview = get_template_preview(
            tpl,
            data["platform"], data["handle"], data["price"], data["bargain"],
            data.get("contact", ""), data.get("link", ""), data["seller_username"], kivani, vouches,
        )
        sent = await bot.send_message(
            cq.message.chat.id,
            f"{header}\n\n{'─'*30}\n\n{preview}\n\n{'─'*30}\n\n{footer}",
            parse_mode=HTML, reply_markup=kb,
        )

    await state.update_data(preview_chat_id=sent.chat.id, preview_msg_id=sent.message_id)
    await cq.answer(f"Template {tpl} selected!")


@router.callback_query(F.data == "back:template_pick")
async def back_template_pick(cq: CallbackQuery, state: FSMContext, bot: Bot):
    data = await state.get_data()
    tpl  = data.get("current_template", 1)
    await state.set_state(PostFlow.previewing)
    await _show_template_preview(cq.message.chat.id, cq.from_user.id, state, tpl, bot)
    await cq.answer()


@router.callback_query(PostFlow.confirming, F.data.startswith("confirm_post:"))
async def cb_confirm(cq: CallbackQuery, state: FSMContext, bot: Bot):
    tpl  = int(cq.data.split(":")[1])
    uid  = cq.from_user.id
    cost = COST_PER_POST

    data = await state.get_data()
    if not all(k in data for k in ("platform", "handle", "price", "bargain", "seller_username")):
        # Stale/expired flow — bail out before touching credits.
        await state.clear()
        await edit(cq.message,
            f"{pemoji(E_CROSS)}  {bold('This listing session expired')}\n\n"
            f"Send /post to start a new listing.")
        await cq.answer("Session expired", show_alert=True)
        return

    if not await deduct_credits(uid, cost):
        await edit(cq.message, msg_low_credits(await get_credits(uid), cost))
        await state.clear(); return

    post_id   = f"TW-{uuid.uuid4().hex[:8].upper()}"
    excl      = await is_exclusive(uid)
    kivani    = await get_user_tag(uid)
    vouches   = await get_vouches(uid)

    post_html = build_final_post(
        tpl,
        data["platform"], data["handle"], data["price"], data["bargain"],
        data.get("contact", ""), data.get("link", ""), data["seller_username"],
        post_id, excl, kivani, vouches,
    )

    # Template 4 = ID card image
    if tpl == 4:
        processing = await bot.send_message(cq.message.chat.id, f"{pemoji(E_STAR)}  Processing…", parse_mode=HTML)
        try:
            from utils.id_card import generate_id_card, fetch_profile_photo
            from utils.workers import run_cpu
            user_info = await get_user(uid)
            avatar    = await fetch_profile_photo(bot, uid)
            img_bytes = await run_cpu(
                generate_id_card,
                user_info["name"] if user_info else "",
                data["seller_username"],
                data["platform"], data["handle"],
                fmt_price(data["price"]), fmt_price(data["bargain"]),
                post_id, kivani, avatar,
                data.get("contact", ""), data.get("link", ""), excl, vouches,
            )
            # NOTE: build_final_post() already injects the exclusive badge
            # once (it's handed `excl` directly above) — do NOT inject it
            # again here. Doing so was the cause of the doubled banner.
            sent = await send_idcard_to_channel(
                bot, post_html, img_bytes,
                data["seller_username"], data.get("contact", ""),
            )
        except Exception as e:
            logger.error("ID card failed: %s", e)
            sent = await send_to_channel(
                bot, post_html, data.get("link", ""),
                data["seller_username"], data.get("contact", ""),
            )
        finally:
            try:
                await bot.delete_message(cq.message.chat.id, processing.message_id)
            except Exception:
                pass
    else:
        sent = await send_to_channel(
            bot, post_html, data.get("link", ""),
            data["seller_username"], data.get("contact", ""),
        )

    # Persist post
    await save_post(post_id, {
        "post_id":          post_id,
        "owner_id":         uid,
        "channel_msg_id":   sent.message_id,
        "mode":             "singular",
        "template":         tpl,
        "platform":         data["platform"],
        "handle":           data["handle"],
        "price":            data["price"],
        "bargain":          data["bargain"],
        "contact":          data.get("contact", ""),
        "link":             data.get("link", ""),
        "seller_username":  data["seller_username"],
        "exclusive":        excl,
    })
    await state.clear()
    bal = await get_credits(uid)
    from handlers.manage import kb_manage
    await edit(cq.message,
        f"{pemoji(E_DIAMOND)}  {bold('Posted!')}\n\n"
        f"Live on  {link('@twinid', 'https://t.me/twinid')}\n"
        f"{pemoji(E_ID)}  Post ID:  {code(post_id)}\n\n"
        f"{pemoji(E_STAR)}  Balance:  {bold(usd(bal))}  ({bal} credits)",
        reply_markup=kb_manage(post_id))
    await cq.answer("Posted!")


# ══════════════════════════════════════════════════════════════════════
# PROMOTE ADS FLOW
# ══════════════════════════════════════════════════════════════════════

@router.message(PromoteFlow.entering_message)
async def fsm_promote_message(msg: Message, state: FSMContext):
    # html_text (not .text) — falls back to .caption/.caption_entities
    # when the message is a photo, and works the same whether the
    # message was typed fresh or forwarded, so forwarding an existing
    # post here "just works" without any special-casing.
    promote_html = (msg.html_text or "").strip()
    if not promote_html and not msg.photo:
        await send(msg, msg_invalid_input("message", "Message can't be empty."),
                   reply_markup=kb_back_cancel("back:mode_from_promote")); return

    seller = msg.from_user.username or str(msg.from_user.id)
    await state.update_data(promote_html=promote_html, seller_username=seller)

    if msg.photo:
        # Image came bundled with this message (typed-with-photo or a
        # forwarded photo post) — no need to ask separately.
        await state.update_data(promote_photo=msg.photo[-1].file_id)
        await state.set_state(PromoteFlow.entering_target)
        await send(msg,
            f"{pemoji(E_FIRE)}  {bold('Promo button')}\n\n"
            f"Send a channel link or @username for the button to point to, "
            f"or type  {code('skip')}  to default to  {code('Ads - @Twinid')}.",
            reply_markup=kb_back_cancel("back:mode_from_promote"))
        return

    await state.set_state(PromoteFlow.entering_image)
    await send(msg,
        f"{pemoji(E_STAR)}  Send a photo to attach, or type  {code('skip')}  for none.",
        reply_markup=kb_back_cancel("back:mode_from_promote"))


@router.message(PromoteFlow.entering_image)
async def fsm_promote_image(msg: Message, state: FSMContext):
    if msg.photo:
        await state.update_data(promote_photo=msg.photo[-1].file_id)
    # anything else (including the literal "skip") just means no image
    await state.set_state(PromoteFlow.entering_target)
    await send(msg,
        f"{pemoji(E_FIRE)}  {bold('Promo button')}\n\n"
        f"Send a channel link or @username for the button to point to, "
        f"or type  {code('skip')}  to default to  {code('Ads - @Twinid')}.",
        reply_markup=kb_back_cancel("back:mode_from_promote"))


@router.message(PromoteFlow.entering_target)
async def fsm_promote_target(msg: Message, state: FSMContext):
    raw = (msg.text or "").strip()
    target = "" if raw.lower() == "skip" else raw
    await state.update_data(promote_target=target)

    data = await state.get_data()
    preview = build_raw_post(data["promote_html"])
    if data.get("promote_photo"):
        await msg.answer_photo(data["promote_photo"], caption=preview or None, parse_mode=HTML)
    else:
        await send(msg, f"{pemoji(E_STAR)}  {bold('Preview:')}\n\n{'─'*30}\n\n{preview}")

    await state.set_state(PromoteFlow.confirming)
    cost = custom_post_cost()
    await send(msg,
        f"{pemoji(E_PRICE)}  Cost:  {bold(usd(cost))}  ({cost} credits)  — post to channel?",
        reply_markup=kb_promote_confirm())


@router.callback_query(PromoteFlow.confirming, F.data == "redo_promote")
async def cb_redo_promote(cq: CallbackQuery, state: FSMContext):
    await state.set_state(PromoteFlow.entering_message)
    await edit(cq.message,
        f"{pemoji(E_CUSTOM)}  Rewrite your message (photo optional):",
        reply_markup=kb_back_cancel("back:mode_from_promote"))
    await cq.answer()


@router.callback_query(PromoteFlow.confirming, F.data == "confirm_promote_post")
async def cb_confirm_promote(cq: CallbackQuery, state: FSMContext, bot: Bot):
    uid  = cq.from_user.id
    cost = custom_post_cost()
    if not await deduct_credits(uid, cost):
        await edit(cq.message, msg_low_credits(await get_credits(uid), cost))
        await state.clear(); return

    data      = await state.get_data()
    post_id   = f"TW-{uuid.uuid4().hex[:8].upper()}"
    excl      = await is_exclusive(uid)
    photo     = data.get("promote_photo")

    post_html = build_raw_post(data["promote_html"])
    if excl:
        post_html = inject_exclusive(post_html, kind="promo")
    sent = await send_post(
        bot, CHANNEL_ID, post_html, photo=photo, parse_mode=HTML,
        reply_markup=kb_promo(data.get("promote_target", "")),
    )

    await save_post(post_id, {
        "post_id":         post_id,
        "owner_id":        uid,
        "channel_msg_id":  sent.message_id,
        "mode":            "promote",
        "custom_text":     data["promote_html"],
        "seller_username": data["seller_username"],
        "exclusive":       excl,
    })
    await state.clear()
    bal = await get_credits(uid)
    from handlers.manage import kb_manage
    await edit(cq.message,
        f"{pemoji(E_DIAMOND)}  {bold('Posted!')}\n\n"
        f"Live on  {link('@twinid', 'https://t.me/twinid')}\n"
        f"{pemoji(E_ID)}  Post ID:  {code(post_id)}\n\n"
        f"{pemoji(E_STAR)}  Balance:  {bold(usd(bal))}  ({bal} credits)",
        reply_markup=kb_manage(post_id))
    await cq.answer("Posted!")
