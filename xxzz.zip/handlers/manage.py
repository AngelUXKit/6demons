"""
TwinIDBot — Manage Posts handler
Users can edit, delete, and view all their posts by post ID.
Posts persist in JSON so manage works even after other posts are deleted.
"""
from aiogram import Router, F, Bot
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup

from config import CHANNEL_ID
from db.database import get_user, get_post, get_user_posts, update_post, delete_post, get_user_tag, get_vouches
from utils.ui import (
    HTML,
    send,
    edit,
    ibtn,
    kb_cancel_only,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    msg_no_access,
    msg_invalid_input,
    E_BACK,
    E_BOLT,
    E_CHECK,
    E_CROSS,
    E_CROWN,
    E_CUSTOM,
    E_DIAMOND,
    E_FIRE,
    E_GIFT,
    E_PENCIL,
    E_PRICE,
    E_STAR,
    E_TROPHY,
    E_USER,
    E_SEND,

    BTN_MANAGE,
)
from utils.templates import build_final_post, build_raw_post, inject_exclusive

router = Router()


class EditFlow(StatesGroup):
    selecting_post      = State()
    waiting_new_caption = State()


# ── Keyboard factories ─────────────────────────────────────────────────

def kb_manage(post_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            ibtn("Edit",       f"edit:{post_id}",   E_CUSTOM),
            ibtn("Delete",      f"delete:{post_id}", E_CROSS),
        ],
        [
            ibtn("New Post",    "new_post",          E_STAR),
            ibtn("My Posts",    "my_posts",          E_BOLT),
        ],
    ])


def kb_posts_list(posts: list[dict]) -> InlineKeyboardMarkup:
    rows = []
    for p in posts[:10]:
        pid = p["post_id"]
        label = f"{p.get('platform','?')}  ·  {pid}"
        rows.append([ibtn(label, f"view_post:{pid}", E_BOLT)])
    rows.append([ibtn("Close", "cancel", E_CROSS)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ══════════════════════════════════════════════════════════════════════
# Manage command / button
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("manage"))
@router.message(F.text == BTN_MANAGE)
async def cmd_manage(msg: Message):
    uid   = msg.from_user.id
    user  = await get_user(uid)
    if not user:
        await send(msg, msg_no_access(uid)); return
    posts = await get_user_posts(uid)
    if not posts:
        await send(msg,
            f"{pemoji(E_GIFT)}  {bold('No Posts Found')}\n\n"
            f"You haven't posted anything yet.\n"
            f"Tap  {bold('New Post')}  to list your first item.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                ibtn("New Post", "new_post", E_STAR)
            ]])); return
    await send(msg,
        f"{pemoji(E_BOLT)}  {bold('Your Posts')}  ({len(posts)})\n\n"
        f"Select a post to manage:",
        reply_markup=kb_posts_list(posts))


# ── View individual post ───────────────────────────────────────────────

@router.callback_query(F.data.startswith("view_post:"))
async def cb_view_post(cq: CallbackQuery):
    post_id = cq.data.split(":", 1)[1]
    post    = await get_post(post_id)
    if not post:
        await cq.answer("Post not found.", show_alert=True); return
    mode = post.get("mode", "singular")
    plat = post.get("platform", "?")
    if mode == "singular":
        contact_line = f"\n{pemoji(E_SEND)}  Contact:  {esc(post.get('contact',''))}" if post.get("contact") else ""
        link_line    = f"\n{pemoji(E_DIAMOND)}  Link:  {esc(post.get('link',''))}" if post.get("link") else ""
        detail = (
            f"{pemoji(E_USER)}  Handle:   {code('@' + post.get('handle',''))}\n"
            f"{pemoji(E_PRICE)}  Price:    {bold(post.get('price',''))}\n"
            f"{pemoji(E_CHECK)}  Bargain:  {bold(post.get('bargain',''))}"
            f"{contact_line}{link_line}"
        )
        plat_line = f"{pemoji(E_STAR)}  Platform:  {bold(esc(plat))}\n"
    else:
        preview = (post.get("custom_text",""))[:120]
        detail  = f"{pemoji(E_PENCIL)}  {esc(preview)}{'…' if len(post.get('custom_text',''))>120 else ''}"
        plat_line = ""

    excl_line = f"\n{pemoji(E_CROWN)}  {bold('EXCLUSIVE')}\n" if post.get("exclusive") else ""
    await edit(cq.message,
        f"{pemoji(E_BOLT)}  {bold('Post')}  {code(post_id)}{excl_line}\n\n"
        f"{plat_line}"
        f"{detail}\n\n"
        f"{pemoji(E_SEND)}  Seller:  @{esc(post.get('seller_username',''))}\n"
        f"{pemoji(E_BOLT)}  {link('View on channel', 'https://t.me/twinid')}",
        reply_markup=kb_manage(post_id))
    await cq.answer()


# ── My posts list button ───────────────────────────────────────────────

@router.callback_query(F.data == "my_posts")
async def cb_my_posts(cq: CallbackQuery):
    posts = await get_user_posts(cq.from_user.id)
    if not posts:
        await cq.answer("No posts found.", show_alert=True); return
    await edit(cq.message,
        f"{pemoji(E_BOLT)}  {bold('Your Posts')}  ({len(posts)})\n\nSelect one to manage:",
        reply_markup=kb_posts_list(posts))
    await cq.answer()


# ── New post shortcut ──────────────────────────────────────────────────

@router.callback_query(F.data == "new_post")
async def cb_new_post(cq: CallbackQuery, state: FSMContext):
    uid  = cq.from_user.id
    user = await get_user(uid)
    if not user:
        await edit(cq.message, msg_no_access(uid)); return
    from config import COST_PER_POST
    from utils.ui import usd, kb_cancel_only
    if user["credits"] < COST_PER_POST:
        from utils.ui import msg_low_credits
        await edit(cq.message, msg_low_credits(user["credits"], COST_PER_POST)); return

    from config import COST_PER_POST, custom_post_cost
    from handlers.posts import ModeFlow, kb_mode, mode_menu_text
    await state.set_state(ModeFlow.choosing_mode)
    await edit(cq.message, mode_menu_text(), reply_markup=kb_mode())
    await cq.answer()


# ── Edit ───────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("edit:"))
async def cb_edit(cq: CallbackQuery, state: FSMContext):
    post_id = cq.data.split(":", 1)[1]
    post    = await get_post(post_id)
    if not post or post["owner_id"] != cq.from_user.id:
        await cq.answer("Post not found or not yours.", show_alert=True); return
    await state.update_data(edit_post_id=post_id)
    await state.set_state(EditFlow.waiting_new_caption)
    await edit(cq.message,
        f"{pemoji(E_FIRE)}  {bold('Edit Post')}  {code(post_id)}\n\n"
        f"For  {bold('Usernames/Accs')}  posts: send new contact/description text.\n"
        f"For  {bold('Promote Ads')}  posts: send an entirely new message.\n\n"
        f"No credit charge.",
        reply_markup=kb_cancel_only())
    await cq.answer()


@router.message(EditFlow.waiting_new_caption)
async def fsm_edit_caption(msg: Message, state: FSMContext, bot: Bot):
    uid     = msg.from_user.id
    data    = await state.get_data()
    post_id = data.get("edit_post_id")
    if not post_id:
        await send(msg, f"{pemoji(E_CROSS)} Session expired. Use Manage to find your post.");
        await state.clear(); return

    post    = await get_post(post_id)
    if not post or post["owner_id"] != uid:
        await send(msg, f"{pemoji(E_CROSS)} Post not found or not yours.")
        await state.clear(); return

    new_text = (msg.text or "").strip()
    if not new_text:
        await send(msg, msg_invalid_input("message", "Can't be empty. Send new text:"),
                   reply_markup=kb_cancel_only()); return

    excl   = post.get("exclusive", False)
    kivani = await get_user_tag(uid)
    vouches = await get_vouches(uid)
    mode   = post.get("mode", "singular")

    if mode in ("custom", "promote"):
        # Same conservative behavior as before this rename: the edit
        # path takes plain text (not the original message's rich
        # entities) — build_raw_post() is just the passthrough entry
        # point, esc() keeps this identical to the pre-rename escaping.
        new_html = build_raw_post(esc(new_text))
    else:
        tpl = post.get("template", 1)
        new_html = build_final_post(
            tpl,
            post.get("platform", "Other"),
            post.get("handle", ""),
            post.get("price", ""),
            post.get("bargain", ""),
            new_text,                           # new_text replaces contact
            post.get("link", ""),
            post.get("seller_username", str(uid)),
            post_id, excl, kivani, vouches,
        )

    if excl and mode in ("custom", "promote"):
        new_html = inject_exclusive(new_html, kind="promo")

    try:
        # Try edit text; if message had a photo use edit_caption
        try:
            await bot.edit_message_text(
                chat_id=CHANNEL_ID, message_id=post["channel_msg_id"],
                text=new_html, parse_mode=HTML,
            )
        except Exception:
            await bot.edit_message_caption(
                chat_id=CHANNEL_ID, message_id=post["channel_msg_id"],
                caption=new_html, parse_mode=HTML,
            )

        if mode in ("custom", "promote"):
            await update_post(post_id, {"custom_text": new_text})
        else:
            await update_post(post_id, {"contact": new_text})

        await send(msg,
            f"{pemoji(E_DIAMOND)}  {bold('Post updated!')}  {code(post_id)}\n\n"
            f"{link('View on @twinid', 'https://t.me/twinid')}",
            reply_markup=kb_manage(post_id))
    except Exception as ex:
        await msg.answer(
            f"{pemoji(E_CROSS)}  Could not edit: {esc(str(ex))}", parse_mode=HTML
        )
    await state.clear()


# ── Delete ─────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("delete:"))
async def cb_delete(cq: CallbackQuery, bot: Bot):
    post_id = cq.data.split(":", 1)[1]
    post    = await get_post(post_id)
    if not post or post["owner_id"] != cq.from_user.id:
        await cq.answer("Post not found or not yours.", show_alert=True); return

    try:
        await bot.delete_message(chat_id=CHANNEL_ID, message_id=post["channel_msg_id"])
    except Exception as ex:
        # Message may already be gone — still mark it deleted
        pass

    await delete_post(post_id)
    await edit(cq.message,
        f"{pemoji(E_TROPHY)}  {bold('Post Deleted')}  {code(post_id)}\n\n"
        f"Tap  {bold('New Post')}  to create a new listing.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            ibtn("New Post", "new_post", E_STAR),
        ]]))
    await cq.answer("Deleted!")


# ── Cancel callback ────────────────────────────────────────────────────

@router.callback_query(F.data == "cancel")
async def cb_cancel(cq: CallbackQuery, state: FSMContext):
    await state.clear()
    await edit(cq.message, f"{pemoji(E_STAR)}  Cancelled.")
    await cq.answer()