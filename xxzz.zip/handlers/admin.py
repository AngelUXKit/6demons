"""
TwinIDBot — Admin handler
Manage users, credits, and Exclusive members.
"""
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup

from config import ADMIN_ID
from db.database import (
    get_user, add_user, add_credits, remove_user, list_users,
    set_exclusive, is_exclusive, get_user_tag,
    is_moderation_enabled, set_moderation_enabled, list_moderated_chats,
)
from utils.ui import (
    send,
    edit,
    ibtn,
    kb_back_cancel,
    kb_cancel_only,
    pemoji,
    bold,
    code,
    link,
    esc,
    usd,
    msg_invalid_input,
    E_BACK,
    E_CHECK,
    E_CROSS,
    E_CROWN,
    E_DIAMOND,
    E_FIRE,
    E_GIFT,
    E_MESSAGE,
    E_SHIELD,
    E_STAR,
    E_TOPUP,
    E_USER,
)

router = Router()

# ── Guard ─────────────────────────────────────────────────────────────

def is_admin(uid: int) -> bool:
    return uid == ADMIN_ID


# ── FSM ───────────────────────────────────────────────────────────────

class AdminFlow(StatesGroup):
    add_waiting_id      = State()
    add_waiting_name    = State()
    add_waiting_credits = State()
    topup_waiting_id    = State()
    topup_waiting_amt   = State()
    remove_waiting_id   = State()
    excl_waiting_id     = State()    # grant exclusive
    revoke_waiting_id   = State()    # revoke exclusive
    mod_waiting_chatid  = State()    # TwinGuard — enable moderation for a new chat


# ── Keyboards ─────────────────────────────────────────────────────────

def kb_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            ibtn("Add User",     "admin:add",    E_TOPUP),
            ibtn("Top-Up",       "admin:topup",  E_DIAMOND),
            ibtn("Remove",        "admin:remove", E_CROSS),
        ],
        [
            ibtn("Grant Exclusive", "admin:grant_excl",  E_CROWN),
            ibtn("Revoke Exclusive","admin:revoke_excl", E_SHIELD),
        ],
        [
            ibtn("List Users",   "admin:list",   E_USER),
            ibtn("Exclusives",   "admin:excl_list", E_STAR),
        ],
        [
            ibtn("TwinGuard",    "admin:twinguard", E_FIRE),
            ibtn("Close",        "cancel",       E_CROSS),
        ],
    ])


# ══════════════════════════════════════════════════════════════════════
# /admin
# ══════════════════════════════════════════════════════════════════════

@router.message(Command("admin"))
async def cmd_admin(msg: Message):
    if not is_admin(msg.from_user.id):
        return  # silent — no response at all for non-admins, don't confirm this command exists
    users = await list_users()
    excl_count = sum(1 for u in users.values() if u.get("exclusive"))
    await send(msg,
        f"{pemoji(E_CROWN)}  {bold('TWINID Admin Panel')}\n\n"
        f"👥  Total users:  {bold(str(len(users)))}\n"
        f"{pemoji(E_CROWN)}  Exclusive:  {bold(str(excl_count))}",
        reply_markup=kb_admin())


# ══════════════════════════════════════════════════════════════════════
# Add User
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "admin:add")
async def cb_admin_add(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.add_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_TOPUP)}  {bold('Add User')}\n\nSend the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.message(AdminFlow.add_waiting_id)
async def admin_add_id(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("ID", "Send a numeric Telegram ID:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    await state.update_data(new_uid=int(raw))
    await state.set_state(AdminFlow.add_waiting_name)
    await send(msg, f"{pemoji(E_USER)}  Send a display name for this user:",
               reply_markup=kb_back_cancel("back:admin_add_id"))


@router.message(AdminFlow.add_waiting_name)
async def admin_add_name(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    name = (msg.text or "").strip()
    if not name:
        await send(msg, msg_invalid_input("name", "Name can't be empty."),
                   reply_markup=kb_back_cancel("back:admin_add_id")); return
    await state.update_data(new_name=name)
    await state.set_state(AdminFlow.add_waiting_credits)
    await send(msg, f"{pemoji(E_DIAMOND)}  Starting credits  {bold('(1 000 = $1.00)')}:",
               reply_markup=kb_back_cancel("back:admin_add_name"))


@router.message(AdminFlow.add_waiting_credits)
async def admin_add_credits_handler(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.isdigit() or int(raw) < 0:
        await send(msg, msg_invalid_input("credits", "Enter a non-negative number:"),
                   reply_markup=kb_back_cancel("back:admin_add_name")); return
    amount = int(raw)
    data   = await state.get_data()
    await add_user(data["new_uid"], data["new_name"], amount)
    await state.clear()
    await send(msg,
        f"{pemoji(E_DIAMOND)}  {bold('User Added!')}\n\n"
        f"ID      {code(str(data['new_uid']))}\n"
        f"Name    {bold(esc(data['new_name']))}\n"
        f"Credits  {bold(str(amount))}  ({usd(amount)})",
        reply_markup=kb_admin())


# ══════════════════════════════════════════════════════════════════════
# Top Up
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "admin:topup")
async def cb_topup_admin(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.topup_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_TOPUP)}  {bold('Top Up User')}\n\nSend the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.message(AdminFlow.topup_waiting_id)
async def admin_topup_id(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("ID", "Numeric Telegram ID:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    uid = int(raw)
    if not await get_user(uid):
        await send(msg, msg_invalid_input("ID", f"User {uid} not found:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    await state.update_data(topup_uid=uid)
    await state.set_state(AdminFlow.topup_waiting_amt)
    await send(msg, f"{pemoji(E_DIAMOND)}  Credits to add:",
               reply_markup=kb_back_cancel("back:admin_topup_id"))


@router.message(AdminFlow.topup_waiting_amt)
async def admin_topup_amt(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await send(msg, msg_invalid_input("amount", "Enter a positive number:"),
                   reply_markup=kb_back_cancel("back:admin_topup_id")); return
    amount = int(raw)
    data   = await state.get_data()
    await add_credits(data["topup_uid"], amount)
    from db.database import get_credits
    new_bal = await get_credits(data["topup_uid"])
    await state.clear()
    await send(msg,
        f"{pemoji(E_DIAMOND)}  {bold('Credits Added!')}\n\n"
        f"User      {code(str(data['topup_uid']))}\n"
        f"Added     +{amount}\n"
        f"New balance  {bold(str(new_bal))}  ({usd(new_bal)})",
        reply_markup=kb_admin())


# ══════════════════════════════════════════════════════════════════════
# Remove User
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "admin:remove")
async def cb_remove(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.remove_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_CROSS)}  {bold('Remove User')}\n\nSend the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.message(AdminFlow.remove_waiting_id)
async def admin_remove_id(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("ID", "Numeric Telegram ID:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    uid     = int(raw)
    removed = await remove_user(uid)
    await state.clear()
    if removed:
        await send(msg, f"{pemoji(E_DIAMOND)}  User  {code(str(uid))}  removed.",
                   reply_markup=kb_admin())
    else:
        await send(msg, msg_invalid_input("ID", f"User {uid} not found."), reply_markup=kb_admin())


# ══════════════════════════════════════════════════════════════════════
# Grant / Revoke Exclusive
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "admin:grant_excl")
async def cb_grant_excl(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.excl_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_CROWN)}  {bold('Grant Exclusive Membership')}\n\n"
        f"Every post from this user will show the\n"
        f"{bold('ܔܛܔ 𝗘𝗫𝗖𝗟𝗨𝗦𝗜𝗩𝗘 ܔܛܔ')}  badge in gold.\n\n"
        f"Send the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.message(AdminFlow.excl_waiting_id)
async def admin_grant_excl(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("ID", "Numeric Telegram ID:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    uid  = int(raw)
    user = await get_user(uid)
    if not user:
        await send(msg, msg_invalid_input("ID", f"User {uid} not found."),
                   reply_markup=kb_admin()); return
    await set_exclusive(uid, True)
    await state.clear()
    await send(msg,
        f"{pemoji(E_CROWN)}  {bold('Exclusive Granted!')}\n\n"
        f"User:  {bold(esc(user['name']))}  ({code(str(uid))})\n\n"
        f"All future posts from this user will carry the\n"
        f"{bold('✦ ܔܛܔ 𝗘𝗫𝗖𝗟𝗨𝗦𝗜𝗩𝗘 ܔܛܔ ✦')}  badge.",
        reply_markup=kb_admin())


@router.callback_query(F.data == "admin:revoke_excl")
async def cb_revoke_excl(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.revoke_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_SHIELD)}  {bold('Revoke Exclusive')}\n\n"
        f"Send the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.message(AdminFlow.revoke_waiting_id)
async def admin_revoke_excl(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("ID", "Numeric Telegram ID:"),
                   reply_markup=kb_back_cancel("back:admin_menu")); return
    uid  = int(raw)
    user = await get_user(uid)
    if not user:
        await send(msg, msg_invalid_input("ID", f"User {uid} not found."),
                   reply_markup=kb_admin()); return
    await set_exclusive(uid, False)
    await state.clear()
    await send(msg,
        f"{pemoji(E_SHIELD)}  {bold('Exclusive Revoked')}\n\n"
        f"User:  {bold(esc(user['name']))}  ({code(str(uid))})\n"
        f"Posts will no longer carry the exclusive badge.",
        reply_markup=kb_admin())


# ══════════════════════════════════════════════════════════════════════
# List Users / Exclusives
# ══════════════════════════════════════════════════════════════════════

@router.callback_query(F.data == "admin:list")
async def cb_list(cq: CallbackQuery):
    if not is_admin(cq.from_user.id): return
    users = await list_users()
    if not users:
        await edit(cq.message, "No users.", reply_markup=kb_admin()); return
    lines = [f"{pemoji(E_CROWN)}  {bold(f'All Users  ({len(users)})')}"]
    for uid, info in list(users.items())[:20]:
        bal   = info["credits"]
        excl  = f"  {pemoji(E_CROWN)}" if info.get("exclusive") else ""
        # Source from the tags table (authoritative) first — the cached
        # kivani_tag field on the user record can fall out of sync.
        kivani = await get_user_tag(int(uid)) or info.get("kivani_tag") or "—"
        lines.append(
            f"\n{pemoji(E_USER)}  {code(str(uid))}  {esc(info['name'])}{excl}\n"
            f"{pemoji(E_DIAMOND)}  {bal} cr  ({usd(bal)})   {pemoji(E_MESSAGE)} {kivani}"
        )
    if len(users) > 20:
        lines.append(f"\n…and {len(users)-20} more.")
    await edit(cq.message, "\n".join(lines), reply_markup=kb_admin())
    await cq.answer()


@router.callback_query(F.data == "admin:excl_list")
async def cb_excl_list(cq: CallbackQuery):
    if not is_admin(cq.from_user.id): return
    users = await list_users()
    excl  = {uid: u for uid, u in users.items() if u.get("exclusive")}
    if not excl:
        await cq.answer("No exclusive members yet.", show_alert=True); return
    lines = [f"{pemoji(E_CROWN)}  {bold(f'Exclusive Members  ({len(excl)})')}"]
    for uid, info in excl.items():
        lines.append(f"\n✦  {code(str(uid))}  {bold(esc(info['name']))}")
    await edit(cq.message, "\n".join(lines), reply_markup=kb_admin())
    await cq.answer()


# ══════════════════════════════════════════════════════════════════════
# TwinGuard — enable/disable the moderation module per chat
# ══════════════════════════════════════════════════════════════════════
# Merged into TwinIDBot rather than run as a separate bot. Costs
# nothing in chats that aren't explicitly enabled here — see
# handlers/moderation.py for the actual filter/wipe logic.

def kb_twinguard(chats: dict) -> InlineKeyboardMarkup:
    rows = []
    for chat_id, info in chats.items():
        mark  = "✅" if info.get("enabled") else "⬜"
        title = info.get("title") or chat_id
        rows.append([ibtn(f"{mark} {title}", f"modtoggle:{chat_id}")])
    rows.append([ibtn("+ Enable a chat", "admin:mod_add", E_TOPUP)])
    rows.append([ibtn("Back", "back:admin_menu", E_BACK)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _twinguard_text() -> str:
    chats = await list_moderated_chats()
    on_count = sum(1 for c in chats.values() if c.get("enabled"))
    body = (
        f"{pemoji(E_FIRE)}  {bold('TwinGuard')}\n\n"
        f"Deletes ad/spam walls (500+ word messages) and join/leave "
        f"clutter in chats enabled below. Tap a chat to toggle it.\n\n"
        f"Active in  {bold(str(on_count))}  of  {bold(str(len(chats)))}  known chats."
    )
    return body


@router.callback_query(F.data == "admin:twinguard")
async def cb_twinguard(cq: CallbackQuery):
    if not is_admin(cq.from_user.id): return
    chats = await list_moderated_chats()
    await edit(cq.message, await _twinguard_text(), reply_markup=kb_twinguard(chats))
    await cq.answer()


@router.callback_query(F.data.startswith("modtoggle:"))
async def cb_mod_toggle(cq: CallbackQuery):
    if not is_admin(cq.from_user.id): return
    chat_id = int(cq.data.split(":", 1)[1])
    chats   = await list_moderated_chats()
    current = chats.get(str(chat_id), {}).get("enabled", False)
    await set_moderation_enabled(chat_id, not current)
    chats = await list_moderated_chats()
    await edit(cq.message, await _twinguard_text(), reply_markup=kb_twinguard(chats))
    await cq.answer("Enabled" if not current else "Disabled")


@router.callback_query(F.data == "admin:mod_add")
async def cb_mod_add(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.mod_waiting_chatid)
    await edit(cq.message,
        f"{pemoji(E_FIRE)}  {bold('Enable TwinGuard for a chat')}\n\n"
        f"Send the group's chat ID (looks like  {code('-100XXXXXXXXXX')}  — "
        f"forward any message from that group to  {code('@userinfobot')}  "
        f"if you don't have it handy). The bot must already be an admin "
        f"there with delete-message rights.",
        reply_markup=kb_back_cancel("admin:twinguard"))
    await cq.answer()


@router.message(AdminFlow.mod_waiting_chatid)
async def admin_mod_add_chatid(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id): return
    raw = (msg.text or "").strip()
    if not raw.lstrip("-").isdigit():
        await send(msg, msg_invalid_input("chat ID", "Send a numeric chat ID (e.g. -1001234567890):"),
                   reply_markup=kb_back_cancel("admin:twinguard")); return
    chat_id = int(raw)
    await set_moderation_enabled(chat_id, True)
    await state.clear()
    chats = await list_moderated_chats()
    await send(msg,
        f"{pemoji(E_CHECK)}  TwinGuard enabled for  {code(str(chat_id))}.",
        reply_markup=kb_twinguard(chats))


# ── Admin back-nav ─────────────────────────────────────────────────────

@router.callback_query(F.data == "back:admin_menu")
async def back_admin_menu(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.clear()
    users = await list_users()
    excl_count = sum(1 for u in users.values() if u.get("exclusive"))
    await edit(cq.message,
        f"{pemoji(E_CROWN)}  {bold('TWINID Admin Panel')}\n\n"
        f"👥  Total users:  {bold(str(len(users)))}\n"
        f"{pemoji(E_CROWN)}  Exclusive:  {bold(str(excl_count))}",
        reply_markup=kb_admin())
    await cq.answer()


@router.callback_query(F.data == "back:admin_add_id")
async def back_admin_add_id(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.add_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_TOPUP)}  {bold('Add User')}\n\nSend the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()


@router.callback_query(F.data == "back:admin_add_name")
async def back_admin_add_name(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    data = await state.get_data()
    await state.set_state(AdminFlow.add_waiting_name)
    await edit(cq.message,
        f"{pemoji(E_USER)}  Name for user  {code(str(data.get('new_uid','?')))}:",
        reply_markup=kb_back_cancel("back:admin_add_id"))
    await cq.answer()


@router.callback_query(F.data == "back:admin_topup_id")
async def back_admin_topup_id(cq: CallbackQuery, state: FSMContext):
    if not is_admin(cq.from_user.id): return
    await state.set_state(AdminFlow.topup_waiting_id)
    await edit(cq.message,
        f"{pemoji(E_TOPUP)}  {bold('Top Up User')}\n\nSend the user's Telegram ID:",
        reply_markup=kb_back_cancel("back:admin_menu"))
    await cq.answer()
