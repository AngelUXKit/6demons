-- ============================================================
--  TwinIDBot — MySQL Database Setup
--  Run once:  mysql -u root -p < twinidbot.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS twinidbot
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'twinbot'@'root'
    IDENTIFIED BY 'Balenci123$$';

GRANT ALL PRIVILEGES ON twinidbot.* TO 'twinbot'@'root';
FLUSH PRIVILEGES;

USE twinidbot;

-- ── KivaniCDK Messages ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS kivani_messages (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    sender_tag      VARCHAR(16)     NOT NULL,
    receiver_tag    VARCHAR(16)     NOT NULL,
    content         TEXT            NOT NULL,
    sent_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_read         TINYINT(1)      NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    INDEX idx_receiver  (receiver_tag),
    INDEX idx_sender    (sender_tag),
    INDEX idx_sent_at   (sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;