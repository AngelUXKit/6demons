import json
import os
from datetime import datetime, timezone
from config import EDITS_LOG_FILE

def load_logs() -> list:
    if not os.path.exists(EDITS_LOG_FILE):
        return []
    with open(EDITS_LOG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_logs(logs: list):
    with open(EDITS_LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2, ensure_ascii=False)

def add_edit_log(user_id: int, content: str) -> int:
    logs = load_logs()
    entry = {
        "user_id": user_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "content": content
    }
    logs.append(entry)
    save_logs(logs)
    return len(logs) - 1

def get_user_logs(user_id: int) -> list:
    logs = load_logs()
    return [entry for entry in logs if entry.get("user_id") == user_id]