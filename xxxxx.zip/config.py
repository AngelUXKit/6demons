BOT_TOKEN   = "8845674141:AAGd3vUP3CIJLUzNa0yY6oByphN9M33hvnc"
ADMIN_ID    = 6662384890
SUPPORT_URL = "https://t.me/borzbec"

KEYS_FILE  = "keys.json"
USERS_FILE = "users.json"
SEEN_FILE  = "seen.json"
PHOTO_PATH = "cachias.jpg"

UID_SALT = "devil2025$$__"

# ---- paths for JS and logs ----
CACHIAS_JS_PATH = "cachias.js"
EDITS_LOG_FILE  = "edits_log.json"

_EMOJI = {
    "star":    "⭐",
    "check":   "✅",
    "cross":   "❌",
    "lock":    "🔐",
    "crown":   "👑",
    "fire":    "🔥",
    "diamond": "💎",
    "bolt":    "⚡",
    "shield":  "🛡️",
    "user":    "👤",
    "trash":   "🗑️",
    "list":    "📋",
    "warn":    "⚠️",
    "key":     "🔑",
    "send":    "📤",
    "edit":    "✏️",
    "download":"⬇️",
    "save":    "💾",
}

def pe(name: str) -> str:
    return _EMOJI.get(name, "·")