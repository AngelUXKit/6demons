import json
import os
from datetime import datetime, timezone
from config import KEYS_FILE, USERS_FILE, SEEN_FILE

THROTTLE_DAYS = 90

def load_seen() -> dict:
    if not os.path.exists(SEEN_FILE):
        return {}
    with open(SEEN_FILE, "r") as f:
        return json.load(f)

def save_seen(data: dict):
    with open(SEEN_FILE, "w") as f:
        json.dump(data, f, indent=2)

def record_seen(cachias_id: str, telegram_id: int):
    data = load_seen()
    data[cachias_id] = telegram_id
    save_seen(data)

def telegram_id_from_cachias_id(cachias_id: str) -> int | None:
    return load_seen().get(cachias_id)

def load_users() -> dict:
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r") as f:
        return json.load(f)

def save_users(data: dict):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def is_allowed(user_id: int) -> bool:
    return str(user_id) in load_users()

def add_user(user_id: int, label: str = "", cachias_id: str = "") -> bool:
    data = load_users()
    key  = str(user_id)
    if key in data:
        return False
    data[key] = {"label": label, "cachias_id": cachias_id}
    save_users(data)
    return True

def remove_user_by_cachias_id(cachias_id: str) -> tuple[bool, int | None]:
    data = load_users()
    for tg_id, info in data.items():
        if info.get("cachias_id") == cachias_id:
            del data[tg_id]
            save_users(data)
            return True, int(tg_id)
    return False, None

def list_users() -> dict:
    return load_users()

def load_keys() -> list:
    if not os.path.exists(KEYS_FILE):
        return []
    with open(KEYS_FILE, "r") as f:
        return json.load(f)

def save_keys(data: list):
    with open(KEYS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _days_since(iso: str) -> float:
    dt = datetime.fromisoformat(iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - dt).total_seconds() / 86400

def get_claimed_key(user_id: int) -> dict | None:
    keys = load_keys()
    found = None
    for entry in keys:
        if entry.get("claimed_by") == user_id and entry.get("used"):
            if found is None or (entry.get("claimed_at", "") > found.get("claimed_at", "")):
                found = entry
    return found

def claim_key(user_id: int) -> tuple[dict | None, float | None]:
    keys = load_keys()
    last_claim_iso = None
    for entry in keys:
        if entry.get("claimed_by") == user_id and entry.get("used"):
            ts = entry.get("claimed_at")
            if ts and (last_claim_iso is None or ts > last_claim_iso):
                last_claim_iso = ts

    if last_claim_iso:
        days_ago = _days_since(last_claim_iso)
        if days_ago < THROTTLE_DAYS:
            return None, THROTTLE_DAYS - days_ago

    for entry in keys:
        if not entry.get("used"):
            entry["used"]       = True
            entry["claimed_by"] = user_id
            entry["claimed_at"] = _now_iso()
            save_keys(keys)
            return entry, None

    return None, None

def total_keys() -> tuple[int, int]:
    keys  = load_keys()
    used  = sum(1 for k in keys if k.get("used"))
    return used, len(keys)