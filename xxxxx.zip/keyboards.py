from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import SUPPORT_URL, pe

def btn(text: str, emoji: str, **kwargs) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=f"{pe(emoji)}  {text}", **kwargs)

def kb_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Get My Panel Key", "key",    callback_data="get_key")],
        [btn("Edit Source Config", "edit", callback_data="edit_source")],
        [btn("Support",          "shield", url=SUPPORT_URL)],
    ])

def kb_support() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Pricing & Plans", "diamond", callback_data="pricing")],
        [btn("Contact Support", "bolt",    url=SUPPORT_URL)],
    ])

def kb_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Back to Menu", "star", callback_data="back_main")],
    ])

def kb_pricing() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Get A-Tier — $500",    "fire",  url=SUPPORT_URL)],
        [btn("Get Premium — $2,000", "crown", url=SUPPORT_URL)],
        [btn("Contact Support",      "bolt",  url=SUPPORT_URL)],
    ])

def kb_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Add User",    "user",    callback_data="admin_add")],
        [btn("Remove User", "trash",   callback_data="admin_remove")],
        [btn("List Users",  "list",    callback_data="admin_list")],
        [btn("Key Stats",   "diamond", callback_data="admin_stats")],
    ])

def kb_admin_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [btn("Admin Panel", "crown", callback_data="back_admin")],
    ])